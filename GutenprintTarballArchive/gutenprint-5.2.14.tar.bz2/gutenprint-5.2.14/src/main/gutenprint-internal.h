/*
 *   Print plug-in header file for the GIMP.
 *
 *   Copyright 1997-2000 Michael Sweet (mike@easysw.com) and
 *	Robert Krawitz (rlk@alum.mit.edu)
 *
 *   This program is free software; you can redistribute it and/or modify it
 *   under the terms of the GNU General Public License as published by the Free
 *   Software Foundation; either version 2 of the License, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful, but
 *   WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 *   or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *   for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Revision History:
 *
 *   See ChangeLog
 */

/*
 * This file must include only standard C header files.  The core code must
 * compile on generic platforms that don't support glib, gimp, gtk, etc.
 */

#ifndef GUTENPRINT_INTERNAL_INTERNAL_H
#define GUTENPRINT_INTERNAL_INTERNAL_H

#ifdef __cplusplus
extern "C" {
#endif

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <gutenprint/gutenprint-module.h>

/**
 * Utility functions (internal).
 *
 * @defgroup util_internal util-internal
 * @{
 */

extern void stpi_init_paper(void);
extern void stpi_init_dither(void);
extern void stpi_init_printer(void);
extern void stpi_vars_print_error(const stp_vars_t *v, const char *prefix);
#define BUFFER_FLAG_FLIP_X	0x1
#define BUFFER_FLAG_FLIP_Y	0x2
extern stp_image_t* stpi_buffer_image(stp_image_t* image, unsigned int flags);

#define STPI_ASSERT(x,v)						\
do									\
{									\
  if (stp_get_debug_level() & STP_DBG_ASSERTIONS)			\
    stp_erprintf("DEBUG: Testing assertion %s file %s line %d\n",	\
		 #x, __FILE__, __LINE__);				\
  if (!(x))								\
    {									\
      stp_erprintf("\nERROR: ***Gutenprint %s assertion %s failed!"	\
		   " file %s, line %d.  %s\n", PACKAGE_VERSION,		\
		   #x, __FILE__, __LINE__, "Please report this bug!");	\
      if ((v)) stpi_vars_print_error((v), "ERROR");			\
      stp_abort();							\
    }									\
} while (0)

/** @} */

#define CAST_IS_SAFE GCC_DIAG_OFF(cast-qual)
#define CAST_IS_UNSAFE GCC_DIAG_ON(cast-qual)

#pragma GCC diagnostic ignored "-Woverlength-strings"
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wcast-qual"
static inline void *
stpi_cast_safe(const void *ptr)
{
  return (void *)ptr;
}
#pragma GCC diagnostic pop

#ifdef __cplusplus
  }
#endif

#endif /* GUTENPRINT_INTERNAL_INTERNAL_H */
