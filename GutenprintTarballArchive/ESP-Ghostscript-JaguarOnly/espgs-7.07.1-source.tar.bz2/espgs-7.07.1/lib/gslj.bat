@echo off
@rem $Id: gslj.bat,v 1.3 2002/04/23 11:58:34 easysw Exp $

call gssetgs.bat
%GSC% -q -sDEVICE=laserjet -r300 -dNOPAUSE -sPROGNAME=gslj -- gslp.ps %1 %2 %3 %4 %5 %6 %7 %8 %9
