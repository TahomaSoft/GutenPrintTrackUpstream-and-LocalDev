@echo off
@rem $Id: gst.bat,v 1.3 2002/04/23 11:58:34 easysw Exp $

call gssetgs.bat
%GS% %1 %2 %3 %4 %5 %6 %7 %8 %9 >t
