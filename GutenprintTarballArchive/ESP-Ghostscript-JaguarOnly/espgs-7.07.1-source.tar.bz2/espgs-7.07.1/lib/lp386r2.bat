@rem $Id: lp386r2.bat,v 1.3 2002/04/23 11:58:35 easysw Exp $
@gs386 -sDEVICE=djet500 -dNOPAUSE -- gslp.ps -2r %1 %2 %3 %4 %5 %6 %7 %8 %9
