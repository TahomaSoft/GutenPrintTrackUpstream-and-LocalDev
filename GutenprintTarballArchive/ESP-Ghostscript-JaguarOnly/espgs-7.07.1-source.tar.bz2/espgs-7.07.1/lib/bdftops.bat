@echo off
@rem $Id: bdftops.bat,v 1.3 2002/04/23 11:58:33 easysw Exp $

call gssetgs.bat
%GSC% -q -dBATCH -dNODISPLAY -- bdftops.ps %1 %2 %3 %4 %5 %6 %7 %8 %9
