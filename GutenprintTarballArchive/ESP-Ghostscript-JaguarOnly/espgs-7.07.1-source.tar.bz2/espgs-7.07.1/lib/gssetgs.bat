@echo off
@rem $Id: gssetgs.bat,v 1.3 2002/04/23 11:58:34 easysw Exp $

rem Set default values for GS (gs with graphics window) and GSC
rem (console mode gs) if the user hasn't set them.

if %GS%/==/ set GS=gswin32
if %GSC%/==/ set GSC=gswin32c
