/* $Id: pf2afm.cmd,v 1.3 2002/04/23 11:58:36 easysw Exp $ */
/*
 * This file is maintained by a user: if you have any questions about it,
 * please contact Mark Hale (mark.hale@physics.org).
 */

@gsos2 -q -dNODISPLAY -dSAFER -dDELAYSAFER -- pf2afm.ps %1
