@echo off
@rem $Id: lpgs.bat,v 1.3 2002/04/23 11:58:35 easysw Exp $

call gssetgs.bat
%GSC% -sDEVICE#djet500 -dNOPAUSE -sPROGNAME=lpgs -- gslp.ps -fCourier9 %1 %2 %3 %4 %5 %6 %7 %8 %9
