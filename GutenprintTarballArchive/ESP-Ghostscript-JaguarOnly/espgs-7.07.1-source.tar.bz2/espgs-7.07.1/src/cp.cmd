@copy /B %1 %2
@rem $Id: cp.cmd,v 1.3 2002/04/23 11:58:38 easysw Exp $
@if not "%2"=="." touch %2
