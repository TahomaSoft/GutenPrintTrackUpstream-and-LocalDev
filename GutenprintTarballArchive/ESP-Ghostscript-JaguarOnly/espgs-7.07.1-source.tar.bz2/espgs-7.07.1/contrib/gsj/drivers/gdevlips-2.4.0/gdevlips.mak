# ---------------- Laser Printer devices ---------------- #
# $Id: gdevlips.mak,v 1.1 2002/10/12 23:24:34 tillkamppeter Exp $

$(GLOBJ)gdevlprn.$(OBJ): $(GLSRC)gdevlprn.c $(GLSRC)gdevlprn.h\
 $(gdevprn_h) $(PDEVH)
	$(GLCC) $(GLO_)gdevlprn.$(OBJ) $(C_) $(GLSRC)gdevlprn.c

### --- The Canon LIPS II+/III/IVc/IV printer device --- ###

lipsr_=$(GLOBJ)gdevl4r.$(OBJ) $(GLOBJ)gdevlips.$(OBJ) $(GLOBJ)gdevlprn.$(OBJ)
$(GLOBJ)gdevl4r.$(OBJ): $(GLSRC)gdevl4r.c $(GLSRC)gdevlips.h $(PDEVH)
	$(GLCC) -DA4 $(GLO_)gdevl4r.$(OBJ) $(C_) $(GLSRC)gdevl4r.c
$(GLOBJ)gdevlips.$(OBJ): $(GLSRC)gdevlips.c
	$(GLCC) $(GLO_)gdevlips.$(OBJ) $(C_) $(GLSRC)gdevlips.c
$(DD)lips2p.dev: $(lipsr_) $(DD)page.dev
	$(SETPDEV) $(DD)lips2p $(lipsr_)
$(DD)lips3.dev: $(lipsr_) $(DD)page.dev
	$(SETPDEV) $(DD)lips3 $(lipsr_)
$(DD)bjc880j.dev: $(lipsr_) $(DD)page.dev
	$(SETPDEV) $(DD)bjc880j $(lipsr_)
$(DD)lips4.dev: $(lipsr_) $(DD)page.dev
	$(SETPDEV) $(DD)lips4 $(lipsr_)

lipsv_=$(GLOBJ)gdevl4v.$(OBJ) $(GLOBJ)gdevlips.$(OBJ)
$(DD)lips4v.dev: $(ECHOGS_XE) $(lipsv_) $(DD)vector.dev
	$(SETDEV) $(DD)lips4v $(lipsv_)
	$(ADDMOD) $(DD)lips4v -include $(DD)vector

$(GLOBJ)gdevl4v.$(OBJ): $(GLSRC)gdevl4v.c $(GLSRC)gdevlips.h $(GDEV) $(math__h)\
 $(gscspace_h) $(gsutil_h) $(gsparam_h) $(gsmatrix_h) $(gdevvec_h)\
 $(ghost_h) $(gzstate_h) $(igstate_h)
	$(GLCC) -DA4 $(GLO_)gdevl4v.$(OBJ) $(C_) $(GLSRC)gdevl4v.c

### ------- Epson ESC/Page printer device ----------------- ###

escpage_=$(GLOBJ)gdevespg.$(OBJ) $(GLOBJ)gdevlprn.$(OBJ)
$(GLOBJ)gdevespg.$(OBJ): $(GLSRC)gdevespg.c $(GLSRC)gdevlprn.h $(PDEVH)
	$(GLCC) -DA4 $(GLO_)gdevespg.$(OBJ) $(C_) $(GLSRC)gdevespg.c

$(GLOBJ)escpage.dev: $(escpage_) $(DD)page.dev
	$(SETPDEV) $(DD)escpage $(escpage_)

$(GLOBJ)lp2000.dev: $(escpage_) $(DD)page.dev
	$(SETPDEV) $(DD)lp2000 $(escpage_)

### --- The NEC NPDL language printer device ------ ###

npdl_=$(GLOBJ)gdevnpdl.$(OBJ) $(GLOBJ)gdevlprn.$(OBJ)
$(GLOBJ)gdevnpdl.$(OBJ): $(GLSRC)gdevnpdl.c $(GLSRC)gdevlprn.h $(PDEVH)
	$(GLCC) -DA4 $(GLO_)gdevnpdl.$(OBJ) $(C_) $(GLSRC)gdevnpdl.c

$(GLOBJ)npdl.dev: $(npdl_) $(DD)page.dev
	$(SETPDEV) $(DD)npdl $(npdl_)
	
### --- The RICOH RPDL language printer device ------ ###

rpdl_=$(GLOBJ)gdevrpdl.$(OBJ) $(GLOBJ)gdevlprn.$(OBJ)
$(GLOBJ)gdevrpdl.$(OBJ): $(GLSRC)gdevrpdl.c $(GLSRC)gdevlprn.h $(PDEVH)
	$(GLCC) -DA4 $(GLO_)gdevrpdl.$(OBJ) $(C_) $(GLSRC)gdevrpdl.c

$(GLOBJ)rpdl.dev: $(rpdl_) $(DD)page.dev
	$(SETPDEV) $(DD)rpdl $(rpdl_)
	
