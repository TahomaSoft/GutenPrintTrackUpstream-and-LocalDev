/*
 * $Id: main.c 109 2008-11-01 21:04:33Z tyler $
 *
 *   Mac OS X USB backend for the Common UNIX Printing System (CUPS).
 *
 *   Copyright 2003-2007 Tyler Blessing, all rights reserved.
 *                                                                             
 *  This program is freed software; you can redistribute it and/or modify it   
 *  under the terms of the GNU General Public License as published by the Free 
 *  Software Foundation; either version 2 of the License, or (at your option)  
 *  any later version.                                                         
 *                                                                             
 *  Inquiries regarding the use of this copyrighted software under alternate
 *  license terms should be directed to one of the following addresses:                                                                               
 *                                                                             
 *      Software Licensing
 *      PO Box 300645
 *      Austin TX 78703
 
 *      swlicense@buymelunch.org
 *                                                                             
 *  This program is distributed in the hope that it will be useful, but        
 *  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
 *  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License   
 *  for more details.
 *
 *  You should have received a copy of the GNU General Public License          
 *  along with this program; if not, write to the Free Software                
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */


#include <CoreFoundation/CoreFoundation.h>
#include <IOKit/IOCFPlugIn.h>
#include <IOKit/usb/IOUSBLib.h>
#include <IOKit/IOMessage.h>
#include <unistd.h>

#define SVN_REV_VALUE                     "$Rev: 109 $"
#define APP_VERSION_NUMBER_STRING         "1.0.17"
#define APP_NAME_STRING                   "usbtb"
#define DEVICE_URI_PREFIX                 APP_NAME_STRING"://"
#define TB_VALID_CONTEXT_KEY              4233433437ul
#define URI_OPTIONS_STRING                "?options"
#define URI_OPTION_BUF_SIZE               "+bufsize="
#define URI_OPTION_DEBUG                  "+debug"
#define URI_OPTION_SIGNAL_READ            "+sigread"
#define MAX_CHUNK_SIZE                    32768
#define BUF_SIZE_MAX                      8388608
#define BUF_SIZE_DEFAULT                  MAX_CHUNK_SIZE
#define NULL_STRING                       "(null)"
#define APP_SHOW_VERSION_STRING           "--version"
#define APP_SHOW_DEVICE_IDS_STRING        "--showDeviceIDs"
#define APP_AS_UTILITY                    "--utility"
#define APP_DEBUG_TEST                    "--debugTest"

#define IPP_OFFLINE                       "offline-error"
#define IPP_MEDIA_EMPTY                   "media-empty-error"

#define DESTROY_CFTypeRef(arg)      (void *)((NULL == (arg)) ? NULL : (CFRelease(arg), (arg)=NULL))
#define NULLIFY_REF_OF_POINTER(arg) (void *)((NULL != (arg) && NULL != *(arg)) ? (*(arg)=NULL) : NULL)

#define CUPS_DEBUG2(format, ...) fprintf(stderr, "DEBUG2: %s: "format, APP_NAME_STRING, ## __VA_ARGS__)
#define CUPS_DEBUG(format, ...) fprintf(stderr,"%s: %s: "format, gDebugStr, APP_NAME_STRING, ## __VA_ARGS__)
#define CUPS_ERROR(format, ...) fprintf(stderr, "ERROR: "format, ## __VA_ARGS__)
#define CUPS_INFO(format, ...) fprintf(stderr, "INFO: "format, ## __VA_ARGS__)

#define CUPS_RECOVERABLE(format, ...) fprintf(stderr, "ERROR: recoverable: "format, ## __VA_ARGS__)
#define CUPS_RECOVERED(format, ...) fprintf(stderr, "INFO: recovered: "format, ## __VA_ARGS__)

#define    CUPS_STATE_SET(state)    fprintf(stderr, "STATE: +"state"\n")
#define  CUPS_STATE_CLEAR(state)    fprintf(stderr, "STATE: -"state"\n")


enum {
        kUSBPrintingSubclass            = 1,

        kUSBPrintClassGetDeviceID       = 0,
        kUSBPrintClassGetPortStatus     = 1,
        kUSBPrintClassSoftReset         = 2,

        kUSBPrintClassDeviceNoError     = 1 << 3,
        kUSBPrintClassDeviceSelected    = 1 << 4,
        kUSBPrintClassDevicePaperEmpty  = 1 << 5,
        
        kUSBdefaultControlPipe = 0,

        kUSBInterfaceIsOpen              = 1,
        kUSBInterfaceIsClosed            = 0,

        kReadStreamNoDataTimeOutDefault  = 30,

        kBackChannelDevice               = 1 << 0,
        kPrinterDeviceStatusInDeviceID   = 1 << 1,
        kGetPrinterDeviceStatus          = 1 << 2,
        kEpsonPrinterDevice              = ((1 << 20) | kBackChannelDevice),        
        kHPPrinterDevice                 = ((1 << 21) | kPrinterDeviceStatusInDeviceID),
        kPrinterUtility                  =  (1 << 22),
        kBackChannelSignalRead           =  (1 << 23) ,
        
        kEpsonPrinterFormFeed            = 1 << 3,
        kEpsonPrinterCommandSetStatus    = 1 << 4,
        kEpsonPrinterCommandNozzleCheck  = ((1 << 5) | kEpsonPrinterFormFeed),
        kEpsonPrinterCommandDoAlignment  = ((1 << 6) | kEpsonPrinterFormFeed),
        kEpsonPrinterCommandSetAlignment = 1 << 7,
        kEpsonPrinterCommandGetInkQ      = 1 << 8,
        kEpsonPrinterUsesPacketMode      = 1 << 12,
        kEpsonPrinterRemoteCommandBegin  = 1 << 13,
        kEpsonPrinterRemoteCommandEnd    = 1 << 14,
        kEpsonPrinterReset               = 1 << 15,
        
        kMallocQuantumSize               = 16,
        kMaxInkColors                    = 16,

        readStreamCallBack_Dirty            = 1 << 1,
        IOAsyncReadPipeCallback1_Dirty		= 1 << 2,
        IOAsyncWritePipeCallback2_Dirty		= 1 << 3,
        readStreamTimerCallback_Dirty		= 1 << 4,
        writeCompletionTimerCallback_Dirty  = 1 << 5,
        deviceStatusTimerCallback_Dirty		= 1 << 6,
        writeStreamCallback_Dirty		    = 1 << 7,
        
        IOAsyncWritePipeCallback2_CleanMask  = (IOAsyncWritePipeCallback2_Dirty ^ 0xff)
};

typedef struct {
    UInt8 bulkIN;
    UInt8 bulkOUT;
    UInt8 configurationIndex;
    UInt8 interfaceProtocol;
    UInt8 interfaceNumber;
    UInt8 interfaceAlternate;
    UInt8 interfaceStatus;
    UInt8 callbackInProgress;
    UInt16 idVendor;
    UInt16 idProduct;
    UInt32 deviceProperties;
    UInt32 readByteCount;
    UInt32 writeByteCount;
    UInt32 completedCount;
    UInt32 validator;
    UInt32 backchannelBufferSize;
    UInt8 * backchannelBuffer;
    UInt16 deviceIDBufferSize;
    UInt16 deviceIDLength;
    UInt8 * deviceIDBuffer;
    IOReturn readStatus;
    IOReturn writeStatus;
    IOReturn USBReadStatus;
    CFIndex maxQueuedData;
    CFIndex readStreamReadSize;
    CFIndex recentWriteTimeoutCount;
    CFTimeInterval readStreamNoDataTimeOut;
    CFTimeInterval writeCompletionTimeOut;
    CFTimeInterval deviceStatusReadInterval;
    CFReadStreamRef readStream;
    CFWriteStreamRef writeStream;
    CFMutableArrayRef dataArray;
    CFArrayRef runLoopModes;
    CFRunLoopTimerRef readStreamTimer;
    CFRunLoopTimerRef writeCompletionTimer;
    CFRunLoopTimerRef deviceStatusTimer;
    CFRunLoopSourceRef interfaceAsyncSource;
    CFRunLoopObserverRef runLoopObserver;
    io_service_t deviceObject;
    io_iterator_t  objectIterator;
    IONotificationPortRef notifyPort;
    IOUSBInterfaceInterface190 **interface;
    IOUSBDeviceInterface187 **device;
    CFStringRef deviceIDString;
    CFStringRef deviceURIString;
} TBUSBInterfaceContext;


extern ssize_t cupsBackChannelWrite( const char * buffer, size_t bytes, double timeout)   WEAK_IMPORT_ATTRIBUTE;

#pragma mark -
#pragma mark declarations

void list_devices(void);
void list_device_IDs(void);

// print a CFStringRef to stdout
void putCFString(CFStringRef theString);
void fputCFString(CFStringRef theString, FILE *stream);

// given valid input strings for str, prefix, and terminator, this function will return the first substring in str between prefix and terminator, exclusive; otherwise it returns NULL. 
CFStringRef TBCFStringCreateSubstringFromPrefixToTerminator(CFStringRef str, CFStringRef prefix, CFStringRef terminator);

IOReturn decodeDeviceIDCreate(CFStringRef deviceID, CFStringRef *deviceURI, CFStringRef *deviceDescription, CFStringRef *mfg, CFStringRef *MDLStr);
static kern_return_t usbPrinter_CreateCFStringWithGET_DEVICE_ID(IOUSBInterfaceInterface190 **interface, CFStringRef *deviceID);
static void deviceIDDictionaryCreate(CFMutableDictionaryRef *deviceIDDict);
static kern_return_t usbInterfaceGetConfigurationDescriptor( IOUSBInterfaceInterface190 **iInterface, UInt8 *interfaceNumber, UInt8 *interfaceAlternate);
static kern_return_t usbInterfaceGetiDeviceIndices( IOUSBInterfaceInterface190 **interfaceInterface, CFIndex *iManufacturer, CFIndex *iProduct, CFIndex *iSerialNumber);
static kern_return_t usbInterfaceGetDescriptorStringCopy(  IOUSBInterfaceInterface190 **interface, CFIndex stringIndex, CFStringRef *descriptorString);
IOReturn usbInterfaceGetDeviceDescriptor( IOUSBInterfaceInterface190 **interfaceInterface, IOUSBDeviceDescriptorPtr dDescriptor, CFIndex dDescriptorLength);
void applyToValueIUnknownRelease(const void *key, const void *value, void *context);
IOReturn openDeviceOpenReadStream(const char *uri, const char *printFile, int copies);
IOReturn copyUSBIInterfaceForURIForContext(TBUSBInterfaceContext  *tbContext, const char *uri);
IOReturn openUSBInterfaceForContext(TBUSBInterfaceContext  *tbContext);
IOReturn setWriteStream(const char * path, TBUSBInterfaceContext *tbContext);
Boolean setReadStreamClientForContext(TBUSBInterfaceContext  *tbContext);
Boolean setReadStreamTimerForContext(TBUSBInterfaceContext  *tbContext);
void setWriteCompletionTimerForContext(TBUSBInterfaceContext  *tbContext);
void handleSignalForContext(TBUSBInterfaceContext  *tbContext);
void stopRunLoopForContext(TBUSBInterfaceContext * tbContext);
void killWriteCompletionTimer(TBUSBInterfaceContext  *tbContext);
void setDeviceStatusTimerForContext(TBUSBInterfaceContext  *tbContext);
void readStreamCallBack(CFReadStreamRef readStream, CFStreamEventType eventType, void *info);
void IOAsyncWritePipeCallback2( void *context, IOReturn ioResult, void *arg0);
void initializeContext(TBUSBInterfaceContext * tbContext);
void removeRunLoopSourcesForContext(TBUSBInterfaceContext * tbContext);
void destroyContext(TBUSBInterfaceContext * tbContext);
void examineDeviceForContext(TBUSBInterfaceContext * tbContext);
void readFromReadStreamForContext(CFReadStreamRef readStream, TBUSBInterfaceContext *tbContext);
void readAsyncFromUSBInterfaceForContext(TBUSBInterfaceContext * tbContext);
void writeAsyncToUSBInterfaceForContext(TBUSBInterfaceContext  *tbContext);
void compactDataArrayFromIndexForContext(CFIndex start, CFIndex maxSize, TBUSBInterfaceContext * tbContext);
void epsonPrinterStartReportingForContext(TBUSBInterfaceContext * tbContext);
void hpPrinterStartReportingForContext(TBUSBInterfaceContext * tbContext);
void getDeviceIDForContext(TBUSBInterfaceContext * tbContext);
void readStreamTimerCallback(CFRunLoopTimerRef readStreamTimer, void *info);
static IOReturn usbPrinterGetPortStatus(IOUSBInterfaceInterface190 **interface, UInt8 *portStatus);
IOReturn usbInterfaceResetUSBDevice(IOUSBInterfaceInterface190 **interface);
kern_return_t usbPrinterSoftReset(IOUSBInterfaceInterface190 **interface);
kern_return_t usbPrinterSoftResetCompatible(IOUSBInterfaceInterface190 **interface);
kern_return_t sendSoftResetGeneric(IOUSBInterfaceInterface190 **interface, bool versionOneDotZeroCompatible);
static void signalHandler(int sigraised);
IOReturn epsonPrinterParseInkData(UInt8 *buffer, unsigned numBytesRead);
void parseHPDeviceIDForStatus(const char * deviceID, UInt16 deviceIDLength);
IOReturn epsonPrinterGetRemoteCommand(UInt8 *buffer, unsigned *byteCount, int *command, int commandCount, bool usesPacketMode);
const char *strForCFStreamStatus(CFStreamStatus streamStatus);
const char *strForIOMessage(IOMessage message);
const char *strForIOReturn(IOReturn ioResult);
const char *strForSignal(int sigraised);

#pragma mark -
#pragma mark main functions

int gargc;      // global argument count
int gSignal=0;  // global signal flag
const char *gDebugStr = "DEBUG";

static char * revStr()
{
    static char revStr[16]="";
    if(0 == revStr[0])
    {
        char * revPtr = SVN_REV_VALUE;
        int i,j;

        for(i=0;sizeof(SVN_REV_VALUE) > i && ' ' != revPtr[i++];);

        for(j=0;sizeof(SVN_REV_VALUE) > i && sizeof(revStr) - 1 > j && ' ' != revPtr[i];)
            revStr[j++] = revPtr[i++];

        if(0 == j)
        {
            revStr[j++]='!';
        }
        revStr[j]='\0';
        
     }

    return revStr;
}
int main(int  argc, char *argv[])
{
    // set the global argc variable (used to determine whether or not to print certain feedback to stderr)
    gargc=argc;

    // check the number of arguments and do something appropriate 
    switch(argc)
    {
    case 1:
        // list the available devices
        list_devices();
        return (0);

    case 2:
        if (strcasecmp(argv[1], APP_SHOW_VERSION_STRING) == 0)
        {
            // print standard version info
            // this option is not a CUPS-standard option, but perhaps it should be
            fprintf(stdout, "%s %s (r%s)\nCopyright (C) 2003-2008 Tyler Blessing.\nThis program comes with NO WARRANTY, to the extent permitted by law.\n\n", APP_NAME_STRING, APP_VERSION_NUMBER_STRING, revStr());

            return 0;
        }
        else if (strcasecmp(argv[1], APP_SHOW_DEVICE_IDS_STRING) == 0)
        {
            list_device_IDs();
            return 0;
        }
        break;
    case 4:
        // send a command to the device and redirect any response to stdout (the utility usage)
        if (strcasecmp(argv[1], APP_AS_UTILITY) == 0)
        {
            return openDeviceOpenReadStream(argv[2], argv[3], 1);
        }
        break;

    case 6:
        // print the data from stdin (the normal usage)
        return openDeviceOpenReadStream(argv[0], NULL, 1);

    case 7:;
        // print the file provided on the command line
        int copies = (int)strtol(argv[4], (char **)NULL, 10);
        return openDeviceOpenReadStream(argv[0], argv[6], copies);

    default:
        break;
    }

    // for all other conditions print the recommended standard usage and return error
    const char * usage = "\
Standard usage: device-URI job-id user title copies options [file]\n\
Alternate usage: %s [ %s | %s ]\n\
 (no arguments)  -->  List each available USB printer, as follows: \n\
connection-type device-URI \"device description\" \"device model\"\n\
 %s       -->  Show version and copyright information;\n\
 %s -->  List device IDs for the available USB printers;\n\
Printer utility usage: %s %s device-URI file\n\
 %s       -->  Send remote commands in file [use \"-\" for stdin] to the\n\
                      printer at device-URI ... receive any response on stdout;\n";
    
    fprintf(stderr, usage, APP_NAME_STRING, APP_SHOW_VERSION_STRING, APP_SHOW_DEVICE_IDS_STRING, APP_SHOW_VERSION_STRING, APP_SHOW_DEVICE_IDS_STRING, APP_NAME_STRING, APP_AS_UTILITY, APP_AS_UTILITY);
    return (1);
}


// create a list of any available USB printers and print the list to stdout
int performFunctionOnDeviceID(void (*function)(CFStringRef))
{
    // this function gets a dict of deviceID and performs the arg function with each deviceID as its arg.
    // the return value is the number of deviceIDs processed. The function passed as the arg to this function
    // MUST be able to handle a NULL argument.
    
    int                     i=0;                    // loop counter
    CFMutableDictionaryRef  deviceIDDict=NULL;      // CFDictionary for storing device IDs

    // create a dictionary of deviceIDs for any available devices.
    // This function returns a dictionary with pointers to valid device
    // interfaceInterface objects as member values and deviceIDs as member keys.
    // Before releasing the returned dictionary with CFRelease() you MUST call
    // CFDictionaryApplyFunction(deviceIDDict, applyToValueIUnknownRelease, NULL)
    // to release the interfaceInterface objects!
    deviceIDDictionaryCreate(&deviceIDDict);
    
    // check for any valid deviceIDs in the return dict
    if (deviceIDDict != NULL)
    {
        CFIndex     dictCount = CFDictionaryGetCount(deviceIDDict);
        CFTypeRef   *allKeys;
        CFStringRef deviceIDString;
		
        // allocate an array of all keys in the dict
        // the keys are the deviceIDs
        allKeys = malloc(dictCount * sizeof(CFTypeRef *));
        if (NULL != allKeys)
        {
            CFDictionaryGetKeysAndValues(deviceIDDict, allKeys, NULL);
            
            for(i=0; i<dictCount; i++)
            {
                // list uri for each deviceID
                deviceIDString=allKeys[i];
                if (deviceIDString)
                {
                    // now call the passed in function with the deviceID as the arg
                    function(deviceIDString);
                }
            }

            free(allKeys);
        }
        else
        {
            fprintf(stderr, "ERROR: Unable to allocate memory in performFunctionOnDeviceID()");
        }
        
        // now release all interfaceInterface objects in the dict
        // (we no longer need to do this ... CFDict takes care of it with custom callbacks)
//        CFDictionaryApplyFunction(deviceIDDict, applyToValueIUnknownRelease, NULL);
        // and rememeber to release the dict
        CFRelease(deviceIDDict);
    }
    return i;
}
void printURIForDeviceID(CFStringRef deviceIDString)
{
    CFStringRef deviceURI=NULL;
    CFStringRef deviceDescription=NULL;
    CFStringRef deviceModel=NULL;
    CFStringRef unknownStr=CFSTR("Unknown");
    CFStringRef printableURI;

    // decode the deviceID and create CFStrings ...
    decodeDeviceIDCreate(deviceIDString, &deviceURI, &deviceDescription, NULL, &deviceModel);

    //format the string properly for output
    printableURI=CFStringCreateWithFormat(NULL, NULL, CFSTR("direct %@ \"%@\" \"%@\""), deviceURI ? deviceURI:unknownStr, deviceDescription ? deviceDescription:unknownStr, deviceModel ? deviceModel:unknownStr );

    putCFString(printableURI);  // putCFString(NULL) does the right thing ...

    DESTROY_CFTypeRef(printableURI);
    DESTROY_CFTypeRef(deviceURI);
    DESTROY_CFTypeRef(deviceDescription);
    DESTROY_CFTypeRef(deviceModel);

}
void printDeviceID(CFStringRef deviceIDString)
{
    static int deviceNumber=0;
    if (0 == deviceNumber)
        puts("### IEEE-1284-compatible device ID strings");

    printf("### Device number %d:\n", ++deviceNumber);
    putCFString(deviceIDString);    // putCFString(NULL) does the right thing ...
}
void list_devices(void)
{
    // emulate Apple behavior and print the "unknown" string even when we find valid devices
    printf("direct %s \"Unknown\" \"USB Printer (%s)\"\n", APP_NAME_STRING, APP_NAME_STRING);

    performFunctionOnDeviceID(printURIForDeviceID);
}
void list_device_IDs(void)
{
    if (0 == performFunctionOnDeviceID(printDeviceID))
        printf("No USB printing devices.\n");        
}
#pragma mark -
#pragma mark utility functions
void fputCFString(CFStringRef theString, FILE *stream)
{
    if (NULL == theString)
    {
        fputs(NULL_STRING, stream);
        return;
    }
    
    CFStringEncoding encoding = kCFStringEncodingUTF8;
    
    const char * stringPtr = CFStringGetCStringPtr(theString, encoding);
    if (NULL == stringPtr)
    {
        size_t mSize = (1 + CFStringGetLength(theString));
        char * mallocdString = malloc(mSize);
        if (mallocdString)
        {
            if (CFStringGetCString(theString, mallocdString, (CFIndex)mSize, encoding))
                fputs(mallocdString, stream);
            free(mallocdString);
        }
    }
    else
        fputs(stringPtr, stream);
}
void putCFString(CFStringRef theString)
{
    CFStringRef termString = CFStringCreateWithFormat(NULL, NULL, CFSTR("%@\n"), theString);
    if(termString)
    {
        fputCFString(termString, stdout);
        CFRelease(termString);
    }
}
CFStringRef TBCFStringCreateSubstringFromPrefixToTerminatorWithOptions(CFStringRef str, CFStringRef prefixStr, CFStringRef termString, CFOptionFlags searchOptions, Boolean inclusive)
{
    // creates a new CFStringRef containing the desired substring of str.
    // If prefixStr is NULL then substring starts at the start of str;
    // if termString is NULL the substring ends at the end of str;
    // if both are NULL then substring is returned as a copy of str
    // This function returns NULL if str is NULL, or if either of the markers,
    // prefixStr or termString, is both not NULL and not found in str.
    
    // searchOptions are as in CFStringFindWithOptions
    // if YES==inclusive then prefixStr and termString are returned as a part of substring
    
    // verify the arguments
    if (NULL==str)
        return NULL;
        
    CFStringRef subString=NULL;
    CFIndex strLength=CFStringGetLength(str);
    CFRange searchRange={0,strLength};
    CFRange valueRange=searchRange;

    if (prefixStr)
    {
        if (CFStringFindWithOptions(str, prefixStr, searchRange, searchOptions, &searchRange))
        {
            // set the correct range location for the substring value
            // the inclusive flag determines whether substring contains the prefix and terminator
            valueRange.location = searchRange.location + (inclusive ? 0 : searchRange.length);
            valueRange.length = strLength - valueRange.location;
            // reset the searchRange for the term (never search for the terminator inside the prefix)
            searchRange.location = searchRange.location + searchRange.length;
            searchRange.length = strLength - searchRange.location;
        }
        else
            return NULL;
    }
    if (termString)
    {
        if (CFStringFindWithOptions(str, termString, searchRange, searchOptions, &searchRange))
        {
            // set the correct range length for the substring value
            valueRange.length = searchRange.location - valueRange.location + (inclusive ? searchRange.length : 0);
        }
        else
            return NULL;
    }

    // and finally, create the new string from the substring
    if (0 <= valueRange.location && (strLength - valueRange.location) >= valueRange.length)
    {
        subString = CFStringCreateWithSubstring(kCFAllocatorDefault, str, valueRange);
    }
    return subString;
}
CFStringRef TBCFStringCreateSubstringFromPrefixToTerminator(CFStringRef str, CFStringRef prefixStr, CFStringRef termString)
{
    return TBCFStringCreateSubstringFromPrefixToTerminatorWithOptions(str, prefixStr, termString, kCFCompareCaseInsensitive, 0);
}
IOReturn usbInterfaceCreateSerialNumberString(IOUSBInterfaceInterface190 **iInterface, CFStringRef *serialNumberString)
{
    // guarantee NULL on failure
    if (serialNumberString && *serialNumberString)
        *serialNumberString=NULL;

    if (NULL==iInterface || NULL == serialNumberString)
        return kIOReturnBadArgument;

    IOReturn ioResult;    
    // get the device serial number string
    CFIndex iManufacturer, iProduct, iSerialNumber;
    // first we need to get the descriptor string index
    if (ioResult = usbInterfaceGetiDeviceIndices(iInterface, &iManufacturer, &iProduct, &iSerialNumber))
    {
        CUPS_DEBUG("usbInterfaceGetiDeviceIndices returned %s [%.8x]\n", strForIOReturn(ioResult), ioResult);
    }
    else if (0 < iSerialNumber && (ioResult = usbInterfaceGetDescriptorStringCopy(iInterface, iSerialNumber, serialNumberString)) )
    {
        // this function will return a valid (albeit truncated) string, if
        // ioResult == kIOReturnOverrun. It should never happen, but check anyway.
        if (kIOReturnOverrun == ioResult)
            fprintf(stderr,"ERROR: usbInterfaceGetDescriptorStringCopy returned a truncated string[%d]\nThis USB device may be out of spec -- proceed with caution.\n", ioResult);
        else
        {
            fprintf(stderr,"ERROR: usbInterfaceGetDescriptorStringCopy returned [%d]\n", ioResult);
            // the error indicates that serialNumberString is not valid
            *serialNumberString=NULL;
        
        }
    }
    
    // at this point we have either a valid or NULL serialNumberString
    // we need to create one if NULL
    // if NULL we will attempt to create one from some other values
    // SERN:(vendorID-ProductID-deviceVersionNumber);"
    if (NULL == *serialNumberString)
    {
        UInt16 vendorID=0, productID=0, deviceVersionNumber=0;
        UInt32 locationID;
        const char *errStr="ERROR: calling %s returned %s\n";
        if (ioResult = (*iInterface)->GetDeviceVendor(iInterface, &vendorID))
            fprintf(stderr, errStr, "GetDeviceVendor", strForIOReturn(ioResult));
        else if (ioResult = (*iInterface)->GetDeviceProduct(iInterface, &productID))
            fprintf(stderr, errStr, "GetDeviceProduct", strForIOReturn(ioResult));
        else if (ioResult = (*iInterface)->GetLocationID(iInterface, &locationID))
            fprintf(stderr, errStr, "GetLocationID", strForIOReturn(ioResult));
        else if (ioResult = (*iInterface)->GetDeviceReleaseNumber(iInterface, &deviceVersionNumber))
            fprintf(stderr, errStr, "GetDeviceReleaseNumber", strForIOReturn(ioResult));
        else
            *serialNumberString = CFStringCreateWithFormat(NULL, NULL, CFSTR("%.4X%.4X%.4X;*LOC:%.8x"), (int)vendorID, (int)productID, (int)deviceVersionNumber,locationID);
    }

    return ioResult;
}
IOReturn decodeDeviceIDCreate(CFStringRef deviceID, CFStringRef *deviceURI, CFStringRef *deviceDescription, CFStringRef *mfg, CFStringRef *MDLStr)
{
    // guarantee that we return a NULL string on failure
    NULLIFY_REF_OF_POINTER(deviceURI);
    NULLIFY_REF_OF_POINTER(deviceDescription);
    NULLIFY_REF_OF_POINTER(mfg);
    NULLIFY_REF_OF_POINTER(MDLStr);

    // verify the arguments
    if (NULL==deviceID || (NULL==deviceURI && NULL==deviceDescription && NULL==mfg && NULL==MDLStr))
        return kIOReturnBadArgument;

    // here is the general strategy: we need the MFG and MDL and SERN to construct the deviceURI
    // So we look for those substrings, which are terminated by the semicolon `;' then we cat everything
    // together and create the CFStrings.

    IOReturn ioResult=kIOReturnSuccess;    
    CFStringRef deviceMFG, deviceMDL, deviceSERN, deviceLOC;
    CFStringRef termString=CFSTR(";"), unknownString=CFSTR("Unknown"), labelString, localDeviceURI;

    deviceMFG = TBCFStringCreateSubstringFromPrefixToTerminator(deviceID, CFSTR("MFG:"), termString);
    if (NULL == deviceMFG)
    {
        deviceMFG = TBCFStringCreateSubstringFromPrefixToTerminator(deviceID, CFSTR("MANUFACTURER:"), termString);
        if (NULL == deviceMFG)
            deviceMFG = CFRetain(unknownString);
    }
    // special case HP printers for uniform PPDs since they are so all over the map with device ID strings
    if (kCFCompareEqualTo == CFStringCompare(deviceMFG, CFSTR("HEWLETT-PACKARD"), kCFCompareCaseInsensitive))
    {
        CFRelease(deviceMFG);
        deviceMFG = CFRetain(CFSTR("HP"));
    }

    deviceMDL = TBCFStringCreateSubstringFromPrefixToTerminator(deviceID, CFSTR("MDL:"), termString);
    if (NULL == deviceMDL)
    {
        deviceMDL = TBCFStringCreateSubstringFromPrefixToTerminator(deviceID, CFSTR("MODEL:"), termString);
        if (NULL == deviceMDL)
            deviceMDL = CFRetain(unknownString);
    }
    
    if (deviceURI)
    {
        deviceLOC = TBCFStringCreateSubstringFromPrefixToTerminator(deviceID, CFSTR("*LOC:"), termString);
        if(NULL==deviceLOC)
        {
            deviceSERN = TBCFStringCreateSubstringFromPrefixToTerminator(deviceID, CFSTR("SERN:"), termString);
        }
        else
        {
            deviceSERN=NULL;
        }
        
        localDeviceURI = CFStringCreateWithFormat(NULL, NULL, CFSTR("%s%@/%@%s%@"), DEVICE_URI_PREFIX, deviceMFG, deviceMDL, deviceSERN ? "?serial=" : "?location=", deviceSERN ? deviceSERN : deviceLOC);
        
        if (localDeviceURI)
        {
            //search for URL illegal chars and replace with % escapes, like `%20' for space ` '
            *deviceURI = CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault, localDeviceURI, NULL, NULL, kCFStringEncodingUTF8);

            DESTROY_CFTypeRef(localDeviceURI);
        }
        DESTROY_CFTypeRef(deviceSERN);
    }    
    
    // if the deviceDescription is requested by the caller try to create it
    if (deviceDescription)
    {
        labelString = CFSTR("DESCRIPTION:");
        *deviceDescription = TBCFStringCreateSubstringFromPrefixToTerminator(deviceID,labelString,termString);
        if (NULL == *deviceDescription)
        {
            // try again
            labelString = CFSTR("DES:");
            *deviceDescription = TBCFStringCreateSubstringFromPrefixToTerminator(deviceID,labelString,termString);

            if (NULL == *deviceDescription)
            {
                // try once more, this time build it from the MFG and MDL substrings
                *deviceDescription = CFStringCreateWithFormat(NULL, NULL, CFSTR("%@ %@"), deviceMFG, deviceMDL);
            }
        }
    }
    
    // release any deviceMFG CFString
    if (mfg)
    {
        *mfg = deviceMFG;
    }
    else
    {
        DESTROY_CFTypeRef(deviceMFG);
    }
    // return or release any deviceMDL CFString
    if (MDLStr)
    {
        *MDLStr = deviceMDL;
    }
    else
    {
        // always enclose macro functions within braces inside if-blocks
        DESTROY_CFTypeRef(deviceMDL);
    }
    
    return ioResult;
}
static kern_return_t usbPrinter_ConvertDeviceIDToPsuedoDeviceID(IOUSBInterfaceInterface190 **interface, CFStringRef *deviceID)
{
    // add convenience substrings to the device-provided 1284-compatible device ID

    // For the purpose of simplifying later parsing tasks, we are adding certain
    // items to the device ID string if they do not exist: we add a "*SERN: ... ;"
    // substring containing the USB device serial number (or, in the case where the
    // device has no serial number, a number fabricated from certain device properties)
    // ... the logic here is to help differentiate devices using deviceURI in the case
    // where more than one device of a certain make/model is connected. In the case
    // where we add data to the device-provided string, we add a leading asterisk to
    // the substring.
        
    // check for NULL arguments
    if (NULL == interface || NULL == deviceID || NULL == *deviceID)
        return kIOReturnBadArgument;
    
    CFStringRef prefixString = CFSTR("SERN:");
    CFStringRef termString = CFSTR(";");
    CFStringRef sernString;
    CFStringRef psuedoDeviceID;
    CFIndex stringLength;
    IOReturn ioResult;
    
    // check for a NULL_STRING device ID and construct one from components, if necessary ...
    if (kCFCompareEqualTo == CFStringCompare(*deviceID, CFSTR(NULL_STRING), 0))
    {
       // right here we need to handle the case where a printer does not return a device ID
        CFIndex iManufacturer, iProduct;
        CFStringRef manufacturerString=NULL;
        CFStringRef productString=NULL;
        CFStringRef unknownString=CFSTR("Unknown");

       // first we need to get the descriptor string index
        if (ioResult = usbInterfaceGetiDeviceIndices(interface, &iManufacturer, &iProduct, NULL))
        {
            CUPS_DEBUG("usbInterfaceGetiDeviceIndices returned %s [%.8x]\n", strForIOReturn(ioResult), ioResult);
        }

        if (0 < iManufacturer)
        {
            ioResult = usbInterfaceGetDescriptorStringCopy(interface, iManufacturer, &manufacturerString);
            if (kIOReturnSuccess != ioResult && NULL != manufacturerString)
            {
                CFRelease(manufacturerString);
                manufacturerString=NULL;
            }
        }
        
        if (0 < iProduct)
        {
            ioResult = usbInterfaceGetDescriptorStringCopy(interface, iProduct, &productString);
            if (kIOReturnSuccess != ioResult && NULL != productString)
            {
                CFRelease(productString);
                productString=NULL;
            }
        }
        ioResult = usbInterfaceCreateSerialNumberString(interface, &sernString);

        CFRelease(*deviceID);

        *deviceID = CFStringCreateWithFormat(NULL, NULL, CFSTR("(null);*MFG:%@;*MDL:%@;*SERN:%@;"), manufacturerString ? :unknownString, productString ? : unknownString, sernString ? : unknownString);

        DESTROY_CFTypeRef(manufacturerString);
        DESTROY_CFTypeRef(productString);
        DESTROY_CFTypeRef(sernString);
                
        return ioResult;
    }

    //scan the deviceID for an existing "SERN:...;" substring
    sernString = TBCFStringCreateSubstringFromPrefixToTerminator(*deviceID, prefixString, termString);
    if (sernString)
    {
        stringLength=CFStringGetLength(sernString);
        CFRelease(sernString);
        if (1 < stringLength)
            return kIOReturnSuccess;
        sernString = NULL;
    }
    ioResult = usbInterfaceCreateSerialNumberString(interface, &sernString);
    
    if (NULL != sernString)
    {
        psuedoDeviceID = CFStringCreateWithFormat(kCFAllocatorDefault, NULL, CFSTR("%@*%@%@%@"), *deviceID, prefixString, sernString, termString);
        if (NULL != psuedoDeviceID)
        {
            CFRelease(*deviceID);
            *deviceID = psuedoDeviceID;
        }
        CFRelease(sernString);
    }
    return ioResult;
}
static kern_return_t usbPrinter_CreateCFStringWithGET_DEVICE_ID(IOUSBInterfaceInterface190 **interface, CFStringRef *deviceID)
{
    // Guarantee we return NULL in case of failure
    if (deviceID && *deviceID)
        *deviceID=NULL;
    
    // check for NULL pointers
    if (NULL == interface || NULL ==deviceID)
        return kIOReturnBadArgument;
    
    // the basic stategy of this function is to query the interface for the device ID, and to return the
    // result in a CFStringRef.

    // we send the initial query to get the length of the string, then we malloc that memory and resend the
    // query to get the actual string.
    
    UInt8               configValue;
    UInt8               interfaceNumber;
    UInt8               alternateIndex;
    UInt16              deviceIDLength;
    kern_return_t       kr;             // the result from a kernal call
    IOUSBDevRequestTO   rq;             // struct for timeout control request

    const char * errString = "ERROR: %s returned %s [%x]\n";
	
    if(kr = (*interface)->GetConfigurationValue(interface, &configValue))
    {
        CUPS_DEBUG("%s returned %s [%x]\n", "GetConfigurationValue()", strForIOReturn(kr), kr);
    }
    else if(kr = (*interface)->GetInterfaceNumber(interface, &interfaceNumber))
    {
        fprintf(stderr, errString, "GetInterfaceNumber()", strForIOReturn(kr), kr);
    }
    else if(kr = (*interface)->GetAlternateSetting(interface, &alternateIndex))
    {
        fprintf(stderr, errString, "GetAlternateSetting()", strForIOReturn(kr), kr);
    }
    else
    {
        // populate a device request structure
        // GET_DEVICE_ID    bRequest = 0
        //                  wValue field is used to specify a zero-based configuration index.
        //rq.bmRequestType =100100001B=161
        rq.bmRequestType = USBmakebmRequestType(kUSBIn, kUSBClass, kUSBInterface);
        // kUSBPrintClassGetDeviceID is defined in this file (or the header) 
        rq.bRequest = kUSBPrintClassGetDeviceID;
        // the USB Device Class Definition for Printing Devices 1.1 states that
        // for the GET_DEVICE_ID class-specific device request "the wValue field
        // is used to specify a zero-based configuration index."
        // Of course, the bConfigurationValue of zero indicates that the device
        // is not configured, thus all valid configuration values must be >= 1.
        // Apparently, printing device manufacturers have interpreted the qualifier
        // "zero-based" to mean that you should take the index of valid configuration
        // values, which starts at 1, (0 being the default "unconfigured" state) and
        // subtract 1 to make it "zero-based". Odd. Very odd indeed.
        rq.wValue = configValue - 1;
        // The high-byte of wIndex is used to specify the zero-based interface index.
        // The low-byte of wIndex is used to specify the zero-based alternate setting.
        rq.wIndex = (interfaceNumber << 8) | alternateIndex;
        rq.wLength = sizeof(deviceIDLength);
        rq.pData = &deviceIDLength;
        rq.completionTimeout = 100;
        rq.noDataTimeout = 100;

        // send the request once to get the size of the return string
        if (kr = (*interface)->ControlRequestTO(interface, (UInt8)0, &rq ))
        {
            if (0 && kIOUSBPipeStalled == kr)
            {

                CUPS_DEBUG("This device appears to not understand a basic request. It may be \n\
   damaged, or simply non-conformant to the USB specification.\n\n\
Hint - try removing any USB hub between the printer and the host computer.\n");
                if (kr = (*interface)->ClearPipeStallBothEnds(interface, 0))
                {
                    usbInterfaceResetUSBDevice(interface);
                }
                else
                    deviceIDLength = CFSwapInt16HostToBig(512);

            }
        }
        if (kIOReturnSuccess == kr)
        {
            // get the result length from the first two bytes
            // use this form to be bi-endian
            deviceIDLength = CFSwapInt16BigToHost(deviceIDLength);
            //CUPS_DEBUG2("Found a %u character device ID ... ", deviceIDLength);
            if (sizeof(deviceIDLength) < deviceIDLength)
            {
                // malloc a buffer to hold the device ID and resend the request
                UInt8 *deviceIDBuffer;
                unsigned bufferSize=deviceIDLength + 1;  //add 1 for terminating NULL
                deviceIDBuffer=malloc(bufferSize);
                if (deviceIDBuffer)
                {
                    // send the request again with the correctly sized buffer
                    rq.wLength = deviceIDLength;
                    rq.pData = deviceIDBuffer;
                    kr = (*interface)->ControlRequestTO(interface, 0, &rq );
                    if ( kIOReturnSuccess == kr && 1 < rq.wLenDone)
                    {
                        // get the size in bi-endian fashion
//                        deviceIDLength = (deviceIDBuffer[0] << 8) | deviceIDBuffer[1];
                        deviceIDLength = CFSwapInt16BigToHost(*(UInt16 *)deviceIDBuffer);
                        // prevent buffer overflow
                        if (deviceIDLength >= bufferSize)
                            deviceIDLength = bufferSize -1;
                        //create the CFStringRef
                        deviceIDBuffer[deviceIDLength]=0;
                        //fprintf(stderr, "\"%s\"\n", &deviceIDBuffer[2]);
                        *deviceID=CFStringCreateWithFormat(kCFAllocatorDefault,NULL,CFSTR("%s"), &deviceIDBuffer[2]);
//                        *deviceID = CFStringCreateWithBytes(kCFAllocatorDefault, &deviceIDBuffer[2], (deviceIDLength - 2), kCFStringEncodingUTF8, 0);
                        if (NULL==*deviceID)
                        {
                            //CUPS_DEBUG2("CFStringCreateWithFormat returned NULL. Now attempting to legalize non-ASCII chars ...\n");
                            // legalize the non-conforming string
                            int i;
                            for(i=2;i < deviceIDLength && deviceIDBuffer[i]; i++)
                            {
                                //replace out of range chars with '*'
                                if (' ' > deviceIDBuffer[i] || '~' < deviceIDBuffer[i])
                                    deviceIDBuffer[i]='*';
                            }
                            deviceIDLength = i - 2;
                            *deviceID = CFStringCreateWithBytes(kCFAllocatorDefault, &deviceIDBuffer[2], deviceIDLength, kCFStringEncodingUTF8, 0);
                            if (NULL==*deviceID)
                            {
                                CUPS_DEBUG2("CFStringCreateWithBytes returned NULL ... bummer\n");
                                *deviceID = CFStringCreateWithFormat(NULL, NULL, CFSTR("Internal failure to create a device ID CFString"));
                            }
                        }
                    }
                    free(deviceIDBuffer);
                    deviceIDBuffer = NULL;
                }
            }
            else
            {
                // right here we need to handle the case where a printer does not return a device ID
                *deviceID = CFStringCreateWithFormat(NULL, NULL, CFSTR(NULL_STRING));
            }
        }
    }
    return kr;
}
const void * iUnknownRetainCallBack(CFAllocatorRef allocator,  const void *value)
{
    if (value)
    {
        (*(IUnknownVTbl **)value)->AddRef((IUnknownVTbl **)value);
    }
    return value;
//    
//    IUnknownVTbl ** unknown = (IUnknownVTbl **)value;
//    if (unknown != NULL)
//    {
//        (*unknown)->AddRef(unknown);
//    }
//    return unknown;
}
void iUnknownReleaseCallBack(CFAllocatorRef allocator,  const void *value)
{
    if (value)
    {
        (*(IUnknownVTbl **)value)->Release((IUnknownVTbl **)value);
    }
//    IUnknownVTbl ** unknown = (IUnknownVTbl ** )value;
//    if (unknown != NULL)
//    {
//        (*unknown)->Release(unknown);
//        unknown=NULL;
//    }
}
int matchDevice(CFStringRef deviceIDString, TBUSBInterfaceContext * tbContext)
{
    if(NULL == deviceIDString || NULL == tbContext || TB_VALID_CONTEXT_KEY != tbContext->validator || NULL == tbContext->deviceURIString)
    {
        CUPS_DEBUG("bad context argument in %s\n", __func__);
        return 0;
    }
    
    CFStringRef deviceURI = NULL;
    CFStringRef sstr = NULL;
    CFStringRef matchDeviceURI = CFRetain(tbContext->deviceURIString);
    int match = 0;
    CFRange shortRange;
    CFIndex slen = CFStringGetLength(CFSTR("usb://"));
    
    // check for a "usb://..." device uri
    if (CFStringCompareWithOptions(matchDeviceURI, CFSTR("usb://"), CFRangeMake(0,slen), 0) == kCFCompareEqualTo)
    {
        CUPS_DEBUG("matching to a usb://... device uri\n");
        //rewrite to usbtb://...
        sstr = CFStringCreateWithSubstring(NULL, matchDeviceURI, CFRangeMake(slen,CFStringGetLength(matchDeviceURI)-slen));
        CFRelease(matchDeviceURI);
        matchDeviceURI = CFStringCreateWithFormat(NULL, NULL, CFSTR(DEVICE_URI_PREFIX"%@"), sstr);
        DESTROY_CFTypeRef(sstr);
    }
    
    // decode the deviceURI from the IEEE 1284 deviceID
    decodeDeviceIDCreate(deviceIDString, &deviceURI, NULL, NULL, NULL);
    if (deviceURI)
    {
        // strip any inline whitespace from weirdo devices
        if(CFStringFindWithOptions(deviceURI, CFSTR("%20"), CFRangeMake(0,CFStringGetLength(deviceURI)), 0, NULL) && !CFStringFindWithOptions(matchDeviceURI, CFSTR("%20"), CFRangeMake(0,CFStringGetLength(matchDeviceURI)), 0, NULL))
        {
            CFArrayRef arrays = CFStringCreateArrayBySeparatingStrings(NULL, deviceURI, CFSTR("%20"));
            DESTROY_CFTypeRef(deviceURI);
            deviceURI = CFStringCreateByCombiningStrings(NULL, arrays, CFSTR(""));
            DESTROY_CFTypeRef(arrays);
        }

        //compare the deviceURI calculated from the deviceIDString with the one passed in argv[0]
        CUPS_DEBUG("Comparing input deviceURI ");
        fputCFString(matchDeviceURI, stderr);
        fputs(" ... \n", stderr);
        CUPS_DEBUG("with calculated deviceURI ");
        fputCFString(deviceURI, stderr);
        fputs("\n", stderr);
        if (CFStringCompareWithOptions(matchDeviceURI, deviceURI, CFRangeMake(0,CFStringGetLength(deviceURI)), 0) == kCFCompareEqualTo)
        {
            // we have a match
            match = 1;
        }
        else
        {
            match = 0;
            
            // look for a partial match at a different location
            shortRange = CFStringFind(deviceURI, CFSTR("?location="), 0);
            if(0 < shortRange.length)
            {
                // we need to create a substring and use that to match against
                shortRange.length = shortRange.location;
                shortRange.location = 0;
                sstr = CFStringCreateWithSubstring(NULL, deviceURI, shortRange);
                if(kCFCompareEqualTo == CFStringCompareWithOptions(matchDeviceURI, sstr, shortRange, kCFCompareAnchored))
                {
                    match = 2;
                }
                DESTROY_CFTypeRef(sstr);
            }
        }
        DESTROY_CFTypeRef(deviceURI);
    }
    DESTROY_CFTypeRef(matchDeviceURI);
    return match;
}
int iterateForDevices(io_iterator_t matchedInterfaceIter, TBUSBInterfaceContext * tbContext)
{
    // we have a valid iterator -- use it to find any matching IOService objects.
    kern_return_t           err;
    io_service_t            interfaceObject;
    int match=0;
    int bestMatch=0;
        
    while (1 != match && (interfaceObject = IOIteratorNext(matchedInterfaceIter)))
    {
        IOCFPlugInInterface             **plugInInterface = NULL;
        IOUSBInterfaceInterface190	**interfaceInterface = NULL;
        SInt32 score;
        UInt8 deviceClass;
        UInt8 deviceSubClass;
        CFStringRef deviceIDString = NULL;
        
        // get a CFPlugIn interface for this io_service_t object
        if ( err = IOCreatePlugInInterfaceForService(interfaceObject, kIOUSBInterfaceUserClientTypeID, kIOCFPlugInInterfaceID, &plugInInterface, &score) )
            fprintf(stderr, "ERROR: IOCreatePlugInInterfaceForService() returned [%d]\n",err);

        // now get the appropriate InterfaceInterface from the plugin
        if (plugInInterface != NULL)
            err=(*plugInInterface)->QueryInterface(plugInInterface, CFUUIDGetUUIDBytes(kIOUSBInterfaceInterfaceID190), (LPVOID) &interfaceInterface );

        // test the returned InterfaceInterface
        if (interfaceInterface == NULL)
            fprintf(stderr, "ERROR: QueryInterface() returned [%d]\n",err);
        else if( err=(*interfaceInterface)->GetInterfaceClass(interfaceInterface, &deviceClass) )
            CUPS_ERROR("GetInterfaceClass() returned [%d]\n",err);
        else if ( err=(*interfaceInterface)->GetInterfaceSubClass(interfaceInterface, &deviceSubClass) )
            CUPS_ERROR("GetInterfaceSubClass() returned [%d]\n",err);
        else if (deviceClass == kUSBPrintingClass && deviceSubClass == kUSBPrintingSubclass)// kUSBPrintingSubClass
        {
            // if we made it here through all the preceeding tests then we have
            // a valid InterfaceInterface to a USB printing class device
            int retry=0;    // the number of times to retry the request after an initial failure
            while ((err = usbPrinter_CreateCFStringWithGET_DEVICE_ID(interfaceInterface, &deviceIDString)) && 0 < retry--)
            {
                CUPS_DEBUG("Failed GetDeviceID request with error: %s [%x].\n", strForIOReturn(err), err);
                CUPS_DEBUG("Failed to get a device ID from this printer; will try again %d more time%s\n", retry+1, retry?"s":"");
            }
            if (NULL == deviceIDString)
            {
                // some "USB printing devices" are really lame: they do not follow the USB printing device specification.
                // but they still seem to print. So see if we can get the make and model strings to create a primitive
                // device ID.
                deviceIDString=CFRetain(CFSTR(NULL_STRING));
            }
            if (deviceIDString)
            {
                // check if we are just printing the raw device ID
                if (2 != gargc)
                    usbPrinter_ConvertDeviceIDToPsuedoDeviceID(interfaceInterface, &deviceIDString);

                // try to match the device to 
                if(match = matchDevice(deviceIDString, tbContext))
                {
                    CUPS_DEBUG("%s match for device %.8x with deviceID ",(1 == match ? "Full":"Partial"),interfaceObject);
                    fputCFString(deviceIDString, stderr);
                    fputs("\n", stderr);

                    bestMatch = match;
                    //retain the interface
                    if (NULL != tbContext->interface)
                    {
                        (*tbContext->interface)->Release(tbContext->interface);
                    }
                    tbContext->interface = interfaceInterface;
                    (*tbContext->interface)->AddRef(tbContext->interface);
                    DESTROY_CFTypeRef(tbContext->deviceIDString);
                    tbContext->deviceIDString = CFRetain(deviceIDString);
                    tbContext->deviceObject = interfaceObject;//
                    if(err = IOObjectRetain(tbContext->deviceObject))
                    {
                        CUPS_ERROR("IOObjectRetain() returned %s [%.8x] in %s at line %d\n",strForIOReturn(err),err,__func__,__LINE__);
                    }

                    //get the vendor and product id to use for device removal notification
                    if ( err=(*interfaceInterface)->GetDeviceVendor(interfaceInterface, &tbContext->idVendor) )
                    {
                        CUPS_ERROR("GetDeviceVendor() returned %s [%.8x]\n",strForIOReturn(err),err);
                    }
                    if ( err=(*interfaceInterface)->GetDeviceProduct(interfaceInterface, &tbContext->idProduct) )
                    {
                        CUPS_ERROR("GetDeviceProduct() returned %s [%.8x]\n",strForIOReturn(err),err);
                    }
                }
                else
                {
                    CUPS_DEBUG("did not match device %.8x with deviceID ",interfaceObject);
                    fputCFString(deviceIDString, stderr);
                    fputs("\n", stderr);
                }
                
                CFRelease(deviceIDString);
            }
            else
                CUPS_ERROR("Failed to get DeviceID for this printing device [%s].\n",strForIOReturn(err));
        }
        else if (kUSBPrintingClass == deviceClass)
            CUPS_DEBUG2("Found a device that is a printer by class, but not by subclass; subClass=%d\n",  deviceSubClass);


        // we're done with the iterator object interfaces now -- release them.
        if (plugInInterface != NULL)
        {
            //err=IODestroyPlugInInterface(plugInInterface);
            (*plugInInterface)->Release(plugInInterface);
            plugInInterface=NULL;
        }
        if (interfaceInterface != NULL)
        {
            (*interfaceInterface)->Release(interfaceInterface);
            interfaceInterface=NULL;
        }
        IOObjectRelease(interfaceObject);
    }

    return bestMatch;
}
static void deviceIDDictionaryCreate(CFMutableDictionaryRef *deviceIDDict)
{
    // This function returns a dictionary with pointers to valid device
    // IOUSBInterfaceInterface190 objects (stored as CFNumberRefs) as member values
    // and deviceIDs (stored as CFStrings) as member keys.
    //
    // Before releasing the returned dictionary with CFRelease() you MUST call
    // CFDictionaryApplyFunction(deviceIDDict, applyToValueIUnknownRelease, NULL)
    // to release the interfaceInterface objects!
    // This function is guaranteed to return NULL on failure or if no devices exist.
    kern_return_t           err;
    io_service_t            interfaceObject;
    io_iterator_t           matchedInterfaceIter = 0;
    CFMutableDictionaryRef  matchingDict;

    // guarantee that we return a NULL dict on failure
    if(deviceIDDict && *deviceIDDict)
    {
        fprintf(stderr,"WARNING: You may be leaking memory by passing a pointer to an alloc'd dictionary into deviceIDDictionaryCreate.\n");
        *deviceIDDict=NULL;
    }
    // validate the argument
    if (NULL == deviceIDDict)
    {
        fprintf(stderr,"ERROR: Bad argument for deviceIDDictionaryCreate(NULL!).\n");
        return;
    }
    
    // create a matching dictionary for class kIOUSBInterfaceClassName
    // IOServiceGetMatchingServices() consumes a reference so we don't release it
    matchingDict = IOServiceMatching(kIOUSBInterfaceClassName);
    if (!matchingDict)
    {
        fprintf(stderr,"ERROR: failed to create a USB matching dictionary\n");
        return;
    }

    // Get an iterator for IOService objects that match the dictionary
    err=IOServiceGetMatchingServices(kIOMasterPortDefault, matchingDict, &matchedInterfaceIter);
    if (0 == matchedInterfaceIter || err)
    {
        // we will drop in here if there are no USB devices
        // so we don't want to print an error but just fail silently
        //fprintf(stderr,"ERROR:Failed to create an IOServices matching iterator.\n");
        return;        
    }
    // we have a valid iterator -- use it to find any matching IOService objects.
        
    while (interfaceObject = IOIteratorNext(matchedInterfaceIter))
    {
        IOCFPlugInInterface             **plugInInterface = NULL;
        IOUSBInterfaceInterface190	**interfaceInterface = NULL;
        SInt32 score;
        UInt8 deviceClass;
        UInt8 deviceSubClass;
        
        // get a CFPlugIn interface for this io_service_t object
        if ( err = IOCreatePlugInInterfaceForService(interfaceObject, kIOUSBInterfaceUserClientTypeID, kIOCFPlugInInterfaceID, &plugInInterface, &score) )
            fprintf(stderr, "ERROR: IOCreatePlugInInterfaceForService() returned [%d]\n",err);

        // now get the appropriate InterfaceInterface from the plugin
        if (plugInInterface != NULL)
            err=(*plugInInterface)->QueryInterface(plugInInterface, CFUUIDGetUUIDBytes(kIOUSBInterfaceInterfaceID190), (LPVOID) &interfaceInterface );

        // test the returned InterfaceInterface
        if (interfaceInterface == NULL)
            fprintf(stderr, "ERROR: QueryInterface() returned [%d]\n",err);
        else if( err=(*interfaceInterface)->GetInterfaceClass(interfaceInterface, &deviceClass) )
            CUPS_ERROR("GetInterfaceClass() returned [%d]\n",err);
        else if ( err=(*interfaceInterface)->GetInterfaceSubClass(interfaceInterface, &deviceSubClass) )
            CUPS_ERROR("GetInterfaceSubClass() returned [%d]\n",err);
        else if (deviceClass == kUSBPrintingClass && deviceSubClass == kUSBPrintingSubclass)// kUSBPrintingSubClass
        {
            // if we made it here through all the preceeding tests then we have
            // a valid InterfaceInterface to a USB printing class device
            CFStringRef deviceIDString = NULL;
            int retry=0;    // the number of times to retry the request after an initial failure
            while ((err = usbPrinter_CreateCFStringWithGET_DEVICE_ID(interfaceInterface, &deviceIDString)) && 0 < retry--)
            {
                CUPS_DEBUG("Failed GetDeviceID request with error: %s [%x].\n", strForIOReturn(err), err);
                CUPS_DEBUG("Failed to get a device ID from this printer; will try again %d more time%s\n", retry+1, retry?"s":"");
            }
            if (NULL == deviceIDString)
            {
                // some "USB printing devices" are really lame: they do not follow the USB printing device specification.
                // but they still seem to print. So see if we can get the make and model strings to create a primitive
                // device ID.
                deviceIDString=CFRetain(CFSTR(NULL_STRING));
            }
            if (deviceIDString)
            {
                // check if we are just printing the raw device ID
                if (2 != gargc)
                    usbPrinter_ConvertDeviceIDToPsuedoDeviceID(interfaceInterface, &deviceIDString);

                // add the deviceIDString to the return dict
                if (*deviceIDDict == NULL)
                {
                    CFDictionaryValueCallBacks iUnknownPointerCallBacks = {0, iUnknownRetainCallBack, iUnknownReleaseCallBack, NULL, NULL};
                    // allocate the dictionary the first time we need it
                    // this dictionary must be released by the calling function
                    // using CFRelease()
                    *deviceIDDict=CFDictionaryCreateMutable(NULL,0, &kCFTypeDictionaryKeyCallBacks, &iUnknownPointerCallBacks);
                    if (*deviceIDDict == NULL)
                    {
                        // dictionary creation failed
                        CUPS_ERROR("Unable to allocate memory for dictionary creation in deviceIDDictionaryCreate()\n");

                        return;
                    }
                }
                // store the deviceID as the key to this device's interfaceInterface
                CFDictionarySetValue(*deviceIDDict, deviceIDString, (const void *)interfaceInterface);
                // the deviceIDString has been retained by the dict so release it
                CFRelease(deviceIDString);
            }
            else
                CUPS_ERROR("Failed to get DeviceID for this printing device [%s].\n",strForIOReturn(err));
        }
        else if (kUSBPrintingClass == deviceClass)
            CUPS_DEBUG2("Found a device that is a printer by class, but not by subclass; subClass=%d\n",  deviceSubClass);


        // we're done with the iterator object interfaces now -- release them.
        if (plugInInterface != NULL)
        {
            //err=IODestroyPlugInInterface(plugInInterface);
            (*plugInInterface)->Release(plugInInterface);
            plugInInterface=NULL;
        }
        if (interfaceInterface != NULL)
        {
            (*interfaceInterface)->Release(interfaceInterface);
            interfaceInterface=NULL;
        }
        IOObjectRelease(interfaceObject);
    }
    // release the iterator
    IOObjectRelease(matchedInterfaceIter);
}
IOReturn createTimerWithIntervalAndFireDate(CFRunLoopTimerRef * timer, CFTimeInterval interval, CFAbsoluteTime fireDate, void * callback, void *refcon)
{
    if(NULL == timer)
    {
        return kIOReturnBadArgument;
    }
    
    CFRunLoopTimerRef       newTimer = *timer;
    CFRunLoopTimerContext   timerContext;
    IOReturn                ioResult = kIOReturnError;


    // check for an existing writeCompletionTimer
    if(NULL != newTimer)
    {
        // if the existing timer is still valid then just reset the next firedate
        // invalidate any existing timer 
        if (CFRunLoopTimerIsValid(newTimer))
        {
            CFRunLoopTimerInvalidate(newTimer);
        }
        // release any previous writeCompletionTimer 
        CFRelease(newTimer);
    }
	
    // create a new timer
    // init the CFRunLoopTimerContext for this timer
    timerContext.info = refcon;
    timerContext.version = 0;
    timerContext.retain = NULL;
    timerContext.release = NULL;
    timerContext.copyDescription = NULL;


    newTimer = CFRunLoopTimerCreate(NULL, fireDate, interval, 0, 0, callback, &timerContext );
    
    // validate the new timer
    if (NULL != newTimer)
    {
        if (CFRunLoopTimerIsValid(newTimer))
        {
            // add it to the runloop
            CFRunLoopAddTimer (CFRunLoopGetCurrent(), newTimer, kCFRunLoopCommonModes);
            ioResult = kIOReturnSuccess;
        }
        else
        {
            // somehow we created an invalid timer; release it
            CFRelease(newTimer);
            newTimer = NULL;
        }
    }
    *timer = newTimer;
    return ioResult;
}
static kern_return_t usbInterfaceGetConfigurationDescriptor( IOUSBInterfaceInterface190 **iInterface,  UInt8 *interfaceNumber, UInt8 *interfaceAlternate)
{
     // check for NULL pointers
    if (NULL == iInterface)
        return kIOReturnBadArgument;
        
    IOReturn            kr;     //(int) the result from a kernal call
    IOUSBDevRequestTO   rq;     //Parameter block for control requests with timeouts
    UInt8               configValue;
    UInt8               buffer[kMallocQuantumSize];
    
    kr = (*iInterface)->GetConfigurationValue(iInterface, &configValue);
    if ( kr != kIOReturnSuccess )
    {
        fprintf(stderr,"ERROR: failed to get configuration value.\n");
        return kr;
    }
    
    // populate a device request structure
    // GET_DESCRIPTOR   bRequest = kUSBRqGetDescriptor=6
    //  wValue field specifies the descriptor type (CONFIGURATION=2) in
    // the high byte, and the descriptor index in the low byte.
    // rq.bmRequestType = kGetDescriptor;
    //  The wIndex field specifies the Language ID for string descriptor
    
    // bmRequestType = 100000000B=128
    rq.bmRequestType = USBmakebmRequestType(kUSBIn, kUSBStandard, kUSBDevice);
    // defined in this file 
    rq.bRequest = kUSBRqGetDescriptor;
    rq.wValue = (kUSBConfDesc << 8) | configValue;
    rq.wIndex = 0; //returns an array of language IDs.
    rq.wLength = sizeof(buffer);
    rq.pData = buffer;
    rq.completionTimeout = 100;
    rq.noDataTimeout = 100;
    CUPS_DEBUG("getting configuration descriptor for configuration number %d\n",configValue);
    // send the request once to get the total return length
    kr = (*iInterface)->ControlRequestTO(iInterface, kUSBdefaultControlPipe, &rq );
    if ( kr == kIOReturnSuccess && 3 < rq.wLenDone && kUSBConfDesc==buffer[1])
    {
        // per the spec, get the total result length from bytes 2 and 3 (the third and fourth bytes)
        // use this form to be bi-endian
        //unsigned resultLength = CFSwapInt16LittleToHost(*(UInt16 *)&buffer[2]);
        //unsigned resultLength = (buffer[2] + (buffer[3] * 256));
        unsigned resultLength = buffer[2] | (buffer[3] << 8);
        if (resultLength > sizeof(buffer))
        {
            // malloc cStringbuffer to the byte aligned size
            UInt8 *descriptorBuffer;
            size_t remainder;
            size_t blockSize=(resultLength)*sizeof(*descriptorBuffer);
            if (remainder=(blockSize % kMallocQuantumSize))
                blockSize += (kMallocQuantumSize - remainder);
            descriptorBuffer=malloc(blockSize);
            while (descriptorBuffer)
            {
                // send the request again with the correctly sized buffer
                rq.wLength = blockSize;
                rq.pData = descriptorBuffer;
                kr = (*iInterface)->ControlRequestTO(iInterface, kUSBdefaultControlPipe, &rq );
                if ( kr == kIOReturnSuccess && 3 < rq.wLenDone && kUSBConfDesc==buffer[1])
                {
                    UInt8 numInterfaces,cnfgStringIndex,numEndpoints,intfStringIndex;
                    CFStringRef configString=NULL;
                    UInt8 *endptr, *resultptr=descriptorBuffer;
                    IOUSBConfigurationDescriptorPtr configDescriptorptr= (IOUSBConfigurationDescriptorPtr)resultptr;
                    //resultLength = *(resultptr+2) + (*(resultptr+3) * 256);
                    resultLength=CFSwapInt16LittleToHost(configDescriptorptr->wTotalLength);
                    endptr=resultLength + descriptorBuffer;
                    numInterfaces=configDescriptorptr->bNumInterfaces;
                    cnfgStringIndex=configDescriptorptr->iConfiguration;
                    CUPS_DEBUG2("examining configuration descriptor for config number [%d]; \n", configDescriptorptr->bConfigurationValue);
                    CUPS_DEBUG2("\t number of interfaces = %d\n", numInterfaces);

                    if (cnfgStringIndex)
                    {
                        usbInterfaceGetDescriptorStringCopy(iInterface, cnfgStringIndex, &configString);
                        if (configString)
                        {
                            CUPS_DEBUG2("configuration string: ");
                            fputCFString(configString, stderr);
                            fputs("\n", stderr);
                        }
                    }
                    for(resultptr += *resultptr;resultptr < endptr;)
                    {
                        IOUSBInterfaceDescriptorPtr intfcDescriptorptr = (IOUSBInterfaceDescriptorPtr) resultptr;
                        numEndpoints=intfcDescriptorptr->bNumEndpoints;
                        CUPS_DEBUG2("examining interface descriptor for interface number [%d], alternate [%d]; \n", intfcDescriptorptr->bInterfaceNumber, intfcDescriptorptr->bAlternateSetting);
                        CUPS_DEBUG2("\t number of endpoints = %d\n", numEndpoints);
                        CUPS_DEBUG2("\t Interface Class = %d\n", intfcDescriptorptr->bInterfaceClass);
                        CUPS_DEBUG2("\t Interface subClass = %d\n", intfcDescriptorptr->bInterfaceSubClass);
                        CUPS_DEBUG2("\t Interface protocol = %d\n", intfcDescriptorptr->bInterfaceProtocol);
                        if (kUSBPrintingClass == intfcDescriptorptr->bInterfaceClass && kUSBPrintingSubclass == intfcDescriptorptr->bInterfaceSubClass && 2 == intfcDescriptorptr->bInterfaceProtocol && 2==numEndpoints)
                        {
                            *interfaceNumber=intfcDescriptorptr->bInterfaceNumber;
                            *interfaceAlternate=intfcDescriptorptr->bAlternateSetting;
                        }
                        intfStringIndex=intfcDescriptorptr->iInterface;
                        for (resultptr+=*resultptr;0 < numEndpoints && resultptr < endptr;numEndpoints--)
                        {
                            //IOUSBEndpointDescriptorPtr endptDescriptorptr = (IOUSBEndpointDescriptorPtr)resultptr;
                            // advance resultptr to the next descriptor
                            resultptr += *resultptr;
                        }
                        // check for bad descriptor
                        if (0 == *resultptr)
                            break;
                    }
                    DESTROY_CFTypeRef(configString);
                }
                break;
            }
            // free the malloc'd memory
            if (descriptorBuffer)
            {
                free(descriptorBuffer);
                descriptorBuffer=NULL;
            }
            else
                kr=kIOReturnNoMemory;                
        }
    }
    return kr;
}        
static kern_return_t usbInterfaceGetiDeviceIndices( IOUSBInterfaceInterface190 **interfaceInterface, CFIndex *iManufacturer, CFIndex *iProduct, CFIndex *iSerialNumber)
{
    // check for NULL pointers
    if (NULL == interfaceInterface)
        return kIOReturnBadArgument;

    IOUSBDeviceDescriptor   dDescriptor;
    IOReturn                ioResult;
    
    ioResult = usbInterfaceGetDeviceDescriptor(interfaceInterface, &dDescriptor, sizeof(dDescriptor));

    // make sure we don't dereference NULL pointers
    if (NULL != iManufacturer)
    {
        if (kIOReturnSuccess == ioResult)
            *iManufacturer=dDescriptor.iManufacturer;
        else
            *iManufacturer=0;
    }
    if (NULL != iProduct)
    {
        if (kIOReturnSuccess == ioResult)
            *iProduct=dDescriptor.iProduct;
        else
            *iProduct=0;
    }
    if (NULL != iSerialNumber)
    {
        if (kIOReturnSuccess == ioResult)
            *iSerialNumber=dDescriptor.iSerialNumber;
        else
            *iSerialNumber=0;
    }

    return ioResult;
}        
static kern_return_t usbInterfaceGetDescriptorStringCopy(IOUSBInterfaceInterface190 **interfaceInterface, CFIndex stringIndex, CFStringRef *descriptorString)
{
    // check for NULL pointers
    if (NULL == interfaceInterface || NULL == descriptorString || 0 == stringIndex)
    {
        CUPS_ERROR("Passed a NULL pointer or zero index into usbInterfaceGetDescriptorStringCopy.\n");
        
        return kIOReturnBadArgument;
    }
            
    // This function gets the descriptor string at index `stringIndex' and returns it
    // in as a CFStringRef in `descriptorString'
    UInt8               buffer[256];
    kern_return_t       kr;     //(int) the result from a kernal call
    IOUSBDevRequestTO   rq;     //Parameter block for control requests with timeouts
    int                 i,j, langIDCount;
	
    // set descriptorString value to NULL in case of failure
    if (*descriptorString)
        *descriptorString=NULL;
    
    // populate a device request structure
    // GET_DESCRIPTOR   bRequest = kUSBRqGetDescriptor=6
    //  wValue field specifies the descriptor type (STRING=3) in
    // the high byte, and the descriptor index in the low byte.
    // rq.bmRequestType = kGetDescriptor;
    //  The wIndex field specifies the Language ID for string descriptor
    
    // bmRequestType = 100000000B=128
    // kGetConfiguration
    rq.bmRequestType = USBmakebmRequestType(kUSBIn, kUSBStandard, kUSBDevice);
    rq.bRequest = kUSBRqGetDescriptor;
    rq.wValue = (kUSBStringDesc << 8) | 0;
    rq.wIndex = 0; //when reset to zero the call returns an array of language IDs.
    rq.wLength = sizeof(buffer);
    rq.pData = buffer;
    rq.completionTimeout = 0;
    rq.noDataTimeout = 1;
    
    // send the request once to get the array of supported languages
    kr = (*interfaceInterface)->ControlRequestTO(interfaceInterface, (UInt8)0, &rq );
    if (kIOReturnSuccess == kr && 3 < rq.wLenDone)
    {
        langIDCount=(buffer[0] -2)/2;
        for (i=2;i < buffer[0]; i+=2)
        {
            // try to find US English, but accept any (in this case the last) version of English
            // we should ideally be matching against the user's selected language, but we need to be consistent
            // across users, because the URI must match for all users.
            if (0x09 == buffer[i+1])
            {
                rq.wIndex = (buffer[i] << 8) | 0x09;
                if (0x04==buffer[i])
                    break;
            }
        }
        //check for failure
        if (0 == rq.wIndex)
        {
            // if we cannot find an English LangID then we use the first one in the list and hope for the best
            rq.wIndex = (buffer[3] << 8) | buffer[2];//0x0409 US English. hardcoding this is an error.
            // report language codes other than US english
            if (2 < gargc && 0 < langIDCount)
            {   
                CUPS_DEBUG2("using language id %#.4x for string descriptor %d.\n",(int)rq.wIndex, (int)stringIndex);
                CUPS_DEBUG2("The number of language IDs is %d.\n",(buffer[0] -2)/2);
                for (i=3,j=1;i < buffer[0]; i += 2,j++)
                {
                    CUPS_DEBUG2("LangID #%d is  %#.4x.\n",j,((buffer[i] << 8) | buffer[i-1]));
                }
            }
        }
    }
    
    // now we should (hopefully) have a valid LangID so set the wValue to the string index of interest
    // and send the request again to get the string
    rq.wValue = (kUSBStringDesc << 8) | stringIndex;

    kr = (*interfaceInterface)->ControlRequestTO(interfaceInterface, (UInt8)0, &rq );
    if (kIOReturnSuccess == kr && 1 < rq.wLenDone)
    {
        unsigned result_length=buffer[0];

        // USB string descriptors are stored as Unicode strings (16 bit) little endian
        // use the length and descriptor-type bytes to insert a UTF16 BOM for this string
        buffer[0]=0xFF;
        buffer[1]=0xFE;

        // check that the result length does not exceed the buffer
        // according to the USB spec it never should (the length of
        // of a String descriptor should never exceed 256). If it does
        // for any reason then clip the return CFString, return it anyway
        // and return the most "appropriate" error in kr.
        if (result_length > sizeof(buffer))
        {
            result_length=sizeof(buffer);
            kr = kIOReturnOverrun;
        }
		// result_length should always be even for a 16 bit unicode string
		if(result_length % 2 && result_length--);
		// some people do not like to follow specifications ...
		while (0 < result_length && '\0' == buffer[result_length -2] && (result_length -= 2));
		if(4 <= result_length)
		{
			*descriptorString = CFStringCreateWithBytes( NULL, buffer, result_length, kCFStringEncodingUnicode, 1 );
		}
//        if (2 < gargc && *descriptorString)
//            CFShow(*descriptorString);
    }
    return kr;
}
IOReturn usbInterfaceGetDeviceDescriptor( IOUSBInterfaceInterface190 **interfaceInterface, IOUSBDeviceDescriptorPtr dDescriptor, CFIndex dDescriptorLength)
{
    // check for NULL pointers
    if (NULL == interfaceInterface || NULL == dDescriptor || 0 == dDescriptorLength)
    {
        CUPS_ERROR("Passed a NULL pointer or zero length into usbInterfaceGetDeviceDescriptor.\n");
        
        return kIOReturnBadArgument;
    }
            
    // This function gets the USB device descriptor type specified by ...  and returns it
    // in ...
    IOReturn            ioResult;     //(int) the result from a kernal call
    IOUSBDevRequestTO   rq;     //Parameter block for control requests with timeouts
	        
    // populate a device request structure
    // GET_DESCRIPTOR   bRequest = kUSBRqGetDescriptor=6
    //  wValue field specifies the descriptor type in
    // the high byte, and the descriptor index in the low byte.
    // rq.bmRequestType = kGetDescriptor;
    //  The wIndex field specifies the Language ID for string descriptors
    // and is zero for other descriptors
    
    // bmRequestType = 100000000B=128
    rq.bmRequestType = USBmakebmRequestType(kUSBIn, kUSBStandard, kUSBDevice);
    // defined in this file 
    rq.bRequest = kUSBRqGetDescriptor;
    rq.wValue = (kUSBDeviceDesc << 8) | 0;
    rq.wIndex = 0;
    rq.wLength = dDescriptorLength;
    rq.pData = dDescriptor;
    rq.completionTimeout = 100;
    rq.noDataTimeout = 100;
    
    // send the request once and verify the response
    ioResult = (*interfaceInterface)->ControlRequestTO(interfaceInterface, (UInt8)0, &rq );
    if (kIOReturnSuccess == ioResult && dDescriptorLength > rq.wLenDone)
        ioResult = kIOReturnUnderrun;
    return ioResult;
}
void applyToValueIUnknownRelease(const void *key, const void *value, void *context)
{
    CFNumberRef     keyNumber=(CFNumberRef)value;
    IUnknownVTbl ** unknown;
    void *          pointerValue;

    if(CFNumberGetValue(keyNumber, kCFNumberSInt64Type, &pointerValue))
        unknown=(IUnknownVTbl **)pointerValue;
    else
        unknown=NULL;
    if (unknown != NULL)
    {
        (*unknown)->Release(unknown);
        unknown=NULL;
    }
}
static IOReturn usbPrinterGetPortStatus(IOUSBInterfaceInterface190 **interfaceInterface, UInt8 *portStatus)
{
    // check for NULL pointers
    if (NULL == interfaceInterface)
        return kIOReturnBadArgument;

    UInt8               interfaceNumber;    // The currently active device interface
    UInt8               localPortStatus=0;    // The function-local port status variable
    kern_return_t       kr;     //(int) the result from a kernal call
    IOUSBDevRequestTO   rq;     //Parameter block for control requests with timeouts
	

    kr = (*interfaceInterface)->GetInterfaceNumber(interfaceInterface, &interfaceNumber);
    if ( kr == kIOReturnSuccess )
    {

        // populate a device request structure
        // GET_PORT_STATUS    bRequest = 1
        //                      wValue field is zero.
        //                      wIndex field is  the zero-based interface index.
        // bmRequestType =100100001B==161
        rq.bmRequestType = USBmakebmRequestType(kUSBIn, kUSBClass, kUSBInterface);
        // kUSBPrintClassGetPortStatus is defined in this file 
        rq.bRequest = kUSBPrintClassGetPortStatus;
        rq.wValue = 0;
        rq.wIndex = interfaceNumber;
        rq.wLength = 1;
        rq.pData = &localPortStatus;
        rq.completionTimeout = 100;
        rq.noDataTimeout = 100;
        
        kr = (*interfaceInterface)->ControlRequestTO(interfaceInterface, (UInt8)0, &rq );
        if ((1 == rq.wLenDone) && (kIOReturnSuccess == kr))
        {
            // should be checking for wLenDone==1 ...
            
            // the `normal' port status is (kUSBPrintClassDeviceSelected|kUSBPrintClassDeviceNoError)
            if (localPortStatus != (kUSBPrintClassDeviceSelected|kUSBPrintClassDeviceNoError))
            {
                if (localPortStatus & kUSBPrintClassDevicePaperEmpty)
                    kr = kIOReturnNoMedia;
                else if (!(localPortStatus & kUSBPrintClassDeviceSelected))
                    kr = kIOReturnOffline;
                else
                    kr = kIOReturnDeviceError;
            }
        }
        else
        {
            // an error occured during the device request
            // zero the port status and verify that kr returns error
            localPortStatus = 0;
            if (kIOReturnSuccess == kr)
            {
                kr = kIOReturnDeviceError;
            }
        }
    }

    // return the raw port status if the caller requested it (that is, if portStatus != NULL)
    if (NULL != portStatus)
        *portStatus = localPortStatus;

    return kr;
}
IOReturn usbInterfaceResetUSBDevice(IOUSBInterfaceInterface190 **interface)
{
    // check for NULL pointers
    if (NULL == interface)
        return kIOReturnBadArgument;

    IOCFPlugInInterface     **plugInInterface = NULL;
    SInt32 score;

    IOUSBDeviceInterface187 ** device=NULL;
    io_service_t deviceObject;
    IOReturn ioResult;
    
    CUPS_DEBUG("attempting to reset USB device with interface [%x]\n",(int)interface);
    
    // get the `device' and go through the machinations to get the device interface
    ioResult = (*interface)->GetDevice(interface, &deviceObject);

    if (deviceObject)
    {
        // get a CFPlugIn interface for this io_service_t object
        if ( ioResult = IOCreatePlugInInterfaceForService(deviceObject, kIOUSBDeviceUserClientTypeID, kIOCFPlugInInterfaceID, &plugInInterface, &score) )
            fprintf(stderr, "ERROR: IOCreatePlugInInterfaceForService() returned [%d]\n",ioResult);

        // now get the appropriate InterfaceInterface from the plugin
        if (plugInInterface != NULL)
        {
            ioResult=(*plugInInterface)->QueryInterface(plugInInterface, CFUUIDGetUUIDBytes(kIOUSBDeviceInterfaceID187), (LPVOID) &device);
            if (device != NULL)
            {

                CUPS_DEBUG("ReEnumerating USB device [%x]\n",(int)device);
                //ioResult = (*device)->ResetDevice(device);
                ioResult = (*device)->USBDeviceReEnumerate(device,0);
                
                (*device)->Release(device);
                device=NULL;
            }
            IODestroyPlugInInterface(plugInInterface);
            plugInInterface = NULL;
        }
    }
    
    return ioResult;
}
kern_return_t usbPrinterSoftReset(IOUSBInterfaceInterface190 **interface)
{
    return sendSoftResetGeneric(interface, false);
}
kern_return_t usbPrinterSoftResetCompatible(IOUSBInterfaceInterface190 **interface)
{
    return sendSoftResetGeneric(interface, true);
}
kern_return_t sendSoftResetGeneric(IOUSBInterfaceInterface190 **interface, bool versionOneDotZeroCompatible)
{
    // check for NULL pointers
    if (NULL == interface)
        return kIOReturnBadArgument;

    UInt8               interfaceNumber;
    kern_return_t       kr;     //(int) the result from a kernal call
    IOUSBDevRequestTO   rq;     //Parameter block for control requests with timeouts

    // lookup the interface number for this interface
    kr = (*interface)->GetInterfaceNumber(interface, &interfaceNumber);
    if ( kr != kIOReturnSuccess )
		return kr;

    // populate a device request structure
    // SOFT_RESET   bRequest = 2
    //              wValue field is zero.
    //              wIndex field is  the zero-based interface index.
    // bmRequestType =00100001B==33
    // Version 1.0 of the specification incorrectly stated that the bmReqestType
    // for SOFT_RESET was 00100011B. Version 1.1 Host software implementers should
    // be prepared for USB printers that expect this request code.
    if (versionOneDotZeroCompatible)
        rq.bmRequestType = USBmakebmRequestType(kUSBOut, kUSBClass, kUSBOther);
    else
        rq.bmRequestType = USBmakebmRequestType(kUSBOut, kUSBClass, kUSBInterface);
    // kUSBPrintClassSoftReset is defined in this file 
    rq.bRequest = kUSBPrintClassSoftReset;
    rq.wValue = 0;
    rq.wIndex = interfaceNumber;
    rq.wLength = 0;
    rq.pData = NULL;
    rq.completionTimeout = 100;
    rq.noDataTimeout = 100;

    // make the request
    kr = (*interface)->ControlRequestTO(interface, (UInt8)0, &rq );

    return kr;
}
static void signalHandler(int sigraised)
{
  // signal handlers should do as little as possible (ideally set a flag and exit).
  // To the extent that it is necessary to call external functions from
  // a signal handler, only async-signal safe functions should called.


    CUPS_DEBUG("caught signal %d \"%s\"\n",sigraised,strForSignal(sigraised));
    // signals are not processed immediately allowing for signals to
    // be potentially overwritten before they are handled.
    
    // be careful to overwrite only `innocuous' signals
    switch(sigraised)
    {
    case SIGINT  :
        if(gSignal != sigraised)
        {
            CUPS_DEBUG("Caught a signal. Send again to kill the job.\n");
            // require to 
            gSignal = sigraised;
            break;
        }
    case SIGTERM :
    case SIGHUP  :
    case SIGQUIT :
    case SIGABRT :
    case SIGTSTP :
        CFRunLoopStop(CFRunLoopGetCurrent());
        break;

    default:
        gSignal=sigraised;
        break;
    }
}
const char *colors[] =
{
  "Black",
  "Cyan",
  "Magenta",
  "Yellow",
  "Light Cyan",
  "Light Magenta",
  "Black/Dark Yellow",
  0
};
IOReturn epsonPrinterParseInkData(UInt8 *buffer, unsigned numBytesRead)
{
    int i,j;
    char *ptr;
    int level[16];  // an array of ink levels corresponding to const char *colors 

    // check for NULL buffer
    if (NULL == buffer)
    {
      fprintf(stderr, "Cannot parse ink-level output from a NULL buffer!\n");
      return kIOReturnError;
    }
    
    // look for the correct marker
    if ((ptr = strstr((char *)buffer, "IQ:")) == NULL)
    {
      fprintf(stderr, "Cannot parse ink-level output from printer response.\n");
      return kIOReturnError;
    }
    // increment the pointer passed the marker
    ptr += 3;

    // we now need to convert the response from ASCII hex into a usable form
    // The ink level info follows the `IQ:' key as a string of `bytes' encoded in ASCII hex.
    // Each `byte' represents the percentage remaining of the corresponding ink color.
    // for each color,
    // (assumption) The epson will always produce this string in US ASCII encoded hex bytes
    bool keepLooping=true;
    bool cleanExit=false;
    for (i = 0; keepLooping; i++, ptr +=2)
    {
        switch(ptr[0])
        {
        case '0' ... '6':
            switch(ptr[1])
            {
            case '0' ... '9':
                level[i] = ptr[1] - '0';
                break;
            case 'A' ... 'F':
                level[i] = ptr[1] - ('A' - 10);
                break;
            case 'a' ... 'f':
                level[i] = ptr[1] - ('a' - 10);
                break;
            default:
                keepLooping=false;
                break;
            }
            level[i] += (ptr[0] - '0')*16;
            break;
            
        // look for the terminating semicolon (ASCII 59)
        // and fall through to the exit condition
        case ';':
            if (0<i)
                cleanExit=true;
        default:
            keepLooping=false;
            break;
        }
    }
    // print the results on stderr INFO
    if (cleanExit)
    {
        fprintf(stderr,"INFO: Ink levels:");
        for (j=0;j<i-1;j++)
            fprintf(stderr," %s=%d%%",colors[j],level[j]);
        fprintf(stderr,"\n");
        return kIOReturnSuccess;
    }
    else
        fprintf(stderr,"INFO: Could not read ink levels\n");

    return kIOReturnError;
}
IOReturn epsonPrinterGetRemoteCommand(UInt8 *buffer, unsigned *byteCount, int *command, int commandCount, bool usesPacketMode)
{
    const unsigned  bufferSize = *byteCount;
    int             i, j, commandLength, numCommands, *iCommands;
    UInt8         * bufferPlus = buffer;
    bool            needsFormFeed = false;
    
    UInt8 epson_exit_packet_mode[] = "\0\0\0\033\01@EJL 1284.4\n@EJL     \n\033@";
//"\000\000\000\033\001\100\105\112\114\040\061\062\070\064\056\064\012\100\105\112\114\040\040\040\040\040\012\033\100"
    UInt8 epson_remote_command_begin[] = "\033@\033(R\010\0\0REMOTE1";
    //"\033\100\033\050\122\010\000\000\122\105\115\117\124\105\061"
    UInt8 epson_remote_command_end[] = "\033\0\0\0";     //"\033\000\000\000"
    UInt8 epson_reset[] = "\033\100\033\100";
    UInt8 epson_form_feed[] = "\015\014";           //"\r\f";
    UInt8 epson_status_cmd[] = "ST\02\0\0\01";      //"\123\124\002\000\000\001"
    UInt8 nozzle_check_cmd[] = "NC\02\0\0\0";
    UInt8 epson_ink_quantity_cmd[] = "IQ\01\0\01";
    UInt8 alignment_cmd[] = "DT\03\0\0\01\0";
    UInt8 set_alignment_cmd[] = "DA\04\0\0\02\0\010";
    //"DT\003\000\000\001\000DT\003\000\000\002\000\033\000\000\000\f\033\000\033\000\033";
    //UInt8 ink_level_cmd[] =

    //"\033\000\033\000\033\000";
    
    // preflight the command queue
    numCommands = (int)usesPacketMode + commandCount + 4;
    iCommands=malloc(numCommands * sizeof(iCommands));
    i=commandLength=0;
    if (iCommands)
    {
        if (usesPacketMode)
        {
            iCommands[i]=kEpsonPrinterUsesPacketMode;
            i++;
            commandLength += sizeof(epson_exit_packet_mode) -1;
        }
        iCommands[i]=kEpsonPrinterRemoteCommandBegin;
        i++;
        commandLength += sizeof(epson_remote_command_begin) -1;
        
        for (j=0;j<commandCount;j++,i++)
        {
            iCommands[i]=command[j];
            commandLength += sizeof(set_alignment_cmd) -1;
            if (!needsFormFeed && (kEpsonPrinterFormFeed & command[j]))
                needsFormFeed=true;
        }
        if (needsFormFeed)
        {
            iCommands[i]=kEpsonPrinterFormFeed;
            i++;
            commandLength += sizeof(epson_form_feed) -1;
        }
        iCommands[i]=kEpsonPrinterReset;
        i++;
        commandLength += sizeof(epson_reset) -1;
        
        iCommands[i]=kEpsonPrinterRemoteCommandEnd;
        i++;
        commandLength += sizeof(epson_remote_command_end) -1;
        
        free(iCommands);
    }
    else
        return 1;

    // verify adequate buffer size
    if ( (int)usesPacketMode*sizeof(epson_exit_packet_mode) + sizeof(epson_remote_command_begin) + commandCount*sizeof(set_alignment_cmd) + sizeof(epson_reset) + sizeof(epson_remote_command_end) - (3 + (int)usesPacketMode + commandCount) > bufferSize)
    {
        fprintf(stderr,"ERROR:Command buffer (%u bytes) too small as argument to epsonPrinterGetRemoteCommand()\n", bufferSize);
        return 1;
    }
    
    // zero the byte count. This value returns the total length of the composite command.
    *byteCount=0;
    
    // add the `exit packet mode' command if necessary.
    if (usesPacketMode)
    {
        commandLength = sizeof(epson_exit_packet_mode) -1;
        memcpy(bufferPlus, epson_exit_packet_mode, commandLength);
        bufferPlus += commandLength;
    }
    
    // add the epson_remote_command_begin portion
    commandLength = sizeof(epson_remote_command_begin) -1;
    memcpy(bufferPlus, epson_remote_command_begin, commandLength);
    bufferPlus += commandLength;
    
    UInt8 *cmdptr=NULL;
    for (i=0;i < commandCount;i++)
    {
        switch (command[i])
        {
        case kEpsonPrinterCommandSetStatus:
            commandLength = sizeof(epson_status_cmd) -1;
            cmdptr=epson_status_cmd;
            break;
        case kEpsonPrinterCommandNozzleCheck:
            commandLength = sizeof(nozzle_check_cmd) -1;
            cmdptr=nozzle_check_cmd;
            break;
        case kEpsonPrinterCommandDoAlignment:
            commandLength = sizeof(alignment_cmd) -1;
            cmdptr=alignment_cmd;
            break;
        case kEpsonPrinterCommandGetInkQ:
            commandLength = sizeof(epson_ink_quantity_cmd) -1;
            cmdptr=epson_ink_quantity_cmd;
            break;
        default:
            commandLength=0;
            fprintf(stderr,"ERROR:Unrecognized command argument (%d) to epsonPrinterGetRemoteCommand()\n", command[i]);
            break;
        }
        if (0 < commandLength)
        {
            memcpy(bufferPlus, cmdptr, commandLength);
            bufferPlus += commandLength;            
        }
    }

    // add the epson_remote_command_end portion
    commandLength = sizeof(epson_remote_command_end) -1;
    memcpy(bufferPlus, epson_remote_command_end, commandLength);
    bufferPlus += commandLength;
    
    // add a formfeed command if necessary
    
    // add the epson_reset portion
    commandLength = sizeof(epson_reset) -1;
    memcpy(bufferPlus, epson_reset, commandLength);
    bufferPlus += commandLength;
    
    *byteCount = bufferPlus - buffer;
    return 0;
}
void waitForInterfaceCallback(void * context, io_service_t service, uint32_t messageType, void * messageArgument)
{
    TBUSBInterfaceContext *tbContext = context;

    // validate the context
    if (NULL == tbContext || TB_VALID_CONTEXT_KEY != tbContext->validator)
    {
        CUPS_DEBUG("Internal context inconsistency error entering %s;\n",__func__);
        return;
    }
    
    CUPS_DEBUG("while waiting to open .... got a message about the device: message = %s arg = %p\n", strForIOMessage(messageType), messageArgument);
    if(kIOMessageServiceIsTerminated == messageType)
    {
        tbContext->writeStatus = kIOReturnNoDevice;
        CFRunLoopStop(CFRunLoopGetCurrent());
    }
    if(kIOMessageServiceWasClosed == messageType)
    {
        CFRunLoopStop(CFRunLoopGetCurrent());
    }

//
//    kern_return_t kr;
//    TBUSBInterfaceContext * tbContext = context;
//
//    // validate the context
//    if (NULL == tbContext || TB_VALID_CONTEXT_KEY != tbContext->validator)
//    {
//        CUPS_DEBUG("Internal context inconsistency error in %s;\n",__func__);
//        return;
//    }
//
//    
//    if (kIOMessageServiceWasClosed == messageType)
//    {
//        // try to open the interface
//        kr =(*tbContext->interface)->USBInterfaceOpenSeize(tbContext->interface);
//        // check the result
//        if (kIOReturnSuccess == kr)
//        {
//            tbContext->interfaceStatus = kUSBInterfaceIsOpen;
//            // stop the runloop if we succeeded in opening
//            CFRunLoopStop(CFRunLoopGetCurrent());
//        }
//        else if (kIOReturnExclusiveAccess != kr)
//        {
//        
//        }
//    }
//    else
//    {
//        // log the message and continue to wait ...
//        CUPS_DEBUG("while waiting to open .... got a message about the device: message = %u arg = %p\n", messageType, messageArgument);
//    }

}
void interfaceTimerCallback(CFRunLoopTimerRef timer, void *refcon)
{
    TBUSBInterfaceContext *tbContext = refcon;

    // validate the context
    if (NULL == tbContext || TB_VALID_CONTEXT_KEY != tbContext->validator)
    {
        CUPS_DEBUG("Internal context inconsistency error entering %s;\n",__func__);
        return;
    }

    // check if we have opened the interface
    if(kUSBInterfaceIsClosed == tbContext->interfaceStatus && 0 == tbContext->writeByteCount)
    {
        CUPS_INFO("The printer is busy.\n");
        tbContext->recentWriteTimeoutCount ++;
    }

    if(kIOReturnNotFound == tbContext->readStatus)
    {
        // the reading is done so the upstream filter should
        // not further pollute the status stream
        // so we can stop putting out ours
        CUPS_DEBUG("invalidating \"interface busy\" timer \n");
        CFRunLoopTimerInvalidate(timer);
        // the timer will never fire again
    }
}
kern_return_t waitForInterface(TBUSBInterfaceContext * tbContext)
{
    //try to open the interface; wait indefinitely for another app to close it
    
    kern_return_t kr = kIOReturnError;
    io_object_t  notification;    
    
    if(tbContext->notifyPort)
    {
        // add a fallback timer because the notification method seems to miss events?!
        kr = IOServiceAddInterestNotification(tbContext->notifyPort, tbContext->deviceObject, kIOGeneralInterest, waitForInterfaceCallback, tbContext, &notification);
        if(kIOReturnSuccess == kr && notification)
        {

            // we need to prepare for receiving kIOReturnExclusiveAccess
            // we use the USBInterfaceOpenSeize variant because the user is attempting
            // to print to this device, so any other driver should release it asap
            while(kUSBInterfaceIsClosed == tbContext->interfaceStatus && kIOReturnExclusiveAccess == (kr = (*tbContext->interface)->USBInterfaceOpenSeize(tbContext->interface)))
            {
                CUPS_DEBUG("Another app has the printer USB interface open for exclusive access.\n");
                CUPS_DEBUG("Waiting for USB interface on device %.8x to be closed...\n",tbContext->deviceObject);

                // add a timer to report printer status if we have to wait excessively long
                // report first after 15 sec and then check every 30
                CFRunLoopTimerRef statTimer=NULL;
                CFAbsoluteTime start = CFAbsoluteTimeGetCurrent();
                createTimerWithIntervalAndFireDate(&statTimer, 30.0, (start + 15.0), interfaceTimerCallback, tbContext);

                // the device is in exclusive use by another app
                // start the run loop to wait for it to be closed
                CFRunLoopRun();
                if(gSignal && (SIGUSR1 != gSignal && SIGUSR2 != gSignal))
                {
                    CUPS_DEBUG("breaking out for signal %s\n",strForSignal(gSignal));
                    break;
                }
                
                // guard against device removal
                if(kIOReturnNoDevice == tbContext->writeStatus)
                {
                    kr = kIOReturnNoDevice;
                    break;
                }
                
                CUPS_DEBUG("waited %f seconds for the interface to open.\n",(CFAbsoluteTimeGetCurrent() - start));

                if (CFRunLoopTimerIsValid(statTimer))
                {
                    CFRunLoopTimerInvalidate(statTimer);
                }
                DESTROY_CFTypeRef(statTimer);

            }

            if (kUSBInterfaceIsOpen == tbContext->interfaceStatus && 0 < tbContext->recentWriteTimeoutCount)
            {
                // if we are recovering from a wait condition be sure to clear any "busy" status messages
                tbContext->recentWriteTimeoutCount = 0;
                CUPS_INFO("Printing ...\n");
            }
        }
        else
        {
            //failed to add an interest notification
            while(kIOReturnExclusiveAccess == (kr = (*tbContext->interface)->USBInterfaceOpenSeize(tbContext->interface)))
            {
                CUPS_INFO("The printer is busy.\n");
                sleep(15);
            }
        }
        if (kIOReturnSuccess == kr)
        {
            tbContext->interfaceStatus = kUSBInterfaceIsOpen;
        }
        //clean up
        if(notification && (kr=IOObjectRelease(notification)))
        {
            CUPS_DEBUG2("%s error [0x%.2X] trying to release a notification object in %s line %d\n",strForIOReturn(kr), kr, __func__, __LINE__);
        }
    }
    else
    {
        CUPS_DEBUG("Failed to get resources for a runloop\n");
    }
        
    return kr;
}
void deviceRemovedCallback(void *refcon, io_iterator_t iterator)
{
    TBUSBInterfaceContext *tbContext = refcon;

    // validate the context
    if (NULL == tbContext || TB_VALID_CONTEXT_KEY != tbContext->validator)
    {
        CUPS_DEBUG("Internal context inconsistency error entering %s;\n",__func__);
        return;
    }

    io_service_t            removedDevice;
        
    while ((IOIteratorIsValid(iterator) || (IOIteratorReset(iterator),(1))) && (removedDevice = IOIteratorNext(iterator)) )
    {
        // check if the removed device is ours
        if(IOObjectIsEqualTo(removedDevice,tbContext->deviceObject))
        {
            CFRunLoopStop(CFRunLoopGetCurrent());
            // make sure we never start again
            tbContext->writeStatus = kIOReturnNoDevice;
            CUPS_STATE_SET("offline-error");
            CUPS_ERROR("The printer connection has terminated!");
            break;
        }
    }
}
void newPrinterCallback(void *refcon, io_iterator_t iterator)
{
    CFRunLoopStop(CFRunLoopGetCurrent());
//    //iterate through to (re)arm the notification
//    while (IOIteratorNext(iterator));
//
//    // basically just stop the runloop
//    CFRunLoopRef runloop = refcon;
//    if(refcon)
//    {
//        CFRunLoopStop(runloop);
//    }
}
void watchDevice(TBUSBInterfaceContext * tbContext)
{
    //wait for a USB printer class device connection
    
    kern_return_t kr;

    CFMutableDictionaryRef matchingDict;
    SInt32 matchingValue;
    CFNumberRef keyNumber;    
    CFRunLoopSourceRef runLoopSource=NULL;
    io_iterator_t  printerIterator=0;
    
    IONotificationPortRef notifyPort = IONotificationPortCreate(kIOMasterPortDefault);
    
    if(notifyPort)
    {
        runLoopSource = IONotificationPortGetRunLoopSource(notifyPort);
    }

    // Look up (existing) registered IOService objects that match a matching dictionary and
    // Set up matching dictionary for class IOUSBDevice and its subclasses
    matchingDict = IOServiceMatching(kIOUSBInterfaceClassName);

    if(runLoopSource && matchingDict)
    {
        // add our source to the run loop so that it waits for events
        CFRunLoopAddSource(CFRunLoopGetCurrent(), runLoopSource, kCFRunLoopCommonModes);

        //Add the vendor and product IDs to the matching dictionary
        //This is the second key of the first table in the USB Common Class

        //Specification kIOProviderClassKey
        matchingValue=kUSBPrintingInterfaceClass;
        keyNumber=CFNumberCreate(kCFAllocatorDefault, kCFNumberSInt32Type, &matchingValue);
        CFDictionarySetValue(matchingDict, CFSTR(kUSBInterfaceClass), keyNumber);
        CFRelease(keyNumber);
        
        matchingValue=kUSBPrintingSubclass;
        keyNumber=CFNumberCreate(kCFAllocatorDefault, kCFNumberSInt32Type, &matchingValue);
        CFDictionarySetValue(matchingDict, CFSTR(kUSBInterfaceSubClass), keyNumber);
        CFRelease(keyNumber);
        
        matchingValue=tbContext->idVendor;
        keyNumber=CFNumberCreate(kCFAllocatorDefault, kCFNumberSInt32Type, &matchingValue);
        CFDictionarySetValue(matchingDict, CFSTR(kUSBVendorID), keyNumber);
        CFRelease(keyNumber);
        
        matchingValue=tbContext->idProduct;
        keyNumber=CFNumberCreate(kCFAllocatorDefault, kCFNumberSInt32Type, &matchingValue);
        CFDictionarySetValue(matchingDict, CFSTR(kUSBProductID), keyNumber);
        CFRelease(keyNumber);
        
        // install a notification request for new IOServices that match
        // this function consumes a reference to the matchingdict so we don't release it
        kr=IOServiceAddMatchingNotification(notifyPort, kIOTerminatedNotification, matchingDict, deviceRemovedCallback, NULL, &printerIterator);
        // now call newPrinterCallback to iterate through any existing objects in gAppearedIter
        // this call should empty the iterator of objects which has the effect of arming the notification
        if(kIOReturnSuccess == kr && printerIterator)
        {
            //drain the iterator to arm the notification
            
            // save the notification port
        }
    }
}
void waitForDevice(TBUSBInterfaceContext * tbContext, const char *uri)
{
    
    //wait for a USB printer class device connection
    
    kern_return_t kr;

    CFMutableDictionaryRef matchingDict;
    SInt32 matchingValue;
    CFNumberRef keyNumber;    
    CFRunLoopSourceRef runLoopSource=NULL;
    io_iterator_t  printerIterator=0;
    int match;
    boolean_t   shouldRecover=false;
    
    tbContext->notifyPort = IONotificationPortCreate(kIOMasterPortDefault);
    
    if(tbContext->notifyPort)
    {
        runLoopSource = IONotificationPortGetRunLoopSource(tbContext->notifyPort);
    }
    
    // Look up (existing) registered IOService objects that match a matching dictionary and
    // Set up matching dictionary for class IOUSBDevice and its subclasses
    matchingDict = IOServiceMatching(kIOUSBInterfaceClassName);
    // retain the dict once to use again for the termination notification
    matchingDict = (CFMutableDictionaryRef) CFRetain(matchingDict);

    if(runLoopSource && matchingDict)
    {
        // add our source to the run loop so that it waits for events
        CFRunLoopAddSource(CFRunLoopGetCurrent(), runLoopSource, kCFRunLoopCommonModes);

        //This is the second key of the first table in the USB Common Class
        //Specification kIOProviderClassKey

        matchingValue=kUSBPrintingInterfaceClass;
        keyNumber=CFNumberCreate(kCFAllocatorDefault, kCFNumberSInt32Type, &matchingValue);
        CFDictionarySetValue(matchingDict, CFSTR(kUSBInterfaceClass), keyNumber);
        CFRelease(keyNumber);

        matchingValue=kUSBPrintingSubclass;
        keyNumber=CFNumberCreate(kCFAllocatorDefault, kCFNumberSInt32Type, &matchingValue);
        CFDictionarySetValue(matchingDict, CFSTR(kUSBInterfaceSubClass), keyNumber);
        CFRelease(keyNumber);

        // install a notification request for new IOServices that match
        // this function consumes a reference to the matchingdict so we don't release it
        kr=IOServiceAddMatchingNotification(tbContext->notifyPort, kIOMatchedNotification, matchingDict, newPrinterCallback, NULL, &printerIterator);
        if(kIOReturnSuccess == kr && printerIterator)
        {
            //drain the iterator to arm the notification
            while(0 == (match=iterateForDevices(printerIterator, tbContext)))
            {
                if(false == shouldRecover)
                {
                    CUPS_STATE_SET("offline-error");
                    CUPS_RECOVERABLE("No printer available. Please verify the USB connection!\n");
                    shouldRecover = true;
                }

                // now actually start the run loop
                // the runloop will run until we get a match
                CFRunLoopRun();
                if(gSignal && (SIGUSR1 != gSignal && SIGUSR2 != gSignal))
                {
                    CUPS_DEBUG("breaking out for signal %s\n",strForSignal(gSignal));
                    break;
                }
            }
            if(match)
            {
                // destroy the device iterator to prevent it from firing again
                if (kr=IOObjectRelease(printerIterator))
                {
                    CUPS_DEBUG("%s error [%.8x] trying to release an io_iterator in %s line %d\n",strForIOReturn(kr),kr,__func__,__LINE__);
                }
                printerIterator = 0;
                
                CUPS_DEBUG("Matched USB device %.8x to input device URI \"%s\".\n",tbContext->deviceObject, uri);
                if(true == shouldRecover)
                {
                    CUPS_STATE_CLEAR("offline-error");
                    CUPS_RECOVERED("\n");            
                }
                
                // now create a new notification for the case of unexpected device removal
                // add the matched vendorID and productID to the matching dict
                matchingValue=tbContext->idVendor;
                keyNumber=CFNumberCreate(kCFAllocatorDefault, kCFNumberSInt32Type, &matchingValue);
                CFDictionarySetValue(matchingDict, CFSTR(kUSBVendorID), keyNumber);
                CFRelease(keyNumber);
                
                matchingValue=tbContext->idProduct;
                keyNumber=CFNumberCreate(kCFAllocatorDefault, kCFNumberSInt32Type, &matchingValue);
                CFDictionarySetValue(matchingDict, CFSTR(kUSBProductID), keyNumber);
                CFRelease(keyNumber);
                
                // this function consumes a reference to the matchingdict so we don't release it
                kr=IOServiceAddMatchingNotification(tbContext->notifyPort, kIOTerminatedNotification, matchingDict, deviceRemovedCallback, NULL, &tbContext->objectIterator);
                //drain the iterator to arm it
                deviceRemovedCallback(tbContext, tbContext->objectIterator);
                //now save the notification port
                
                return;
            }
            else
            {
                CFRelease(matchingDict);
                CUPS_DEBUG("bad match ? for USB device with device URI \"%s\".\n", uri);
            }
        }
        
        //clean up
        if(printerIterator && IOIteratorIsValid(printerIterator) && (kr=IOObjectRelease(printerIterator)))
        {
            CUPS_DEBUG("%s error [%.8x] trying to release an io_iterator in %s line %d\n",strForIOReturn(kr),kr,__func__,__LINE__);
        }
        
    }

    if(tbContext->notifyPort)
    {
        IONotificationPortDestroy(tbContext->notifyPort);
        tbContext->notifyPort = NULL;
    }

    CUPS_STATE_SET("server-error-internal-error");
    CUPS_DEBUG("Failed to get resources to match a device\n");
    sleep(10);
}
void parseOptionsInURI(const char * uri, TBUSBInterfaceContext * tbContext)
{
    char * options;
    char * option;
    long bufferSize;
    if (uri && (NULL != (options = strstr(uri, URI_OPTIONS_STRING))))
    {
        CUPS_DEBUG("parsing URI options \"%s\"\n",options);
        // parse any options
        if (NULL != (option = strstr(options, URI_OPTION_BUF_SIZE)))
        {
            CUPS_DEBUG("found a valid URI option \"%s\"\n",option);
            
            option += sizeof(URI_OPTION_BUF_SIZE) - 1;
            bufferSize = strtol (option, &option, 0);
            
            switch(option[0])
            {
            case 'm'  :
            case 'M'  :
                bufferSize *= 1048576;
                break;
            case 'k'  :
            case 'K'  :
                bufferSize *= 1024;
                break;
            default:
                break;
            }

            if (tbContext->readStreamReadSize != bufferSize)
            {
                if (0 < bufferSize && BUF_SIZE_MAX >= bufferSize )
                {
                    CUPS_DEBUG("changing readStream buffer size from %ld to %ld.\n", (long)tbContext->readStreamReadSize, bufferSize);
                    tbContext->readStreamReadSize=(bufferSize);
                }
                else 
                    CUPS_DEBUG("uri contained non-valid buffer size option of %ld (max size is %ld).\n", bufferSize, (long)BUF_SIZE_MAX);
            }
        }
        else if (NULL != (option = strstr(options, URI_OPTION_DEBUG)))
        {
            gDebugStr = "ERROR";
            CUPS_DEBUG("Enabling debug output option.\n");
        }
        else if (NULL != (option = strstr(options, URI_OPTION_SIGNAL_READ)))
        {
            if(4 == gargc)
            {
                CUPS_DEBUG("Ignoring \"%s\" option ... overridden by command line arg \"%s\"\n",URI_OPTION_SIGNAL_READ,APP_AS_UTILITY);            
            }
            else
            {
                tbContext->deviceProperties |= kBackChannelDevice;
                tbContext->deviceProperties |= kBackChannelSignalRead;
                CUPS_DEBUG("Enabling backchannel reading only on SIGUSR1.\n");
            }
        }
    }
    else
    {
        CUPS_DEBUG("No options detected in device URI %s.\n",uri);
    }
}
const char *strForCFStreamStatus(CFStreamStatus streamStatus)
{
    //  return a char string for a CFStreamStatus
    switch(streamStatus)
    {
    case kCFStreamStatusNotOpen: return "kCFStreamStatusNotOpen";
    case kCFStreamStatusOpening: return "kCFStreamStatusOpening";
    case kCFStreamStatusOpen:    return "kCFStreamStatusOpen";
    case kCFStreamStatusReading: return "kCFStreamStatusReading";
    case kCFStreamStatusWriting: return "kCFStreamStatusWriting";
    case kCFStreamStatusAtEnd:   return "kCFStreamStatusAtEnd";
    case kCFStreamStatusClosed:  return "kCFStreamStatusClosed";
    case kCFStreamStatusError:   return "kCFStreamStatusError";
    default:    break;
    }
    return "kCFStreamStatusUnknown";
}
const char *strForCFEventType(CFStreamEventType eventType)
{
    //  return a char string for a CFStreamStatus
    switch(eventType)
    {
    case kCFStreamEventNone: return "kCFStreamEventNone";
    case kCFStreamEventOpenCompleted: return "kCFStreamEventOpenCompleted";
    case kCFStreamEventHasBytesAvailable: return "kCFStreamEventHasBytesAvailable";
    case kCFStreamEventCanAcceptBytes: return "kCFStreamEventCanAcceptBytes";
    case kCFStreamEventErrorOccurred: return "kCFStreamEventErrorOccurred";
    case kCFStreamEventEndEncountered: return "kCFStreamEventEndEncountered";
    
    default:    break;
    }
    return "kCFStreamEventUnknown";
}
const char *strForIOMessage(IOMessage message)
{    
    //  return a char string for an IOReturn code
    switch(message)
    {
    case kIOMessageServiceIsTerminated      :    return "kIOMessageServiceIsTerminated";
    case kIOMessageServiceIsSuspended       :    return "kIOMessageServiceIsSuspended";
    case kIOMessageServiceIsResumed         :    return "kIOMessageServiceIsResumed";
    case kIOMessageServiceIsRequestingClose :    return "kIOMessageServiceIsRequestingClose";
    case kIOMessageServiceIsAttemptingOpen  :    return "kIOMessageServiceIsAttemptingOpen";
    case kIOMessageServiceWasClosed         :    return "kIOMessageServiceWasClosed";
    case kIOMessageServiceBusyStateChange   :    return "kIOMessageServiceBusyStateChange";
    case kIOMessageServicePropertyChange    :    return "kIOMessageServicePropertyChange";
    case kIOMessageCanDevicePowerOff        :    return "kIOMessageCanDevicePowerOff";
    case kIOMessageDeviceWillPowerOff       :    return "kIOMessageDeviceWillPowerOff";
    case kIOMessageDeviceWillNotPowerOff    :    return "kIOMessageDeviceWillNotPowerOff";
    case kIOMessageDeviceHasPoweredOn       :    return "kIOMessageDeviceHasPoweredOn";
    case kIOMessageCanSystemPowerOff        :    return "kIOMessageCanSystemPowerOff";
    case kIOMessageSystemWillPowerOff       :    return "kIOMessageSystemWillPowerOff";
    case kIOMessageSystemWillNotPowerOff    :    return "kIOMessageSystemWillNotPowerOff";
    case kIOMessageCanSystemSleep           :    return "kIOMessageCanSystemSleep";
    case kIOMessageSystemWillSleep          :    return "kIOMessageSystemWillSleep";
    case kIOMessageSystemWillNotSleep       :    return "kIOMessageSystemWillNotSleep";
    case kIOMessageSystemHasPoweredOn       :    return "kIOMessageSystemHasPoweredOn";
    case kIOMessageSystemWillRestart        :    return "kIOMessageSystemWillRestart";
    case kIOMessageSystemWillPowerOn        :    return "kIOMessageSystemWillPowerOn";
    case kIOMessageCopyClientID             :    return "kIOMessageCopyClientID";

    default                                 :    return "kIOMessageUnknown";
        break;
    }
}
const char *strForIOReturn(IOReturn ioResult)
{    
    //  return a char string for an IOReturn code
    switch(ioResult)
    {
    // success (no error)
    case kIOReturnSuccess:          return "kIOReturnSuccess";

    // general IOKit returns
    case kIOReturnExclusiveAccess:  return "kIOReturnExclusiveAccess";
    case kIOReturnNoMemory:         return "kIOReturnNoMemory";
    case kIOReturnNotFound:         return "kIOReturnNotFound";
    case kIOReturnTimeout:          return "kIOReturnTimeout";
    case kIOReturnNoDevice:         return "kIOReturnNoDevice";
    case kIOReturnInvalid:          return "kIOReturnInvalid";
    case kIOReturnNoResources:      return "kIOReturnNoResources";
    case kIOReturnStillOpen:        return "kIOReturnStillOpen";

    case kIOReturnUnderrun:         return "kIOReturnUnderrun";
    case kIOReturnOverrun:          return "kIOReturnOverrun";
    case kIOReturnNotResponding:    return "kIOReturnNotResponding";
    case kIOReturnDeviceError:      return "kIOReturnDeviceError";
    case kIOReturnNoCompletion:     return "kIOReturnNoCompletion";
    case kIOReturnAborted:          return "kIOReturnAborted";
    case kIOReturnNoBandwidth:      return "kIOReturnNoBandwidth";

    case kIOReturnIPCError:         return "kIOReturnIPCError";
    case kIOReturnNotPrivileged:    return "kIOReturnNotPrivileged";
    case kIOReturnBadArgument:      return "kIOReturnBadArgument";
    case kIOReturnLockedRead:       return "kIOReturnLockedRead";
    case kIOReturnLockedWrite:      return "kIOReturnLockedWrite";
    
    // IOUSBFamily error returns
    case kIOUSBTransactionTimeout:  return "kIOUSBTransactionTimeout";
    case kIOUSBTransactionReturned: return "kIOUSBTransactionReturned";
    case kIOUSBPipeStalled:         return "kIOUSBPipeStalled";
    case kIOUSBTooManyPipesErr:     return "kIOUSBTooManyPipesErr";
    case kIOUSBNotEnoughPipesErr:   return "kIOUSBNotEnoughPipesErr";
    case kIOUSBUnknownPipeErr:      return "kIOUSBUnknownPipeErr";
    case kIOUSBNoAsyncPortErr:      return "kIOUSBNoAsyncPortErr";
    case kIOUSBEndpointNotFound:    return "kIOUSBEndpointNotFound";
    case kIOUSBInterfaceNotFound:   return "kIOUSBInterfaceNotFound";
    case kIOUSBConfigNotFound:      return "kIOUSBConfigNotFound";
    case kIOUSBNotEnoughPowerErr:   return "kIOUSBNotEnoughPowerErr";
    case kIOUSBHighSpeedSplitError: return "kIOUSBHighSpeedSplitError";

    case kIOUSBLowLatencyBufferNotPreviouslyAllocated:      return "kIOUSBLowLatencyBufferNotPreviouslyAllocated";
    case kIOUSBLowLatencyFrameListNotPreviouslyAllocated:   return "kIOUSBLowLatencyFrameListNotPreviouslyAllocated";
    
    case kIOUSBLinkErr:             return "kIOUSBLinkErr";
    case kIOUSBNotSent2Err:         return "kIOUSBNotSent2Err";
    case kIOUSBNotSent1Err:         return "kIOUSBNotSent1Err";
    case kIOUSBBufferUnderrunErr:   return "kIOUSBBufferUnderrunErr";
    case kIOUSBBufferOverrunErr:    return "kIOUSBBufferOverrunErr";
    case kIOUSBReserved2Err:        return "kIOUSBReserved2Err";
    case kIOUSBReserved1Err:        return "kIOUSBReserved1Err";
    case kIOUSBWrongPIDErr:         return "kIOUSBWrongPIDErr";
    case kIOUSBPIDCheckErr:         return "kIOUSBPIDCheckErr";
    case kIOUSBDataToggleErr:       return "kIOUSBDataToggleErr";
    case kIOUSBBitstufErr:          return "kIOUSBBitstufErr";
    case kIOUSBCRCErr:              return "kIOUSBCRCErr";

    default:                        return "kIOReturnError";
        break;
    }
}
const char *strForErrno(int err)
{    
    //  return a char string for an signal code
    switch(err)
    {
    case EPERM  :    return "EPERM - Operation not permitted";
    case ENOENT  :    return "ENOENT - No such file or directory";
    case ESRCH  :    return "ESRCH - No such process";
    case EINTR  :    return "EINTR - Interrupted system call";
    case EIO  :    return "EIO - Input/output error";
    case ENXIO  :    return "ENXIO - Device not configured";
    case E2BIG  :    return "E2BIG - Argument list too long";
    case ENOEXEC  :    return "ENOEXEC - Exec format error";
    case EBADF  :    return "EBADF - Bad file descriptor";
    case ECHILD  :    return "ECHILD - No child processes";
    case EDEADLK  :    return "EDEADLK - Resource deadlock avoided";
    case ENOMEM  :    return "ENOMEM - Cannot allocate memory";
    case EACCES  :    return "EACCES - Permission denied";
    case EFAULT  :    return "EFAULT - Bad address";
#if !defined(_POSIX_C_SOURCE) || defined(_DARWIN_C_SOURCE)
    case ENOTBLK  :    return "ENOTBLK - Block device required";
#endif
    case EBUSY  :    return "EBUSY - Device / Resource busy";
    case EEXIST  :    return "EEXIST - File exists";
    case EXDEV  :    return "EXDEV - Cross-device link";
    case ENODEV  :    return "ENODEV - Operation not supported by device";
    case ENOTDIR  :    return "ENOTDIR - Not a directory";
    case EISDIR  :    return "EISDIR - Is a directory";
    case EINVAL  :    return "EINVAL - Invalid argument";
    case ENFILE  :    return "ENFILE - Too many open files in system";
    case EMFILE  :    return "EMFILE - Too many open files";
    case ENOTTY  :    return "ENOTTY - Inappropriate ioctl for device";
    case ETXTBSY  :    return "ETXTBSY - Text file busy";
    case EFBIG  :    return "EFBIG - File too large";
    case ENOSPC  :    return "ENOSPC - No space left on device";
    case ESPIPE  :    return "ESPIPE - Illegal seek";
    case EROFS  :    return "EROFS - Read-only file system";
    case EMLINK  :    return "EMLINK - Too many links";
    case EPIPE  :    return "EPIPE - Broken pipe";
    case EDOM  :    return "EDOM - Numerical argument out of domain";
    case ERANGE  :    return "ERANGE - Result too large";
    case EAGAIN  :    return "EAGAIN - Resource temporarily unavailable; Operation would block";
    case EINPROGRESS  :    return "EINPROGRESS - Operation now in progress";
    case EALREADY  :    return "EALREADY - Operation already in progress";
    case ENOTSOCK  :    return "ENOTSOCK - Socket operation on non-socket";
    case EDESTADDRREQ  :    return "EDESTADDRREQ - Destination address required";
    case EMSGSIZE  :    return "EMSGSIZE - Message too long";
    case EPROTOTYPE  :    return "EPROTOTYPE - Protocol wrong type for socket";
    case ENOPROTOOPT  :    return "ENOPROTOOPT - Protocol not available";
    case EPROTONOSUPPORT  :    return "EPROTONOSUPPORT - Protocol not supported";
    
    default:        return "unknown";
        break;
    }
}
const char *strForSignal(int sigraised)
{    
    //  return a char string for an signal code
    switch(sigraised)
    {
    case SIGHUP  :    return "HangUP";
    case SIGINT  :    return "INTerrupt";
    case SIGQUIT :    return "QUIT";
    case SIGILL  :    return "ILLegal instruction";
    case SIGABRT :    return "ABoRT";
    case SIGTRAP :    return "trace TRAP";

    case SIGFPE  :    return "Floating Point Exception";
    case SIGKILL :    return "KILL";
    case SIGBUS  :    return "BUS error";
    case SIGSEGV :    return "SEGmentation Violation";
    case SIGSYS  :    return "bad argument to SYStem call";
    case SIGPIPE :    return "write on a PIPE with no one to read it";
    case SIGALRM :    return "ALaRM clock";
    case SIGTERM :    return "software TERMination signal from kill";
    case SIGURG  :    return "URGent condition on IO channel";
    case SIGSTOP :    return "sendable STOP signal not from tty";
    case SIGTSTP :    return "Tty SToP signal";
    case SIGCONT :    return "CONTinue a stopped process";
    case SIGCHLD :    return "to parent on CHiLD stop or exit";
    case SIGTTIN :    return "to readers pgrp upon background TTy read IN";
    case SIGTTOU :    return "like TTin for OUtput";
    case SIGXCPU :    return "eXceeded CPU time limit";
    case SIGXFSZ :    return "eXceeded File SiZe limit";
    case SIGVTALRM:   return "Virtual Time ALaRM";
    case SIGPROF :    return "PROFiling time alarm";
    case SIGUSR1 :    return "USeR 1";
    case SIGUSR2 :    return "USeR 2";


#if  (!defined(_POSIX_C_SOURCE) || defined(_DARWIN_C_SOURCE))
    case SIGIO      :    return "Input/Output possible signal";
    case SIGWINCH   :    return "WINdow size CHanges";
    case SIGINFO    :    return "INFOrmation request";
#endif

    default:        return "unknown";
        break;
    }
}
#pragma mark -
#pragma mark ReadStream functions
IOReturn openDeviceOpenReadStream(const char *uri, const char *printFile, int copies)
{
    // try to match the provided uri with an available USB device, and (if a match is found) 
    // output the data at printFile to the USB
    
    TBUSBInterfaceContext   tbContext;
    CFURLRef                readURL;
    const UInt8 *           path=NULL;
    const char *            eURI;
    IOReturn                ioResult=kIOReturnSuccess;
    int                     returnValue = 1; // default to failure
    
    CUPS_DEBUG("starting up v%s\n",revStr());
        
    // we need unbuffered error messages for the logging facility to function properly
    setbuf(stderr, NULL);

    // register a common signal handler so we can clean up the globals when 
    // the command line process is interupted
    const char *errStr="Failed to set a signal handler for \"%s\".\n";

    int aSignal, signalList[10]={SIGUSR1, SIGUSR2, SIGINT, SIGTERM, SIGHUP, SIGPIPE, SIGQUIT, SIGABRT, SIGTSTP, 0};
    int *signalPtr = signalList;
    while(aSignal=*(signalPtr++))
    {
        if (signal(aSignal, signalHandler) == SIG_ERR)
            fprintf(stderr, errStr, strForSignal(aSignal));
    }

    // set the input file (usually stdin)
    if (NULL == printFile || (strcasecmp(printFile, "-") == 0))
    {
        path = (const UInt8 *) "/dev/fd/0";
        CUPS_DEBUG("reading data from stdin.\n");
    }
    else
    {
        path = (const UInt8 *) printFile;
        CUPS_DEBUG("reading data from file \"%s\".\n", printFile);
    }
    
    eURI=getenv("DEVICE_URI");
    while(1)
    {
        if(uri && (strstr(uri, "usb://") == uri))
        {
            CUPS_DEBUG("using a usb://... device uri\n");
            break;
        }
        else if(uri && (strstr(uri, DEVICE_URI_PREFIX) == uri))
        {
            CUPS_DEBUG("using a " DEVICE_URI_PREFIX "... device uri\n");
            break;
        }
        else if (uri == eURI)
        {
            CUPS_DEBUG("failed to find a valid device uri!\n");
            return kIOReturnBadArgument;
        }
        uri = eURI;
    }
    // initialize the context struct
    initializeContext(&tbContext);
    
    // set the deviceURI
    tbContext.deviceURIString = CFStringCreateWithCString(kCFAllocatorDefault, uri, kCFStringEncodingUTF8);

    // check for any options embedded in the uri
    parseOptionsInURI(uri, &tbContext);

    // attempt to match a device for the provided URI
    CUPS_STATE_SET("connecting-to-device");

    waitForDevice(&tbContext, uri);

    // verify 
    if (kIOReturnSuccess != ioResult || NULL == tbContext.interface)
    {
        CUPS_ERROR("The Printer is not available.\n");
        return kIOReturnNoDevice;
    }
    else
    {
        CUPS_DEBUG("got an interface <%p> for the USB device %.8x.\n", tbContext.interface, tbContext.deviceObject);
    }
    
    // add a notification for unexpected device removal
//    watchDevice(&tbContext);
    
    // check for a known manufacturer (for status reporting)
    examineDeviceForContext(&tbContext);
    
//    // Now we have an interface. Try to open it and get its properties
//    ioResult=openUSBInterfaceForContext(&tbContext);
//    // check the result
//    if (kIOReturnSuccess == ioResult && kUSBInterfaceIsOpen == tbContext.interfaceStatus)
//    {        
        // try to create a CFURL for the input file
        readURL = CFURLCreateFromFileSystemRepresentation(NULL, path, (CFIndex)strlen((const char *)path), false);
        // verify it
        if (NULL == readURL)
        {
            CUPS_DEBUG("unable to create a CFURL for file \"%s\".\n",  path );
        }
        else
        {
            // try to create a CFReadStream
            tbContext.readStream=CFReadStreamCreateWithFile (NULL, readURL);
            
            //done with the URL
            DESTROY_CFTypeRef(readURL);

            // check the readStream
            if ( NULL == tbContext.readStream)
                CUPS_DEBUG("unable to create a readStream from CFURL for file \"%s\".\n", path );
            else
            {
                // Now we have a valid readStream

                // get an interface asynceventsource and add it to the run loop
                ioResult = (*tbContext.interface) -> CreateInterfaceAsyncEventSource(tbContext.interface, &tbContext.interfaceAsyncSource);
                if (ioResult || NULL == tbContext.interfaceAsyncSource)
                {
                    CUPS_DEBUG("failed to create an asyncEventSource: %s.\n", strForIOReturn(ioResult));
                    tbContext.interfaceAsyncSource=NULL;
                }
                else
                {
                    //Add the InterfaceAsyncEventSource to our run loop
                    CFRunLoopAddSource(CFRunLoopGetCurrent(), tbContext.interfaceAsyncSource, kCFRunLoopCommonModes);
                }
                
                // set the readStream client
                setReadStreamClientForContext(&tbContext);

                // add the readStream to the runloop
                CFReadStreamScheduleWithRunLoop (tbContext.readStream, CFRunLoopGetCurrent(), kCFRunLoopCommonModes);
                // and open the readStream
                if (tbContext.dataArray && tbContext.interfaceAsyncSource && CFReadStreamOpen(tbContext.readStream))
                {
                    // we want to time out if there are never any readstream callbacks.
                    // otherwise, the runloop would never stop!
                    if (setReadStreamTimerForContext(&tbContext))
                    {
                        // get a copy of the runloop modes
                        tbContext.runLoopModes=CFRunLoopCopyAllModes(CFRunLoopGetCurrent());
                        // CFShow(tbContext.runLoopModes);
                        
                        // get the device URI
                        getDeviceIDForContext(&tbContext);
                        
                        setWriteStream("/dev/fd/3", &tbContext);
                        
                        // now start the runloop
                        CFRunLoopRun();

                        // we are all done. Be sure to clean things up ...
                    }
                }
                else
                {
                    CFStreamError streamError=CFReadStreamGetError(tbContext.readStream);
                    CUPS_STATE_SET("No data error");
                    CUPS_DEBUG("unable to open file for reading \"%s\".; domain=%d; error=%d;\n",  path, (int)streamError.domain, (int)streamError.error );
                }

                // we are all done. Be sure to clean things up...
            }
        }
//    }
//    else
//    {
//        // we failed to open the interface successfully
//        CUPS_STATE_SET("offline-error");
//        CUPS_ERROR("The Printer could not be used.\n");
//    }

    // clean up everything
    destroyContext(&tbContext);
	
    // verify the status
    if (kIOReturnNotFound == tbContext.readStatus && kIOReturnSuccess == tbContext.writeStatus)
    {
        CUPS_DEBUG("successful transfer complete; read %lu bytes; wrote %lu bytes in %lu transactions.\n",tbContext.readByteCount, tbContext.writeByteCount, tbContext.completedCount);
        if (0 == tbContext.readByteCount)
        {
            //special case for no data
            CUPS_STATE_CLEAR("connecting-to-device");
        }
        returnValue = 0; //success
    }
    else
    {
        CUPS_STATE_SET("Backend communication error");
        CUPS_ERROR("Printing ended unexpectedly.\n");
        // try to reset the printer
//        CUPS_DEBUG("Attempting to reset printer; result: %s.\n", strForIOReturn(usbPrinterSoftReset(tbContext.interface)));

        CUPS_DEBUG("unsuccessful transfer; read %lu bytes; wrote %lu bytes in %lu transactions.\n",tbContext.readByteCount, tbContext.writeByteCount, tbContext.completedCount);
        CUPS_DEBUG("transfer failed with readStatus: %s [%d] writeStatus:%s [%d].\n", strForIOReturn(tbContext.readStatus), tbContext.readStatus, strForIOReturn(tbContext.writeStatus), tbContext.writeStatus);
    }

    return(returnValue);
}
IOReturn copyUSBIInterfaceForURIForContext(TBUSBInterfaceContext * tbContext, const char * uri)
{
    int                         i;                      // loop counter

    CFMutableDictionaryRef      deviceIDDict = NULL;
    IOReturn                    ioResult = kIOReturnNoDevice;
    CFTypeRef *                 allKeys=NULL;
    CFTypeRef *                 allValues=NULL;
    CFStringRef                 deviceIDString;
    CFStringRef                 deviceURI=NULL;
    int                         match=0;

    CUPS_DEBUG("attempting to match a USB device for device URI \"%s\".\n", uri);

    // create a dictionary of deviceIDs for any available devices.
    // This function returns a dictionary with pointers to valid device
    // interfaceInterface objects as member values and deviceIDs as member keys.
    // Adding the keys and values to the CFDict implicitly retains them.
    // Releasing the CFDict releases all the retained keys and values.

    deviceIDDictionaryCreate(&deviceIDDict);
    
    // check for any valid deviceIDs in the return dict
    if (NULL != deviceIDDict)
    {
        int dictCount = CFDictionaryGetCount(deviceIDDict);
        // allocate an array of all keys in the dict
        // the keys are the deviceIDs
        allKeys= malloc(dictCount*sizeof(CFTypeRef *));
        if (allKeys != NULL)
        {
            allValues = malloc(dictCount*sizeof(CFTypeRef *));
        }
        if (allValues != NULL)
        {
            CFDictionaryGetKeysAndValues(deviceIDDict, allKeys, allValues);
            for(i=0; i<dictCount; i++)
            {
                // list uri for each deviceID
                deviceIDString = allKeys[i];
                if (deviceIDString)
                {
                    // decode the deviceURI from the IEEE 1284 deviceID
                    decodeDeviceIDCreate(deviceIDString, &deviceURI, NULL, NULL, NULL);
                    if (deviceURI)
                    {
                        //compare the deviceURI from the deviceIDString with the one passed in argv[0]
                        if (CFStringCompareWithOptions(tbContext->deviceURIString, deviceURI, CFRangeMake(0,CFStringGetLength(deviceURI)), 0) == kCFCompareEqualTo)
                        {
                            // we have a match
                            match = 1;
                            CUPS_DEBUG("found full match for USB device with device URI \"%s\".\n", uri);
                        }
                        else
                        {
                            match = 0;
                            // look for a partial match at a different location
                            CFRange shortRange = CFStringFind(deviceURI, CFSTR("?location="), 0);
                            if(0 < shortRange.length)
                            {
                                // we need to create a substring and use that to match against
                                shortRange.length = shortRange.location;
                                shortRange.location = 0;
                                CFStringRef sstr = CFStringCreateWithSubstring(NULL, deviceURI, shortRange);

                                if(kCFCompareEqualTo == CFStringCompareWithOptions(tbContext->deviceURIString, sstr, shortRange, kCFCompareAnchored))
                                {
                                    match = 2;
                                    CUPS_DEBUG("found partial match for USB device with device URI \"%s\".\n", uri);
                                }

                                DESTROY_CFTypeRef(sstr);
                            }
                        }

                        CFRelease(deviceURI);
                        deviceURI=NULL;

                        if(match)
                        {
                            DESTROY_CFTypeRef(tbContext->deviceIDString);
                            tbContext->deviceIDString = CFRetain(deviceIDString);
                            // get the interfaceInterface (retain it later)
                            tbContext->interface=(IOUSBInterfaceInterface190 **)allValues[i];

                            if(1 == match)
                            {
                                // exit the loop for a fully matching device
                                break;
                            }
                        }
                    }
                }
            }
            if (NULL != tbContext->interface)
            {
                int refCount;
            
                // "retain" the interface; returns the refcount which should be 2
                refCount=(*tbContext->interface)->AddRef(tbContext->interface);
                if (2 > refCount)
                {
                    CUPS_DEBUG("interfaceInterface retain count is %d (should be > 1)\n",refCount);
                    tbContext->interface=NULL;
                }
                else
                {
                    ioResult = kIOReturnSuccess;
                    CUPS_DEBUG("sucessfully retained the interfaceInterface\n");
                }

            }
            // free all the other allocd items
            // while trying to send the job
            free(allValues);
            allValues=NULL;
        }
        if (allKeys)
        {
            free(allKeys);
            allKeys=NULL;
        }
        // the CFDict now releases all retained interfaceInterface objects upon release
        // rememeber to release the dict
        CFRelease(deviceIDDict);
        deviceIDDict=NULL;
    }
    
    return ioResult;
}
IOReturn openUSBInterfaceForContext(TBUSBInterfaceContext * tbContext)
{
    IOReturn                    ioResult;

    // try to open the interface ...
    CUPS_DEBUG("attempting to open USB interface for device %.8x ... ",tbContext->deviceObject);
    
    ioResult = waitForInterface(tbContext);
    
    // if we opened the interface then get its properties
    if (kIOReturnSuccess == ioResult && kUSBInterfaceIsOpen == tbContext->interfaceStatus)
    {
        //finish out our log message
        fprintf(stderr, "success!\n");
        
        UInt8 interfaceProtocol;
        UInt8 interfaceNumber, currentInterfaceNumber;
        UInt8 interfaceAlternate, currentInterfaceAlternate;
        UInt8   numEndpoints, bulkIN=0, bulkOUT=0;
        UInt8   pipeRef, direction, number, transferType, interval;
        UInt16  maxPacketSize;

        // verify the interface ...
        // we need to ensure that we have the correct interface. USB printers must have
        // at least one configuration but could have more, and the configuration must
        // have at least one interface. Printer interfaces are identified by the
        // bInterfaceProtcol where 00=undefined, 01=unidirectional,02=bi-directional, 03=1284.4, ...
        // the bInterfaceProtcol is stored in the interface descriptor which is included
        // with the configuration descriptor for the configuration of which it is a part.
        // so first we get the config descriptor and go from there

        if (ioResult = (*tbContext->interface)->GetConfigurationValue(tbContext->interface, &(tbContext->configurationIndex)))
            CUPS_DEBUG("Failure to get ConfigurationValue on the open USB device; error=[%d]\n", ioResult);
        else if (ioResult = (*tbContext->interface)->GetInterfaceProtocol(tbContext->interface, &interfaceProtocol))
            CUPS_DEBUG("Failure to get interfaceProtocol on the open USB device; error=[%d]\n", ioResult);
        else if (ioResult = (*tbContext->interface)->GetInterfaceNumber(tbContext->interface, &interfaceNumber))
            CUPS_DEBUG("Failure to get interfaceNumber on the open USB device; error=[%d]\n", ioResult);
        else if (ioResult = (*tbContext->interface)->GetAlternateSetting(tbContext->interface, &interfaceAlternate))
            CUPS_DEBUG("Failure to get interfaceAlternate on the open USB device; error=[%d]\n", ioResult);
        else if (2 != interfaceProtocol)
        {
            // always try to use the interface with interfaceProtocol==2 as some models of printer
            // provide an interface with interfaceProtocol==1, but the interface is non-functional
            // if the interface with interfaceProtocol==2 exists then it should work, if it doesn't
            // exist then the default interface gets used (and hopefully the default interface should
            // always work in that case).
            CUPS_DEBUG("current interfaceProtocol=%d (configNum=%d;interfaceNumber=%d;interfaceAlternate=%d). Attempting to switch interfaces.\n", interfaceProtocol, tbContext->configurationIndex, interfaceNumber, interfaceAlternate);
            // switch to interfaceProtocol 2 (this may need to be changed for certain devices)
            currentInterfaceAlternate = interfaceAlternate;
            currentInterfaceNumber = interfaceNumber;
            // this next function returns by reference the interface alternate for interface protocol 2
            // or else it returns the interfaceNumber and interfaceAlternate unmodified
            usbInterfaceGetConfigurationDescriptor(tbContext->interface, &interfaceNumber, &interfaceAlternate);
            if (interfaceAlternate != currentInterfaceAlternate)
            {
                CUPS_DEBUG("found a compatible alternate interface;\n\tattempting to SetAlternateInterface for value [%d] ... ", (int)interfaceAlternate);
            
                ioResult = (*tbContext->interface)->SetAlternateInterface(tbContext->interface, interfaceAlternate);
                if (kIOReturnSuccess == ioResult)
                {
                    fprintf(stderr, "success.\n");
                }
                else
                {
                    fprintf(stderr, "failed!\n");
                    CUPS_DEBUG("* error: failure to SetAlternateInterface for value \"%d\" on the open USB device; error= %s [%x]\n", (int)interfaceAlternate, strForIOReturn(ioResult), ioResult);
                }
            }

            if (kIOReturnSuccess == ioResult)
            {
                if (ioResult = (*tbContext->interface)->GetInterfaceProtocol(tbContext->interface, &interfaceProtocol))
                    CUPS_DEBUG("Failure to get interfaceProtocol on the open USB device; error=[%d]\n", ioResult);
                else if (ioResult = (*tbContext->interface)->GetAlternateSetting(tbContext->interface, &interfaceAlternate))
                    CUPS_DEBUG("Failure to get interfaceAlternate on the open USB device; error=[%d]\n", ioResult);
                else if (ioResult = (*tbContext->interface)->GetInterfaceNumber(tbContext->interface, &interfaceNumber))
                    CUPS_DEBUG("Failure to get interfaceNumber on the open USB device; error=[%d]\n", ioResult);
            }
        }

        if (kIOReturnSuccess == ioResult)
        {
            CUPS_DEBUG("Using interface with interfaceProtocol=%d;configNum=%d;interfaceNumber=%d;interfaceAlternate=%d.\n", interfaceProtocol, tbContext->configurationIndex, interfaceNumber, interfaceAlternate);

            //tbContext->configurationIndex=configIndex;//GetCon
            tbContext->interfaceProtocol=interfaceProtocol;
            tbContext->interfaceNumber=interfaceNumber;
            tbContext->interfaceAlternate=interfaceAlternate;

            // the interface is open. we will send the file data on BULK OUT endpoint but
            // first we need to find the endpoint for BULK_OUT
            if (ioResult=(*tbContext->interface)->GetNumEndpoints( tbContext->interface, &numEndpoints))
                CUPS_DEBUG("failure for GetNumEndpoints on the open USB device; error=[%d]\n", ioResult);
            else
            {
                CUPS_DEBUG("examining endpoints for interface %d alternate %d.\n", tbContext->interfaceNumber, tbContext->interfaceAlternate);    
                for (pipeRef=0;pipeRef < numEndpoints;)
                {   // we start pipeRef at 1 because 0 is always the control pipe
                    pipeRef++;

                    ioResult=(*tbContext->interface)->GetPipeProperties(tbContext->interface,  pipeRef, &direction, &number, &transferType, &maxPacketSize, &interval);
                    if (kIOReturnSuccess == ioResult && kUSBBulk == transferType)
                    {
                        if (kUSBOut == direction)
                        {
                            bulkOUT=pipeRef;
                        }
                        else if (kUSBIn == direction)
                        {
                            bulkIN=pipeRef;
                        }
                    }
                    CUPS_DEBUG2("ne=%d, pRef=%d, dir=%d, num=%d, trans=%d, maxPacketSize=%d, interval=%d\n", numEndpoints, pipeRef, direction, number, transferType, maxPacketSize, interval);
                }
                
                // verify that we got the bulkIN pipe
                if (bulkIN > numEndpoints)
                {
                    bulkIN = 0;
                }
                // verify that we got the bulkOUT pipe
                if (0 < bulkOUT && ! (bulkOUT > numEndpoints))
                {
                    CUPS_DEBUG("success in getting BULK OUT\n");

                    //tbContext->numEndpoints = numEndpoints;
                    tbContext->bulkOUT = bulkOUT;
                    tbContext->bulkIN = bulkIN;
                    // mark the interface as Open
                    tbContext->interfaceStatus = kUSBInterfaceIsOpen;
                }
                else
                {
                    ioResult=kIOReturnNotWritable;
                    CUPS_DEBUG("Failed to get BULK OUT [%d]\n", ioResult);
                }
            }
        }
        // check for errors
        if (kIOReturnSuccess != ioResult)
        {
            // close the interface
            IOReturn ioError;
            if(ioError=(*tbContext->interface)->USBInterfaceClose(tbContext->interface))
                CUPS_DEBUG("Failed to close interface [%d]\n", ioError);
            else
                tbContext->interfaceStatus = kUSBInterfaceIsClosed;
        }
        else
        {
            // now we have an open,valid interface for sending data to the USB device
            CUPS_STATE_CLEAR("connecting-to-device");
        }
    }
    else
    {
        //finish out our log message
        fprintf(stderr, "failed!\n");
    }
    
    return ioResult;
}
#pragma mark -
#pragma mark runloop source callbacks
void readStreamCallBack(CFReadStreamRef readStream, CFStreamEventType eventType, void *context)
{
    TBUSBInterfaceContext * tbContext=context;
    CFIndex                 dataCount=0;
    CFStreamError           streamError;
    CFStreamStatus          streamStatus=CFReadStreamGetStatus(readStream);
	
//	CUPS_DEBUG("control entering readStreamCallBack \n");
    
    // set the callback-in-progress bit
    tbContext->callbackInProgress |= readStreamCallBack_Dirty;

    // check for pending time-out and invalidate the readStreamTimer, if necessary
    if(NULL != tbContext->readStreamTimer)
    {
        // invalidate readStreamTimer and release it
        CFRunLoopTimerInvalidate(tbContext->readStreamTimer);
        CFRelease(tbContext->readStreamTimer);
        tbContext->readStreamTimer=NULL;
        
        // clear the timeout status
        if (kIOReturnTimeout == tbContext->readStatus)
            tbContext->readStatus = kIOReturnSuccess;
    }

    // the readStream has a message for us
    CUPS_DEBUG2("received %s for readStream\n", strForCFEventType(eventType));
    switch(eventType)
    {
    
    case kCFStreamEventHasBytesAvailable:
    
        // we have data to read and send to the USB device
        
        // first check to see if we need to wait for the device to consume the pending data.
        // we do this to conserve CPU resources (memory)
        // get the current count of objects in the data array
        dataCount=CFArrayGetCount(tbContext->dataArray);
// changing threshold to accumulated data rather than count
//        if (dataCount > tbContext->maxQueuedData)
        if ((tbContext->readByteCount - tbContext->writeByteCount) > tbContext->readStreamReadSize)
        {
            // we have reached the limit for queued data objects in the array
            // we need to temporarily "lock" reading (artificially lock, that is)
            // set a status indicator so we'll know to resume later.
            tbContext->readStatus = kIOReturnLockedRead;
            
            CUPS_DEBUG2("temporarily locking reads; %d queued objects (%d bytes).\n", (int)dataCount, (int)(tbContext->readByteCount - tbContext->writeByteCount));
            break;
        }
        
        // read available data from the readStream
        readFromReadStreamForContext(readStream, tbContext);

        break;
        
    case kCFStreamEventErrorOccurred:
        // check the error
        streamError=CFReadStreamGetError(readStream);
        CUPS_DEBUG("kCFStreamEventErrorOccurred; domain=%d; error=%d; stream status=%s;\n", (int)streamError.domain , (int)streamError.error, strForCFStreamStatus(streamStatus));    
        tbContext->readStatus=kIOReturnNoMemory;
        break;
        
    case kCFStreamEventEndEncountered:
        // we're finished reading data
        tbContext->readStatus=kIOReturnNotFound;
        break;
        
    case kCFStreamEventOpenCompleted:
        // we're ready to start
        break;
        
    default: // combinations of other events
        break;
    }
    
    // check the read and write status and stop the runloop if necessary
    switch(tbContext->readStatus)
    {
    case kIOReturnNotFound:
        // The readstream is exhausted
        // close the stream ; this removes it from the run loop
        CFReadStreamClose(readStream);
		
		// we don't want to stop the runloop just yet because there may be
		// pending queued data to be written.
        
    case kIOReturnSuccess:
    case kIOReturnLockedRead:

        // keep going, provided the write status checks out
        if (kIOReturnSuccess == tbContext->writeStatus || kIOReturnTimeout == tbContext->writeStatus)
            break;

    default:
        // for all other status conditions we need to stop the run loop

        // clear the callback-in-progress bit
        tbContext->callbackInProgress ^= readStreamCallBack_Dirty;

    CUPS_DEBUG("aborting job from readStreamCallback with error ws=\"%s\" .\n", strForIOReturn(tbContext->writeStatus));
        stopRunLoopForContext(tbContext);
        break;
    }

    // clear the callback-in-progress bit
    tbContext->callbackInProgress ^= readStreamCallBack_Dirty;

    // handle any pending signal
    if (gSignal)
        handleSignalForContext(tbContext);

//	CUPS_DEBUG("control exiting readStreamCallBack \n");
}
void writeStreamCallBack(CFWriteStreamRef writeStream, CFStreamEventType eventType, void *context)
{
	CUPS_DEBUG2("control entering %s\n",__func__);

    TBUSBInterfaceContext * tbContext=context;
    CFStreamError           streamError;
    CFStreamStatus          streamStatus=CFWriteStreamGetStatus(writeStream);
	
    // validate the context
    if (NULL == tbContext || TB_VALID_CONTEXT_KEY != tbContext->validator)
    {
        CUPS_DEBUG("Internal context inconsistency error; %s;\n",__func__);
        return;
    }
    
    // set the callback-in-progress bit
    tbContext->callbackInProgress |= writeStreamCallback_Dirty;
    
    // the write stream has a message for us
    CUPS_DEBUG("received %s for writeStream\n", strForCFEventType(eventType));

    switch(eventType)
    {
    
    case kCFStreamEventCanAcceptBytes:
    
        // the backchannel stream is ready for bytes
//        CFWriteStreamWrite(writeStream, tbContext->backchannelBuffer, tbContext->backchannelBufferSize);

        break;
        
    case kCFStreamEventErrorOccurred:
        // check the error
        streamError=CFWriteStreamGetError(writeStream);
        if(1 == streamError.domain)
        {
            CUPS_DEBUG("kCFStreamEventErrorOccurred; error %d \"%s\"\n", (int)streamError.error,strForErrno((int)streamError.error));
        }
        else
        {
            CUPS_DEBUG("kCFStreamEventErrorOccurred; domain=%d; error=%d; stream status=%s;\n", (int)streamError.domain , (int)streamError.error, strForCFStreamStatus(streamStatus));
        }
        break;
        
    case kCFStreamEventEndEncountered:
        // we're finished writing data
        break;
        
    case kCFStreamEventOpenCompleted:
        // we're ready to start
        break;
        
    default: // combinations of other events
        break;
    }

    // clear the callback-in-progress bit
    tbContext->callbackInProgress ^= writeStreamCallback_Dirty;

    // handle any pending signal
    if (gSignal)
        handleSignalForContext(tbContext);

	CUPS_DEBUG2("control exiting %s\n",__func__);
}
void IOAsyncReadPipeCallback1( void *context, IOReturn ioResult, void *numBytesRead)
{
    // This is the callback function for the asynchronous read of data from the device
    // (this is the backchannel data). The callback is called only when the async read
    // returns, which happens when data has been read successfully, or on error.
    
    TBUSBInterfaceContext * tbContext=context;
    static int              callbackCount=0;
    UInt32                  byteCount = (UInt32) numBytesRead;
    
//    CUPS_DEBUG2("control entering %s \n",__func__);

    // validate the context
    if (NULL == tbContext || TB_VALID_CONTEXT_KEY != tbContext->validator)
    {
        CUPS_DEBUG("Internal context inconsistency error entering %s;\n",__func__);
        return;
    }
    
    // set the callback-in-progress bit
    tbContext->callbackInProgress |= IOAsyncReadPipeCallback1_Dirty;

    // increment the read callback static counter 
    callbackCount ++;
    
    CUPS_DEBUG("backchannel async read #%d returned with %lu bytes; status: %s [%X];\n", callbackCount, byteCount, strForIOReturn(ioResult), ioResult);    

    if(kIOReturnSuccess==ioResult && 0 < byteCount)
    {
        // post a backchannel notification for distributed observers (upstream filters)
        CFDataRef bcData = CFDataCreate(kCFAllocatorDefault, tbContext->backchannelBuffer, byteCount);
        if(bcData)
        {
            CFDictionaryRef notifDict = CFDictionaryCreate(kCFAllocatorDefault, (void *)&(tbContext->deviceURIString), (void *)&bcData, 1, &kCFTypeDictionaryKeyCallBacks, &kCFTypeDictionaryValueCallBacks);
            if(notifDict)
            {
                CFStringRef notifyStr = CFStringCreateWithFormat(NULL, NULL, CFSTR("DEBUG: %s:distributed notification: name=\"%@\" object=\"%@\" userinfo=dict\n"), APP_NAME_STRING, CFSTR("backchannel"),tbContext->deviceURIString);
                CUPS_DEBUG("Posting a %d byte backchannel data distributed notification\n",(int)byteCount);
                fputCFString(notifyStr, stderr);
                DESTROY_CFTypeRef(notifyStr);
                CFNotificationCenterPostNotification(CFNotificationCenterGetDistributedCenter(), CFSTR("backchannel"), tbContext->deviceURIString, notifDict, false);
                CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(), tbContext->deviceURIString, NULL, notifDict, false);
                CFRelease(notifDict);
            }
            CFRelease(bcData);
        }
        // check device properties and try to parse return data
        // probably we should OR the deviceProperties with a model mask (of at least 256 bits)
        // and switch on the result ... for now we do this
        if ( kEpsonPrinterDevice == tbContext->deviceProperties )
        {
            epsonPrinterParseInkData(tbContext->backchannelBuffer,  (unsigned) byteCount);
        }
        else if ( kHPPrinterDevice == tbContext->deviceProperties )
        {
            ;//hpPrinterParseInkData(tbContext->backchannelBuffer,  unsigned byteCount)

            // do nothing. HP printers return status info in the device ID, not on the
            // backchannel.
        }
        if (kPrinterUtility & tbContext->deviceProperties)
        {
            // write the raw data to stdout
            while (fwrite(tbContext->backchannelBuffer, sizeof(unsigned char), byteCount, stdout) != byteCount)
                if (errno != EAGAIN || errno != EINTR)
                {
                    CUPS_DEBUG("error writing printer response data to stdout.\n");
                    break;
                }
        }
        else if(0);
        // write to the backchannel
        else if (kBackChannelDevice == tbContext->deviceProperties && (NULL != cupsBackChannelWrite))
        {
            cupsBackChannelWrite((char *)tbContext->backchannelBuffer, byteCount,1);
        }
    }
    
    // set the USBReadStatus
    tbContext->USBReadStatus=ioResult;

    if ( kIOReturnNotFound == tbContext->readStatus && tbContext->writeByteCount == tbContext->readByteCount)
    {
        tbContext->USBReadStatus=kIOReturnAborted;
        CUPS_DEBUG("Aborting backchannel read ... we appear to be done.\n");
        stopRunLoopForContext(tbContext);
    }
    else if(kBackChannelSignalRead & tbContext->deviceProperties); // do nothing ... wait for a signal
    else if(kIOReturnSuccess == ioResult)
    {
        //start another read
        CUPS_DEBUG("Reading device for backchannel data in %s\n",__func__);
        readAsyncFromUSBInterfaceForContext(tbContext);
    }

    // clear the callback-in-progress bit
    tbContext->callbackInProgress ^= IOAsyncReadPipeCallback1_Dirty;

    // check if we have been waiting for this read to return 
    if ( (kBackChannelDevice & tbContext->deviceProperties) && kIOReturnNotFound == tbContext->readStatus && tbContext->writeByteCount == tbContext->readByteCount)
    {
        // make sure we stop
        if (kIOReturnTimeout==ioResult)
            tbContext->USBReadStatus=kIOReturnAborted;
        stopRunLoopForContext(tbContext);
    }
//	CUPS_DEBUG2("control exiting %s\n",__func__);
}
void IOAsyncWritePipeCallback2( void *context, IOReturn ioResult, void *numBytesWritten)
{
//    CUPS_DEBUG2("control entering %s \n",__func__);


    TBUSBInterfaceContext * tbContext=context;
    static unsigned         writeCallCount=0;
    UInt32                  realByteCount = (UInt32) numBytesWritten;
    CFIndex                 dataByteCount=0;
    CFIndex                 dataCount=0;
//	UInt8 *					buffer;
//	const UInt8 *			dataBytePtr;
    CFDataRef               byteData=NULL;
    CFDataRef               unwrittenData=NULL;

	
    // validate the context
    if (NULL == tbContext || TB_VALID_CONTEXT_KEY != tbContext->validator)
    {
        CUPS_DEBUG("Internal context inconsistency error; IOAsyncWritePipeCallback2;\n");
        return;
    }
    
    // set the callback-in-progress bit
    tbContext->callbackInProgress |= IOAsyncWritePipeCallback2_Dirty;
    
    // increment the write call static counter
    writeCallCount += 1;
    
    // get the current count of objects in the data array
    dataCount=CFArrayGetCount(tbContext->dataArray);
	
    // get the current data object
    if (0 < dataCount)      // this should always be true
        byteData=(CFDataRef)CFArrayGetValueAtIndex(tbContext->dataArray,0);
        
    // check the status of the write
    switch (ioResult)
    {
    case kIOReturnSuccess:
    
        // increment the completed transaction counter
        tbContext->completedCount += 1;
		
        if (0 < tbContext->recentWriteTimeoutCount)
        {
            // if we are recovering from a timeout condition be sure to clear any `error' string
            tbContext->recentWriteTimeoutCount = 0;
            CUPS_INFO("Printing ...\n");
        }

        // record the number of bytes in the most recent transaction
        tbContext->writeByteCount += realByteCount;

        // verify the number of bytes in the most recent transaction
        dataByteCount=CFDataGetLength(byteData);
        if (dataByteCount == realByteCount)
        {			
            CUPS_DEBUG2("successful write #%lu (of %d attempts); bytes=%ld;%ld objects remaining;\n", tbContext -> completedCount, writeCallCount,  realByteCount, dataCount-1);    
        }
        else if (dataByteCount > realByteCount)
        {
            // the callback returned successfully but wrote fewer bytes than expected.
            CUPS_DEBUG("short write! (#%lu of %d attempts); wrote %ld bytes (expected %ld bytes);\n", tbContext -> completedCount, writeCallCount,  realByteCount, dataByteCount);
            
            // create a new data object containing the unwritten bytes and add it to the front of the queue
            unwrittenData=CFDataCreate(NULL, CFDataGetBytePtr(byteData) + realByteCount, dataByteCount - realByteCount);
            if (NULL != unwrittenData)
            {
                // insert it at the 1 spot -- the partially written data at index 0 will be removed in the next step
                CFArrayInsertValueAtIndex(tbContext->dataArray, 1, unwrittenData);
                CFRelease(unwrittenData);
                unwrittenData = NULL;            
            }
            else
            {
                // failed to create a data object with the remaining bytes
                CUPS_DEBUG("memory allocation error attempting to create a new CFData object with bytes remaining from most recent short write;\n");
            }
        }
        else
        {
            // the callback reported writing more bytes than the data object length!
            CUPS_DEBUG("spurious write! (#%lu of %d attempts); wrote %ld bytes, but sent only %ld bytes!\n", tbContext -> completedCount, writeCallCount,  realByteCount, dataByteCount);    
        }

        // the last write was successful so set the status and ...
        tbContext->writeStatus=ioResult;
        
        // ... remove the corresponding data object from the data array
        CFArrayRemoveValueAtIndex (tbContext->dataArray, (CFIndex) 0);

        // get the current count of objects in the data array
        dataCount=CFArrayGetCount(tbContext->dataArray);

        // start reading backchannel data (if requested)
        if(kBackChannelSignalRead & tbContext->deviceProperties && SIGUSR1 == gSignal)
        {
            //this signal indicates that we should read the backchannel once and write back any data
            CUPS_DEBUG("now reading backchannel data one time\n");
            readAsyncFromUSBInterfaceForContext(tbContext);
            gSignal = 0;
        }

        // for any existing objects
        if (0 < dataCount)
        {
            // begin an async write for the next data object
            writeAsyncToUSBInterfaceForContext(tbContext);
            
            dataCount=CFArrayGetCount(tbContext->dataArray);
            // verify the write status for the call to writeAsyncToUSBInterfaceForContext
            if (kIOReturnSuccess != tbContext->writeStatus)
                break;
            
            break;
        }
        else
        {
            // stop the writeStatusTimer
            killWriteCompletionTimer(tbContext);
        }
        
        // if there are no more data objects in the queue we need
        // to check the readStream status to discover the reason
        if(kIOReturnSuccess == tbContext->readStatus)
        {
            // try to read any remaining data
            CUPS_DEBUG("trying to read any remaining data\n");
            readFromReadStreamForContext(tbContext->readStream, tbContext);
        }
        
        if (kIOReturnNotFound == tbContext->readStatus)
        {
            CUPS_DEBUG("writing complete.\n");
            // we've exhausted all readStream data.
            // set the write status to mark the interface as needing to be closed
            tbContext->writeStatus = kIOReturnStillOpen;
                        
            break;
        }
        else if(kIOReturnTimeout == tbContext->readStatus)
        {
            CUPS_INFO("Printer is waiting for data...\n");
        
            break;
        }
           
        // for any readStream status except kIOReturnNotFound or kIOReturnTimeout
        // (we don't want to start another readStreamTimer if we already have one running)
        // start a TTL timer for the readStream.  If we get no more data before the
        // timer fires then we give up.
        
        if( ! setReadStreamTimerForContext(tbContext))
        {
            // we couldn't create a readStreamTimer so we should stop the runloop
            // set the appropriate status
            tbContext->writeStatus = kIOReturnError;
            CUPS_DEBUG("failed to set readstream timer...\n");
        }


        break;
    default:
        // an unexpected error occurred; log an error, then abort.
        
        CUPS_ERROR("Printing failed with error \"%s\".\n", strForIOReturn(ioResult));    
        CUPS_DEBUG("write transaction #%d returned with error = %s;\n", writeCallCount , strForIOReturn(ioResult));
        
        tbContext->writeStatus=ioResult;
        break;
    }
    // end of switch(ioResult)
    
    // check readStream status to see if we need to resume reading.
    // the readStream may be "locked" waiting for the writes to catch up
    // if the writes have consumed half of the "maxQueuedData" then
    // we should unlock the readStream and resume reading.
    if (kIOReturnLockedRead == tbContext->readStatus && ! (dataCount > (tbContext->maxQueuedData +1 ) / 2))
    {
        // we are ready to resume reading            
        // set a no-data TTL timer for the readStream
        if(setReadStreamTimerForContext(tbContext))
        {
            CUPS_DEBUG2("resuming reads; %d queued objects (%d bytes).\n", (int)dataCount, (int)(tbContext->readByteCount - tbContext->writeByteCount));
            
            // set the readStream client to accept reads
            //setReadStreamClientForContext(tbContext);

            // "unlock" the readStream status
            tbContext->readStatus = kIOReturnSuccess;
            
            // and resume reading. The readStream source will resume sending
            // "kCFStreamEventHasBytesAvailable" events as soon as we read some data.
            readFromReadStreamForContext(tbContext->readStream, tbContext);
        }
        else
        {
            // we could not create a readStreamTimer so we should stop the runloop
            // set the appropriate status
            tbContext->readStatus = kIOReturnError;
            tbContext->writeStatus = kIOReturnError;
        }
    }
    else if (kIOReturnLockedRead == tbContext->readStatus)
    {
        // try to compact multiple pending writes
        compactDataArrayFromIndexForContext(1, MAX_CHUNK_SIZE, tbContext);
    }

    // test whether we should stop the runloop; we stop on any of the following conditions:
    //    writeStatus != kIOReturnSuccess
    //     readStatus == kIOReturnError && readStatus != kIOReturnTimeout
    if (kIOReturnSuccess != tbContext->writeStatus)
    // || (kIOReturnTimeout != tbContext->readStatus && kIOReturnSuccess != tbContext->readStatus && kIOReturnLockedRead != tbContext->readStatus && kIOReturnNotFound != tbContext->readStatus))
    {
        // clear the callback-in-progress bit
        tbContext->callbackInProgress ^= IOAsyncWritePipeCallback2_Dirty;
        
        // stop the runloop
    //CUPS_DEBUG("aborting job from IOWritePipeCallback with error \"%s\" [%d] .\n", strForIOReturn(tbContext->writeStatus),tbContext->writeStatus);
        stopRunLoopForContext(tbContext);
    }

    // clear the callback-in-progress bit
    tbContext->callbackInProgress ^= IOAsyncWritePipeCallback2_Dirty;

    // handle any pending signal
    if (gSignal)
        handleSignalForContext(tbContext);

//	CUPS_DEBUG2("control exiting %s\n",__func__);
}
#pragma mark runloop observer callbacks
void observerCallback(CFRunLoopObserverRef observer, CFRunLoopActivity activity, void *info)
{
//    CUPS_DEBUG2("control entering %s \n",__func__);

    CFRunLoopStop(CFRunLoopGetCurrent());

//	CUPS_DEBUG2("control exiting %s\n",__func__);
}
#pragma mark runloop timer callbacks
void readStreamTimerCallback(CFRunLoopTimerRef readStreamTimer, void *context)
{
//    CUPS_DEBUG2("control entering %s \n",__func__);

    TBUSBInterfaceContext * tbContext=context;
        
    // validate the context
    if (NULL == tbContext || TB_VALID_CONTEXT_KEY != tbContext->validator)
    {
        CUPS_DEBUG("Internal context inconsistency error; readStreamTimerCallback;\n");
        return;
    }
    
    // block until this callback is no longer executing on any other threads
    // *** DO NOT BLOCK or call ANY BLOCKING CODE ANYWHERE ELSE in this callback ***
    while (readStreamTimerCallback_Dirty & tbContext->callbackInProgress);

    // set the callback-in-progress bit
     tbContext->callbackInProgress |= readStreamTimerCallback_Dirty;
    
    CUPS_ERROR("Printing failed; timed out waiting for data.\n");
    
    // ideally we should only close the readstream here and set the read status

    // clear the callback-in-progress bit
     tbContext->callbackInProgress ^= readStreamTimerCallback_Dirty;

    // stop the runloop 
    CUPS_DEBUG("aborting job from readStreamTimerCallback with error \"%s\" .\n", strForIOReturn(tbContext->readStatus));
    stopRunLoopForContext(tbContext);

//	CUPS_DEBUG2("control exiting %s\n",__func__);
}
void writeCompletionTimerCallback(CFRunLoopTimerRef timer, void *context)
{
//    CUPS_DEBUG2("control entering %s \n",__func__);

    TBUSBInterfaceContext   * tbContext=context;
    IOReturn                ioPrinter;
    static IOReturn         lastError=0;
    UInt8                   portStatus;
    //static unsigned         totalCallbackCount=0;
    static unsigned         recentCompletedCount=0;
    static unsigned         currentErrorCount=0;
    static int              currentDelay=0;
    bool                    shouldAbort = false;
        
    // validate the context
    if ((NULL == tbContext) || (TB_VALID_CONTEXT_KEY != tbContext->validator) || (tbContext->writeCompletionTimer != timer))
    {
        CUPS_DEBUG("Internal context inconsistency error; writeCompletionTimerCallback;\n");
        return;
    }
    
    // block until this callback is no longer executing on any other threads
    // *** DO NOT BLOCK or call ANY BLOCKING CODE ANYWHERE ELSE in this callback ***
    while (writeCompletionTimerCallback_Dirty & tbContext->callbackInProgress);

    // set the callback-in-progress bit
     tbContext->callbackInProgress |= writeCompletionTimerCallback_Dirty;
    
    // this callback function is never called unless a write operation failed to complete
	// before the specified timeout interval. Thus, we need to diagnose the failure
	// and determine if we can resolve the problem and continue (such as the case in a paper-out
	// condition), or if we need to abandon the job, reset the printer and exit.
	
	// set the write status
	tbContext->writeStatus = kIOReturnTimeout;
	tbContext->recentWriteTimeoutCount ++;
	
	// counters
	if (recentCompletedCount == tbContext->completedCount)
	{
		currentDelay +=  tbContext->writeCompletionTimeOut;
		//totalCallbackCount ++;
	}
	else
	{
		recentCompletedCount = tbContext->completedCount;
		currentDelay =  tbContext->writeCompletionTimeOut;
	}
		
	// first check the printer port status
    if(kIOUSBPipeStalled != lastError)
    {
        ioPrinter = usbPrinterGetPortStatus(tbContext->interface, &portStatus);
	}
    else
    {
        ioPrinter = lastError;
    }
	if (ioPrinter == lastError)
		currentErrorCount ++;
	else
	{
		lastError = ioPrinter;
		currentErrorCount = 1;
	}
    switch (ioPrinter)
    {
    case kIOReturnSuccess :
        // check if we are actually done
        if ( kIOReturnNotFound == tbContext->readStatus && tbContext->writeByteCount == tbContext->readByteCount)
        // reading is done and written byte count is equal to read byte count
        {
            tbContext->writeStatus = kIOReturnSuccess;
            stopRunLoopForContext(tbContext);
        }
        // reset the error count after a successful write
        if (currentDelay ==  tbContext->writeCompletionTimeOut);
            currentErrorCount = 0;
        if (60 > currentDelay)
        {
                CUPS_INFO("Waiting for the printer ... (%2d)\n", currentDelay);
                shouldAbort = false;
        }
        else
        {
                CUPS_ERROR("The printer is not responding!\n");
                shouldAbort = false;
        }
        break;
    case kIOReturnNoMedia :
		shouldAbort = false;
		switch ((currentErrorCount + 3) % 4)
		{
		default:
			CUPS_ERROR("The printer is out of paper!\n");
			break;
		case 1:
			CUPS_ERROR("To continue printing, add paper to the printer...\n");
			break;
		case 2:
			CUPS_ERROR("... then press the printer's \"Resume\" button, ...\n");
			break;
		case 3:
			CUPS_ERROR("... which may be lit with a red (or flashing) light.\n");
			break;
		}
        break;
    case kIOReturnOffline :
		shouldAbort = false;
		switch ((currentErrorCount + 3) % 4)
		{
		default:
			CUPS_ERROR("The printer is offline!\n");
			break;
		case 1:
			CUPS_ERROR("To continue printing, check the printer status panel ...\n");
			break;
		case 2:
			CUPS_ERROR("... for a button marked \"Select\" or \"Ready\" or \"Pause\" ...\n");
			break;
		case 3:
			CUPS_ERROR("... and press the button once.\n");
			break;
		}
        //CUPS_ERROR("The printer is offline; check the printer status panel and/or buttons.\n");
        break;
    case kIOUSBPipeStalled:
		shouldAbort = false;
        CUPS_DEBUG("This deviant device does not support the standard GetPortStatus request.\n");
        break;
    default:
		shouldAbort = true;
        CUPS_ERROR("The printer is reporting an error!\n");
        break;
    }
    if (shouldAbort && 180 < currentDelay)
    {
        // clear the callback-in-progress bit
        tbContext->callbackInProgress ^= writeCompletionTimerCallback_Dirty;
        CUPS_DEBUG("aborting job from writeCompletionTimerCallback with error \"%s\" .\n", strForIOReturn(ioPrinter));
        stopRunLoopForContext(tbContext);
    }
    
    // next check whether we may simply need more time
    // if this failure is from the very first write then it may be that we simply have a printer
    // with a very long initialization routine and we need to give it a little more time.
    // if this is the very first write then try to send a printer command
    if (0 == tbContext->completedCount)
    {
    }
    // assuming that the job is still in-progress
    
    //CFRunLoopTimerSetNextFireDate(deviceStatusTimer, CFAbsoluteTimeGetCurrent() + delay);
    
    if ( kIOReturnSuccess != tbContext->writeStatus)
    {
    }
    else
    {
    }
     
    // clear the callback-in-progress bit
     tbContext->callbackInProgress ^= writeCompletionTimerCallback_Dirty;
    
    // handle any pending signal
    if (gSignal)
        handleSignalForContext(tbContext);

//	CUPS_DEBUG2("control exiting %s \n",__func__);
}
void deviceStatusTimerCallback(CFRunLoopTimerRef timer, void *context)
{
//    CUPS_DEBUG2("control entering %s \n",__func__);
	
    TBUSBInterfaceContext * tbContext=context;
        
    // validate the context
    if (NULL == tbContext || TB_VALID_CONTEXT_KEY != tbContext->validator)
    {
        CUPS_DEBUG("Internal context inconsistency error; deviceStatusTimerCallback;\n");
        return;
    }
    
    // set the callback-in-progress bit
     tbContext->callbackInProgress |= deviceStatusTimerCallback_Dirty;
    
    // in this callback function we want to begin another async read
    // assuming that the job is still in-progress
	
	//CFRunLoopTimerSetNextFireDate(deviceStatusTimer, CFAbsoluteTimeGetCurrent() + delay);
    if (kIOReturnTimeout == tbContext->writeStatus);
    else if (kIOReturnNotFound == tbContext->readStatus || kIOReturnSuccess != tbContext->writeStatus)
    {
        // invalidate the timer
        CFRunLoopTimerInvalidate(tbContext->deviceStatusTimer);
        CFRelease(tbContext->deviceStatusTimer);
        tbContext->deviceStatusTimer = NULL;
    }
    else if(kBackChannelSignalRead & tbContext->deviceProperties); // do nothing for on-demand reading
    else
    {
        // try to get any status data
        if (kBackChannelDevice & tbContext->deviceProperties)
        {
            CUPS_DEBUG("Trying to get backchannel data ... is there any here? USBReadStatus=%s \n",strForIOReturn(tbContext->USBReadStatus));
            // if the last read returned
            if(kIOReturnTimeout != tbContext->USBReadStatus && kIOUSBTransactionTimeout != tbContext->USBReadStatus)
            {
                CUPS_DEBUG("Reading device for backchannel data in %s\n",__func__);
                readAsyncFromUSBInterfaceForContext(tbContext);
            }
            else if (NULL != tbContext->backchannelBuffer)
            {
                // reparse the existing data
                if (kEpsonPrinterDevice == tbContext->deviceProperties)
                    epsonPrinterParseInkData(tbContext->backchannelBuffer,  (unsigned) tbContext->backchannelBufferSize);
            }
        }
        else if (kPrinterDeviceStatusInDeviceID & tbContext->deviceProperties)
        {
            // get the deviceID for printers that report status via the deviceID
            //
            // update for 1.0.2 - do we really need to get this everytime?
            // It may be screwing up the "delicate" HP printers
            // we'll cut it out for this release version and see if it helps HP users
            // the downside is that for very large print jobs the ink levels will be checked only
            // at the start of the job and never updated, but that is rather an edge case...
            //getDeviceIDForContext(tbContext);
            
            // check for length > 0 then parse according to model
            if (0 < tbContext->deviceIDLength)
            {
                if (kHPPrinterDevice & tbContext->deviceProperties)
                    parseHPDeviceIDForStatus((char *)tbContext->deviceIDBuffer+2, tbContext->deviceIDLength);
            }
        }
    }
    // clear the callback-in-progress bit
	tbContext->callbackInProgress ^= deviceStatusTimerCallback_Dirty;
    
    // check if we are waiting on just this callback
    if ( (kBackChannelDevice & tbContext->deviceProperties) && kIOReturnNotFound == tbContext->readStatus && tbContext->writeByteCount == tbContext->readByteCount)
    {
        tbContext->USBReadStatus=kIOReturnAborted;
        CUPS_DEBUG("Aborting backchannel read ... we appear to be done.\n");
        stopRunLoopForContext(tbContext);
    }

    // handle any pending signal
    if (gSignal)
        handleSignalForContext(tbContext);

//	CUPS_DEBUG2("control exiting %s\n",__func__);
}
#pragma mark context calls
void initializeContext(TBUSBInterfaceContext * tbContext)
{
    // init the USB interface
    tbContext->interface=NULL;
    tbContext->device=NULL;
    tbContext->notifyPort=NULL;
    tbContext->objectIterator=0;
    tbContext->deviceObject=0;
    
    // init the readStream
    tbContext->readStream=NULL;
    tbContext->writeStream=NULL;

    // init the deviceStatusTimer
    tbContext->deviceStatusTimer=NULL;
    tbContext->deviceStatusReadInterval = (CFTimeInterval) 3.33;

    // init the device properties
    tbContext->deviceProperties=kGetPrinterDeviceStatus;
    if (4 == gargc)
    {
        tbContext->deviceProperties |= kPrinterUtility;
        tbContext->deviceProperties |= kBackChannelDevice;
        tbContext->deviceStatusReadInterval = (CFTimeInterval) 0.33;
    }
    if (NULL != cupsBackChannelWrite)
    {
        CUPS_DEBUG("going to do backchannel reads (CUPS 1.2+)\n");
        tbContext->deviceProperties |= kBackChannelDevice;
    }
    // init the read and write status
    tbContext->readStatus=kIOReturnSuccess;
    tbContext->writeStatus=kIOReturnSuccess;
    tbContext->USBReadStatus=kIOReturnSuccess;
    tbContext->interfaceStatus=kUSBInterfaceIsClosed;
    // init the accounting variables
    tbContext->completedCount=0;
    tbContext->readByteCount=0;
    tbContext->writeByteCount=0;
    // init backchannel buffer and validator
    tbContext->backchannelBuffer=NULL;
    tbContext->backchannelBufferSize=256;
    tbContext->validator=TB_VALID_CONTEXT_KEY;
    // init the deviceID buffer
    tbContext->deviceIDBuffer=NULL;
    tbContext->deviceIDBufferSize=256;
    tbContext->deviceIDLength=0;
    // init the readStreamTimer
    tbContext->readStreamTimer=NULL;
    tbContext->readStreamNoDataTimeOut= (CFTimeInterval) 120.0;
    // init the writeCompletionTimer
    tbContext->writeCompletionTimer=NULL;
    tbContext->writeCompletionTimeOut = (CFTimeInterval) 5.00;
    tbContext->recentWriteTimeoutCount = 0;
    // observer (for cleanup)
    tbContext->runLoopObserver=NULL;
    // init the queue limit
    tbContext->maxQueuedData=9;
    // init the callback status
    tbContext->callbackInProgress=0;
    // init the callback status
    tbContext->readStreamReadSize=BUF_SIZE_DEFAULT;//131072;//65536;// 64 pages 4096; // 2 4KB pages (8KB)

    // create the data array (CFMutableArrayRef) for the tbContext
    tbContext->dataArray=CFArrayCreateMutable (NULL, (CFIndex) 0, &kCFTypeArrayCallBacks);
    if (NULL == tbContext->dataArray)
        CUPS_DEBUG("unable to allocate a CFMutableArray.\n");
        
        
    tbContext->runLoopModes = NULL;

    // NULL the CFStringRefs
    tbContext->deviceURIString=NULL;
    tbContext->deviceIDString=NULL;

}
void removeRunLoopSourcesForContext(TBUSBInterfaceContext * tbContext)
{
    // invalidate any readStreamTimer
    if(NULL != tbContext->readStreamTimer)
    {
        // invalidate and release
        CFRunLoopTimerInvalidate(tbContext->readStreamTimer);
        CFRelease(tbContext->readStreamTimer);
        tbContext->readStreamTimer=NULL;
    }
    
    // invalidate any writeCompletionTimer
    if(NULL != tbContext->writeCompletionTimer)
    {
        // invalidate and release
        CFRunLoopTimerInvalidate(tbContext->writeCompletionTimer);
        CFRelease(tbContext->writeCompletionTimer);
        tbContext->writeCompletionTimer=NULL;
    }
    
    // invalidate any deviceStatusTimer
    if(NULL != tbContext->deviceStatusTimer)
    {
        // invalidate and release
        CFRunLoopTimerInvalidate(tbContext->deviceStatusTimer);
        CFRelease(tbContext->deviceStatusTimer);
        tbContext->deviceStatusTimer=NULL;
    }
    // close the readStream
    if (NULL != tbContext->readStream)
    {
        // close the readStream; closing a readStream removes it from
        // any run loops in which it was scheduled, but does not release
        // the stream.  We need to do that next ...
         
        CFReadStreamClose(tbContext->readStream);
        
        // release the readStream
        CFRelease(tbContext->readStream);
        tbContext->readStream=NULL;
    }
    // close the WriteStream
    if (NULL != tbContext->writeStream)
    {
        // close the writeStream; closing a writeStream removes it from
        // any run loops in which it was scheduled, but does not release
        // the stream.  We need to do that next ...
        CFStreamStatus status = CFWriteStreamGetStatus(tbContext->writeStream);
        if(kCFStreamStatusNotOpen != status && kCFStreamStatusClosed != status)
        {
            CFWriteStreamClose(tbContext->writeStream);
        }
        // release the writeStream
        CFRelease(tbContext->writeStream);
        tbContext->writeStream=NULL;
    }
                
    // release the USB interface async event source
    if (tbContext->interfaceAsyncSource)
    {
        // there is some seeming BUG when using CFRunLoopSourceInvalidate() on
        // the InterfaceAsyncEventSource; so get the underlying CFMachPort and
        // invalidate it
        CFMachPortRef cfMachPort = NULL;
        mach_port_t portNum=(*tbContext->interface)->GetInterfaceAsyncPort(tbContext->interface);
        if (portNum)
            cfMachPort = CFMachPortCreateWithPort(NULL, portNum, NULL, NULL, NULL);
        if (NULL != cfMachPort)
        {
            CUPS_DEBUG("Invalidating cfMachPort %d.\n",portNum);
            CFMachPortInvalidate(cfMachPort);
            CFRelease(cfMachPort);
            cfMachPort=NULL;
        }

        // first invalidate the InterfaceAsyncEventSource
        // this step stops any further callbacks for this source
        // and removes the source from all runloops, in all modes
        if (CFRunLoopSourceIsValid(tbContext->interfaceAsyncSource))
        {
            CUPS_DEBUG("Invalidating interfaceAsyncSource.\n");
            CFRunLoopSourceInvalidate(tbContext->interfaceAsyncSource);
        }
        // now release it
        CFRelease(tbContext->interfaceAsyncSource);
        tbContext->interfaceAsyncSource=NULL;
    }
}
void examineDeviceForContext(TBUSBInterfaceContext * tbContext)
{
    if (tbContext->deviceIDString)
    {
        CFStringRef deviceID=CFStringCreateCopy(kCFAllocatorDefault, tbContext->deviceIDString);
        if (deviceID)
        {
            CFStringRef termString=CFSTR(";"), deviceMFG=NULL, cmdStr=NULL ;

            deviceMFG = TBCFStringCreateSubstringFromPrefixToTerminator(deviceID, CFSTR("MFG:"), termString);
            if (NULL == deviceMFG)
                deviceMFG = TBCFStringCreateSubstringFromPrefixToTerminator(deviceID, CFSTR("MANUFACTURER:"), termString);
            if (deviceMFG)
            {
                CFRange deviceMFGRange = CFRangeMake(0, CFStringGetLength(deviceMFG));
                // check for a known manufacturer
                if (CFStringFindWithOptions(deviceMFG, CFSTR("EPSON"), deviceMFGRange, kCFCompareCaseInsensitive, NULL))
                {
                    //we have an epson ...
                    tbContext->deviceProperties |= kEpsonPrinterDevice;
                    CUPS_DEBUG("detected an Epson printer and will attempt status reporting.\n");

                    // check for EPSON D4 (packet mode) attribute
                    cmdStr = TBCFStringCreateSubstringFromPrefixToTerminator(deviceID, CFSTR("CMD:"), termString);
                    if (NULL == cmdStr)
                        cmdStr = TBCFStringCreateSubstringFromPrefixToTerminator(deviceID, CFSTR("COMMAND:"), termString);
                    if (cmdStr)
                    {
                        if (CFStringFindWithOptions(cmdStr, CFSTR("d4"), CFRangeMake(0, CFStringGetLength(cmdStr)), kCFCompareCaseInsensitive, NULL))
                            tbContext->deviceProperties |= kEpsonPrinterUsesPacketMode;

                        CFRelease(cmdStr);
                    }
                }
                else if (CFStringFindWithOptions(deviceMFG, CFSTR("HP"), deviceMFGRange, kCFCompareCaseInsensitive, NULL) || CFStringFindWithOptions(deviceMFG, CFSTR("HEWLETT-PACKARD"), deviceMFGRange, kCFCompareCaseInsensitive, NULL))
                {
                    tbContext->deviceProperties |= kHPPrinterDevice;
                    CUPS_DEBUG("detected an HP printer and will attempt status reporting.\n");
                }

                CFRelease(deviceMFG);
            }
            CFRelease(deviceID);
        }
    }
}
void destroyContext(TBUSBInterfaceContext * tbContext)
{
    IOReturn ioResult;
    
    // we're done so clean things up
    DESTROY_CFTypeRef(tbContext->runLoopModes);
    // release the CFStringRefs
    DESTROY_CFTypeRef(tbContext->deviceURIString);
    DESTROY_CFTypeRef(tbContext->deviceIDString);
    
    // release the data array
    DESTROY_CFTypeRef(tbContext->dataArray);

    // remove all of the runloop sources
    removeRunLoopSourcesForContext(tbContext);


    // clean up any runloop observer
    if (NULL != tbContext->runLoopObserver)
    {
        CFRunLoopObserverInvalidate(tbContext->runLoopObserver);
        CFRelease(tbContext->runLoopObserver);
        tbContext->runLoopObserver=NULL;
    }

    // free any backchannel buffer
    // we malloc'd this buffer (if it exists)
    if (NULL != tbContext->backchannelBuffer)
    {
        free(tbContext->backchannelBuffer);
        tbContext->backchannelBuffer=NULL;
    }

    // close the interface interface
    if(NULL != tbContext->interface)
    {
        if(kUSBInterfaceIsOpen == tbContext->interfaceStatus)
        {
            CUPS_DEBUG("attempting to close USB interface %p\n", tbContext->interface);
            if(ioResult = (*tbContext->interface)->USBInterfaceClose(tbContext->interface))
            {
                CUPS_DEBUG("failed to close tbContext->interface: %s[%d].\n", strForIOReturn(ioResult), ioResult);
            }
            else
            {
                if (kIOReturnStillOpen == tbContext->writeStatus)
                {
                    tbContext->writeStatus = kIOReturnSuccess;
                }
                tbContext->interfaceStatus=kUSBInterfaceIsClosed;
                CUPS_DEBUG("successfully closed USB interface %p for device %.8x\n", tbContext->interface, tbContext->deviceObject);
            }
        }
        // release the interface
        if( (*tbContext->interface)->Release(tbContext->interface) )
        {
            CUPS_DEBUG("Unbalanced refcount for tbContext->interface.\n");
        }
        else
        {
            tbContext->interface=NULL;
        }
    }

    // release the device interface
    if (NULL != tbContext->device)
    {
        if( (*tbContext->device)->Release(tbContext->device) )
        {
            CUPS_DEBUG("Unbalanced refcount for tbContext->device.\n");
        }
        else
        {
            tbContext->device=NULL;
        }
    }
    if(tbContext->notifyPort)
    {
        IONotificationPortDestroy(tbContext->notifyPort);
        tbContext->notifyPort=NULL;
    }
    if(tbContext->objectIterator)
    {
        IOObjectRelease(tbContext->objectIterator);
        tbContext->objectIterator=0;
    }
    if(tbContext->deviceObject)
    {
        IOObjectRelease(tbContext->deviceObject);
        tbContext->deviceObject=0;
    }
}
IOReturn setWriteStream(const char * path, TBUSBInterfaceContext *tbContext)
{
    CFURLRef writeURL;
    IOReturn ioResult=kIOReturnError;

    // try to create a CFURL for the input file
    writeURL = CFURLCreateFromFileSystemRepresentation(NULL, (const UInt8 * )path, (CFIndex)strlen(path), false);
    // verify it
    if (NULL == writeURL)
    {
        CUPS_DEBUG("unable to create a CFURL for file \"%s\".\n",  path );
    }
    else
    {
        // try to create a CFWriteStream
        tbContext->writeStream = CFWriteStreamCreateWithFile (NULL, writeURL);
        
        //done with the URL
        DESTROY_CFTypeRef(writeURL);

        // check the writeStream
        if ( NULL == tbContext->writeStream)
        {
            CUPS_DEBUG("unable to create a writeStream from CFURL for file \"%s\".\n", path );
        }
        else
        {
            // Now we have a valid writeStream
            // set the writeStream client
            CFOptionFlags streamEvents;
            CFStreamClientContext clientContext;
            
            // init the clientContext
            clientContext.retain=NULL;
            clientContext.release=NULL;
            clientContext.copyDescription=NULL;
            clientContext.version=(CFIndex)0;
            clientContext.info=tbContext;
            
            // set the desired stream event flags
            streamEvents = kCFStreamEventOpenCompleted | kCFStreamEventCanAcceptBytes | kCFStreamEventErrorOccurred | kCFStreamEventEndEncountered ;

            if(CFWriteStreamSetClient(tbContext->writeStream,  streamEvents, writeStreamCallBack, &clientContext))
            {
                CUPS_DEBUG("set a writeStream client\n" );            
            }
            else
            {
                CUPS_DEBUG("unable to set a writeStream client\n" );
            }


            // add the writeStream to the runloop
            CFWriteStreamScheduleWithRunLoop(tbContext->writeStream, CFRunLoopGetCurrent(), kCFRunLoopCommonModes);
            // and open the readStream
            if (CFWriteStreamOpen(tbContext->writeStream))
            {
                CUPS_DEBUG("writeStream is opening for backchannel data\n" );
                ioResult=kIOReturnSuccess;
            }
            else
            {
                CUPS_DEBUG("failed to open a writeStream\n" );
                CFStreamError streamError = CFWriteStreamGetError(tbContext->writeStream);
                if(1 == streamError.domain)
                {
                    CUPS_DEBUG("unable to open file \"%s\" for writing; error %d \"%s\"\n",  path, (int)streamError.error,strForErrno((int)streamError.error));
                }
                else
                {
                    CUPS_DEBUG("unable to open file for writing \"%s\".; domain=%d; error=%d;\n",  path, (int)streamError.domain, (int)streamError.error);
                }
            }
        }
    }
    return ioResult;
}
void readFromReadStreamForContext(CFReadStreamRef readStream, TBUSBInterfaceContext  *tbContext)
{
    static unsigned         readCallCount=0;
    CFIndex                 byteCount;
    UInt8 *                 buffer;
    const UInt8 *           bytes;
    CFDataRef               byteData=NULL;
    CFStreamStatus          streamStatus;    

//    CUPS_DEBUG("control entering readFromReadStreamForContext \n");
                
    byteCount=tbContext->readStreamReadSize;
    streamStatus=CFReadStreamGetStatus(readStream);
    CUPS_DEBUG2("getting readstreamstatus = %s\n",strForCFStreamStatus( streamStatus));
    if (CFReadStreamHasBytesAvailable(readStream) && kIOReturnSuccess == tbContext->readStatus)
    {
        // set status to locked 
        tbContext->readStatus=kIOReturnLockedRead;
        
        readCallCount +=1;
        // try to get a byte buffer
        if (bytes = CFReadStreamGetBuffer(readStream, byteCount, &byteCount))
        {
            CUPS_DEBUG2("CFReadStreamGetBuffer returned %d bytes\n",(int)byteCount);
            byteData = CFDataCreate(NULL, bytes, byteCount);
        }
        // if we get here there was a problem getting the data with CFReadStreamGetBuffer()
        // If status is ok then malloc a buffer and try to read the data with CFReadStreamRead()
        else if ((streamStatus=CFReadStreamGetStatus(readStream)) == kCFStreamStatusOpen || kCFStreamStatusOpening == streamStatus)
        {
            CUPS_DEBUG2("CFReadStreamGetBuffer returned NULL ... trying CFReadStreamRead()\n");
            byteCount=tbContext->readStreamReadSize;
            if (buffer=malloc(byteCount))
            {
                byteCount=CFReadStreamRead(readStream, buffer, byteCount );
                // use CFDataCreateWithBytesNoCopy and pass kCFAllocatorMalloc as deallocator
                if (0 < byteCount)
                {
                    CUPS_DEBUG2("CFReadStreamRead returned %d bytes\n",(int)byteCount);
                    byteData = CFDataCreateWithBytesNoCopy(NULL, buffer, byteCount, kCFAllocatorMalloc);
                    if (NULL == byteData)
                    {
                        // could not create a data object so free the buffer
                        free(buffer);
                        tbContext->readStatus=kIOReturnNoMemory;
                    }
                }
                else
                {
                    // we've exhausted the readStream
                    tbContext->readStatus=kIOReturnNotFound;
                    CUPS_DEBUG2("readStream recieved EOF.\n");
                    CUPS_DEBUG("reading complete; total read count: %d for %d bytes.\n",--readCallCount, (int)tbContext->readByteCount);
					
                    // stop the runloop for the special case of zero bytes read
                    if (1 > tbContext->readByteCount)
                        stopRunLoopForContext(tbContext);
                }
            }
        }
        
        // if we have a data object then add it to the data array
        if(byteData)
        {
            if (byteCount=CFDataGetLength(byteData))
            {
                tbContext->readByteCount += byteCount;
                CFArrayAppendValue(tbContext->dataArray, byteData);
            }
            CFRelease(byteData);
            byteData=NULL;
            tbContext->readStatus=kIOReturnSuccess;
            CUPS_DEBUG2("read transaction #%d; status=%s; bytes=%ld;%s;\n", readCallCount , strForCFStreamStatus(streamStatus), byteCount,(NULL==bytes) ? "m":"b");    

            // check if this is the first pending write in the queue    
            if (1 == CFArrayGetCount(tbContext->dataArray))
            {
                // if this is the very first write then try to send a printer command
                if (0 == tbContext->completedCount)
                {
                    // open the interface if necessary
                    if(kUSBInterfaceIsClosed == tbContext->interfaceStatus && openUSBInterfaceForContext(tbContext))
                    {
                        CUPS_STATE_SET("offline-error");
                        stopRunLoopForContext(tbContext);
                    }
                    
                    if(kGetPrinterDeviceStatus & tbContext->deviceProperties )
                    {

                        // check device properties and try to parse return data
                        // probably we should OR the deviceProperties with a mask (of at least 256 bits)
                        // and switch on the result ... for now we do this
                        if ( kEpsonPrinterDevice == tbContext->deviceProperties )
                        {
                            epsonPrinterStartReportingForContext(tbContext);
                        }
                        else if ( kHPPrinterDevice == tbContext->deviceProperties )
                        {
                            hpPrinterStartReportingForContext(tbContext);
                        }
                        else if ( kBackChannelDevice & tbContext->deviceProperties )
                        {
                            CUPS_DEBUG("starting the backchannel read mechanism;\n");
                            // start the backchannel read mechanism
                            setDeviceStatusTimerForContext(tbContext);
                        }
                    }

                }
                // when the count equals one there are no pending write transactions
                // (we just added the only one that's there) so we need to begin a write
                writeAsyncToUSBInterfaceForContext(tbContext);
            }
        }
        else if (kIOReturnNotFound != tbContext->readStatus)
        {
            // if we get here then we had total failure to read data
            tbContext->readStatus=kIOReturnNoMemory;
        }
    }
    else if (false == CFReadStreamHasBytesAvailable(readStream))
    {
        CUPS_DEBUG("readStream has no bytes available to read.\n");
    }
    else
    {
        // read status error upon entry
        CUPS_DEBUG("read from readStream failed; %s.\n", strForIOReturn(tbContext->readStatus));
    }
//    CUPS_DEBUG("control exiting readFromReadStreamForContext \n");
}
void readAsyncFromUSBInterfaceForContext(TBUSBInterfaceContext * tbContext)
{
    UInt32          noDataTimeout=0;//90000;
    UInt32          completionTimeout=0;//90000;
    IOReturn        ioResult;
    unsigned        bufferSize = tbContext->backchannelBufferSize;
    
    // check for a valid bulkIN
    if (0 == tbContext->bulkIN)
    {
        CUPS_DEBUG("cancelling backchannel reads. No available bulkIN pipe.\n");
        tbContext->deviceProperties ^= (kBackChannelDevice | kBackChannelSignalRead);
        return;
    }
    
    // check for a valid buffer for the backchannel read data
    if (NULL == tbContext->backchannelBuffer && 0 < bufferSize)
    {
        // try to malloc a buffer
        tbContext->backchannelBuffer = malloc(bufferSize);
    }

    if (NULL == tbContext->backchannelBuffer)
    {
        CUPS_DEBUG("failed try to allocate a %d-byte buffer for backchannel reads./n", bufferSize);
    }
    else
    {
        CUPS_DEBUG("attempting to read data from printer backchannel.\n");

        // start the async read            
        ioResult=(*tbContext->interface)->ReadPipeAsyncTO(tbContext->interface, tbContext->bulkIN, tbContext->backchannelBuffer, bufferSize, noDataTimeout, completionTimeout, IOAsyncReadPipeCallback1, tbContext);
        
        // unless the call failed set the USBReadStatus to kIOReturnTimeout
        // if the monitoring timer fires before the read callback then this flag
        // indicates that the timer should continue to wait before initiating another
        // async read
        // we're using a timer to limit the frequency of status reads...
        if (kIOReturnSuccess == ioResult)
        {
            tbContext->USBReadStatus=kIOReturnTimeout;
        }
        else
        {
            tbContext->USBReadStatus=ioResult;
            CUPS_DEBUG("failed to read printer backchannel [%s].\n",strForIOReturn(ioResult));
        }
    }
}
void writeAsyncToUSBInterfaceForContext(TBUSBInterfaceContext * tbContext)
{
    // we cannot use writes with completion timeouts if we want to recover from a timeout condition.
    // We *do* want to recover from such a condition because the situation may arise from
    // time to time in the normal course of use. For example, the printer may run out of paper during
    // the middle of a job. Because the backend has no knowledge of job pagination, but merely
    // transfers data from the filter to the printer, there is no way for the backend to know that a
    // paper empty condition has occured, except by waiting for the printer to signal the event.
    // However, most printers do not test for a paper out condition until a job is in progess,
    // by which time the backend has, by necessity, already sent a portion of the page data.
    // Although a portion of the data transmitted before the timeout will find its way into the printer's memory buffer, the callback from WritePipeAsyncTO() will not reflect this. Instead it will report that no data was sent, making it impossible to continue sending only the remaining bytes once the error condition is resolved because the precise number of `unsent' bytes is unknown. Therefore, we need to not use the `completion TimeOut' function of the call. Instead, we need to start a CFRunLoopTimer everytime we start a write and check for completion when the timer fires. When a write completes successfully before the timer firedate, we need to update the firedate.

    CFDataRef       byteData=NULL;
    UInt32          noDataTimeout=0;//90000;
    UInt32          completionTimeout=0;//90000;
    //UInt8           portStatus;
    //IOReturn        ioPrinter;
    IOReturn        ioResult = tbContext->writeStatus;
    CFIndex         dataCount = CFArrayGetCount(tbContext->dataArray);

    // check the printer port status condition
    // it always should be safe to check the port status here,
    // even for the non-compliant HP models
    // as the buffer should always be empty before we write to it
    
// on second thought, just because the previous write returned does not mean that the buffer is empty
// some HP owners have still reported weird problems so let's just let the status timer handle the 
// port status checks
//    
//    ioPrinter = usbPrinterGetPortStatus(tbContext->interface, &portStatus);
//    switch (ioPrinter)
//    {
//    case kIOReturnSuccess :
//        break;
//    case kIOReturnNoMedia :
//        CUPS_ERROR("The printer is out of paper!\n");
//        break;
//    case kIOReturnOffline :
//        CUPS_ERROR("The printer is offline. Check the buttons.\n");
//        break;
//    default:
//        // here is one place to check for model-specific error codes (such as out-of-ink) ...
//        CUPS_ERROR("The printer is reporting an error!\n");
//        break;
//    }
    
    // verify both the write status condition, and pending data to write
    //if (kIOReturnSuccess == ioResult && 0 < CFArrayGetCount(tbContext->dataArray))
    if ( 0 < dataCount)
    {
        // try to compact multiple pending writes
        compactDataArrayFromIndexForContext(0, MAX_CHUNK_SIZE, tbContext);

        const UInt8 * bptr = NULL;
        if ((byteData = CFArrayGetValueAtIndex(tbContext->dataArray, 0)) && (0 < CFDataGetLength(byteData)))
        {
            bptr = CFDataGetBytePtr(byteData);
            // write it out to the device async
            ioResult=(*tbContext->interface)->WritePipeAsyncTO(tbContext->interface, tbContext->bulkOUT, (void *)bptr, CFDataGetLength(byteData), noDataTimeout, completionTimeout, IOAsyncWritePipeCallback2, tbContext);
            if(4 == CFDataGetLength(byteData))
            {
                CUPS_DEBUG("wrote 4 bytes of data 0X%x%x%x%x\n",bptr[0],bptr[1],bptr[2],bptr[3]);
            }
        }
        else
        {
            // attempted to write a 0 byte buffer
            CUPS_DEBUG("Attempted to write a zero-length buffer. Aborting.\n");
            tbContext->writeStatus=kIOReturnNotFound;
        }
        
    }
    else
    {
        // attempted to write with zero data objects
        CUPS_DEBUG("Attempted to write with zero data objects. Aborting.\n");
        tbContext->writeStatus=kIOReturnNotFound;
    }

    // check the return for immediate failure
    if (kIOReturnSuccess == ioResult)
    {
        // start a CFRunLoop timer to check for completion
        setWriteCompletionTimerForContext(tbContext);
    }
    else
    {
        tbContext->writeStatus=ioResult;
        // the async write call immediately returned an error so we need to give up
        CUPS_ERROR("Printing failed with error \"%s\".\n", strForIOReturn(ioResult));
        // stop the runloop 
        
        //stopRunLoopForContext(tbContext);
    }
}
void compactDataArrayFromIndexForContext(CFIndex start, CFIndex maxSize, TBUSBInterfaceContext * tbContext)
{
    // try to concatenate multiple data objects
    CFDataRef           byteData;
    CFMutableDataRef    bigData;
    CFIndex             dataLength, combinedLenth, i=start;
    CFIndex             dataCount = CFArrayGetCount(tbContext->dataArray);

    if (i + 1 < dataCount)
    {
        
        // begin with index i
        byteData = CFArrayGetValueAtIndex(tbContext->dataArray, i);
        if (NULL != byteData && maxSize > (combinedLenth = CFDataGetLength(byteData)))
        {
            bigData = CFDataCreateMutableCopy(NULL, 0, byteData);
            if (NULL != bigData)
            {
//                for (i++; i < dataCount && NULL != (byteData = CFArrayGetValueAtIndex(tbContext->dataArray,i)) ; i++)
                while (++i < dataCount && NULL != (byteData = CFArrayGetValueAtIndex(tbContext->dataArray,i)))
                {
                    dataLength = CFDataGetLength(byteData);
                    if (maxSize < (combinedLenth += dataLength))
                    {
                        combinedLenth -= dataLength;
                        break;
                    }
                    else
                    {
                        CFDataAppendBytes(bigData, CFDataGetBytePtr(byteData), dataLength);
                    }
                }
                // check the exit condition
                if (i > start + 1)
                {
                    // make an immutable copy
                    byteData = CFDataCreateCopy(NULL, bigData);
                    if (NULL != byteData && CFDataGetLength(byteData) == combinedLenth)
                    {
                        // add it to the 1 spot
                        CFArrayInsertValueAtIndex(tbContext->dataArray, start, byteData);
                        CFRelease(byteData);
                        byteData = NULL;
                        
                        CFRange replaceRange={start + 1, i - start};
                        CFArrayReplaceValues(tbContext->dataArray, replaceRange, NULL, 0);
                        // remove object at start + 1 spot (i - start) times
                        
                        CUPS_DEBUG2("Compacted %ld data objects for %ld bytes.\n", (i-start), combinedLenth);
                    }
                }
                
                CFRelease(bigData);
                bigData = NULL;
            }
        }
    }
}
void epsonPrinterStartReportingForContext(TBUSBInterfaceContext * tbContext)
{
    IOReturn    ioResult;
    UInt8       cmdBuf[128];
    unsigned    byteCount=sizeof(cmdBuf);
    int         commandCount, cmds[4];
    
    //set the number of commands
    commandCount=2;
    // set the commands
    cmds[0]=kEpsonPrinterCommandSetStatus; // This command does not appear to work as expected on the Epson C84
    cmds[1]=kEpsonPrinterCommandGetInkQ;
    //cmds[1]=kEpsonPrinterCommandNozzleCheck;
    // get the assembled commands
    epsonPrinterGetRemoteCommand(cmdBuf, &byteCount, cmds, (sizeof(cmds) < commandCount ? sizeof(cmds) : commandCount), (tbContext->deviceProperties & kEpsonPrinterUsesPacketMode));

    if (0 < byteCount)
    {
        ioResult=(*tbContext->interface)->WritePipeTO(tbContext->interface, tbContext->bulkOUT, cmdBuf, byteCount, 100, 1000);
    
    if (kIOReturnSuccess == ioResult)
        tbContext->USBReadStatus=kIOReturnSuccess;
    }

    // start the backchannel read mechanism
    setDeviceStatusTimerForContext(tbContext);
}
void hpPrinterStartReportingForContext(TBUSBInterfaceContext * tbContext)
{
    //IOReturn    ioResult;
	
	// HP printers report status (such as ink levels) via the device ID.
	// we need to set up a timer that periodically calls a function to get the device ID
	// and parse it for status data
    
    //if (kIOReturnSuccess == tbContext->USBReadStatus)

    // start the backchannel read mechanism
    setDeviceStatusTimerForContext(tbContext);
}
void getDeviceIDForContext(TBUSBInterfaceContext * tbContext)
{
    IOUSBDevRequestTO           request;             // struct for timeout control request
    unsigned			resultLength;		// calculated return length
    IOReturn			kr;
    
    // get the device ID...
    
    // zero the length in case of failure
    tbContext->deviceIDLength = 0;

    // first check if we have a valid buffer
    if (NULL == tbContext->deviceIDBuffer)
    {
        // allocate an unpadded buffer
        if (tbContext->deviceIDBufferSize % kMallocQuantumSize)
            tbContext->deviceIDBufferSize = kMallocQuantumSize * (1 + (tbContext->deviceIDBufferSize / kMallocQuantumSize));
                
        tbContext->deviceIDBuffer = malloc(tbContext->deviceIDBufferSize);
        if (NULL == tbContext->deviceIDBuffer)
        {
            CUPS_DEBUG("Failed to malloc a deviceID buffer of size %ul.\n", tbContext->deviceIDBufferSize);
            return;
        }
    }
	
    // populate a device request structure
    // GET_DEVICE_ID    bRequest = 0
    //                  wValue field is used to specify a zero-based configuration index.
    //request.bmRequestType =100100001B=161
    request.bmRequestType = 161;//USBmakebmRequestType(kUSBIn, kUSBClass, kUSBInterface);
    // defined in this file 
    request.bRequest = kUSBPrintClassGetDeviceID;
    // the USB Device Class Definition for Printing Devices 1.1 states that
    // for the GET_DEVICE_ID class-specific device request "the wValue field
    // is used to specify a zero-based configuration index."
    // Of course, the bConfigurationValue of zero indicates that the device
    // is not configured, thus all valid configuration values must be >= 1.
    // Apparently, printing device manufacturers have interpreted the qualifier
    // "zero-based" to mean that you should take the index of valid configuration
    // values, which starts at 1, (0 being the default "unconfigured" state) and
    // subtract 1 to make it "zero-based". Very odd indeed.
    request.wValue = tbContext->configurationIndex - 1;
    // The high-byte of wIndex is used to specify the zero-based interface index.
    // The low-byte of wIndex is used to specify the zero-based alternate setting.
    request.wIndex = (tbContext->interfaceNumber << 8) | tbContext->interfaceAlternate;
    request.wLength = tbContext->deviceIDBufferSize;
    request.pData = tbContext->deviceIDBuffer;
    request.completionTimeout = 100;
    request.noDataTimeout = 100;

    // send the request, verify the return, and verify the buffer size
    kr = (*tbContext->interface)->ControlRequestTO(tbContext->interface, (UInt8)0, &request );
    if ( kr != kIOReturnSuccess )
    {
        CUPS_DEBUG("* failed GetDeviceID request with error: %s [%.8x].\n", strForIOReturn(kr), kr);
        return;
    }
    else if (2 > request.wLenDone)
    {
        CUPS_DEBUG("* failed GetDeviceID; ControlRequestTO returned with wLenDone=%ld (expected at least 2).\n", request.wLenDone);
        return;
    }
	
    // return verified. Now check for adequate buffer size
    resultLength = (tbContext->deviceIDBuffer[0] << 8) | ( tbContext->deviceIDBuffer[1]);
    if (resultLength > tbContext->deviceIDBufferSize)
    {
        // if the size is inadequate then try to realloc the buffer ...
        unsigned newBufferSize = resultLength + (kMallocQuantumSize - resultLength % kMallocQuantumSize);
        UInt8 * newBuffer=realloc(tbContext->deviceIDBuffer,newBufferSize);
        if (NULL != newBuffer)
        {
            tbContext->deviceIDBufferSize = newBufferSize;
            tbContext->deviceIDBuffer=newBuffer;
        }
        else
        {
            CUPS_DEBUG("* realloc failed for deviceID buffer from old size (%ul) to requested size (%ul)\n", tbContext->deviceIDBufferSize, newBufferSize);
        }
        // ... and send the request again
        request.wLength = tbContext->deviceIDBufferSize;
        request.pData = tbContext->deviceIDBuffer;
        kr = (*tbContext->interface)->ControlRequestTO(tbContext->interface, (UInt8)0, &request );

        if (kIOReturnSuccess !=  kr)
        {
            CUPS_DEBUG("* failed followup GetDeviceID request with error: %s [%d].\n", strForIOReturn(kr), kr);
            return;
        }
        else if (1 < request.wLenDone)
        {
            resultLength = (tbContext->deviceIDBuffer[0] << 8) | ( tbContext->deviceIDBuffer[1]);
            if (resultLength > tbContext->deviceIDBufferSize)
            {
                CUPS_DEBUG("* rapidly changing deviceID; changed from size (%ul) to size (%ul) within one function call.\n", tbContext->deviceIDBufferSize, resultLength);

                // bail out until the next cycle
                return;
            }
        }
    }
    // set the length
    tbContext->deviceIDLength = resultLength;
    // shift all the buffer bytes two bytes over to account for the length bytes
//	for (i=0;i< resultLength -2;i++)
//		tbContext->deviceIDBuffer[i]=tbContext->deviceIDBuffer[i+2];
    // null-terminate the string for good measure
//	tbContext->deviceIDBuffer[i]=NULL;
	
}
//void parseHPDeviceIDForStatusInfoForContext(TBUSBInterfaceContext * tbContext)
void parseHPDeviceIDForStatus(const char * deviceID, UInt16 deviceIDLength)
{
    //note from http://www.hpdevelopersolutions.com/FAQpage.cfm?FAQID=222&CATEGORYID=84
    //Some early HP printers tended to exhibit issues with deviceID/status byte requests when the printer's buffer was full. A full buffer is a common occurrence during the course of a print-job and can be forced with an out-of-paper condition or by opening the top cover. The APSDK printer driver specifically handles these printers (640/810/830/880/895) internally by 'turning off' it's status checking after discovering one of these printers. However, it has been discovered that some implementers of the USB Printer Class Driver (the interface by which the APSDK or any other printer driver communicate over USB to the printer) incorporate their own deviceID or status byte checks during the course of a print job. Namely, Linux kernels previous to 2.4.0 performed this action and consequently exposed the issue. It is our recommendation that the USB Printer Class Driver not perform these device ID or status byte checks until the printer driver makes the request.
    // usage:
    //parseHPDeviceIDForStatus(tbContext->deviceIDBuffer, tbContext->deviceIDBufferSize);
    // now we should have a valid return within an adequately sized buffer.
    
    CUPS_DEBUG("attempting to parse an HP device ID ...\n");
    // check for a valid device ID buffer ...
    if (NULL == deviceID || 0 == deviceIDLength)
    {
        CUPS_DEBUG("* attempt to parse an invalid device ID");
        return;
    }
    char * status, *field, *statusEnd;
    char * hpColors[]={"Black","Color","Photo",0};
    int i, statusLength=0, cartridgeCount=0, val, level[kMaxInkColors];
    // parse it ...
    
    // here I changed the code to use multiple calls to strstr() instead of strcasestr()
    // because jaguar apparently has that particular function in a different shared
    // library than the one it resides in on Panther, so there are errors running on jaguar
    // and I have not cross-compiled for jaguar...
    if ((status = strstr(deviceID, "VSTATUS:")) != NULL||(status = strstr(deviceID, "vstatus:")) != NULL)
    {
        status += 8;
        // look for the ending `;'
        if ((statusEnd = strstr(status, ";")) != NULL)
            statusLength = statusEnd - status;
        // check for ink info by string length
        if (40 < statusLength)
        {
            cartridgeCount = '2' - 48;
            // look for K#,C# and KP###,CP### where # is a decimal digit
            level[0] = -2;  // set the default error condition
            if (0 == strncasecmp(status+23, ",K", 2))
            {
                if (0 == strncasecmp(status+25, "0", 1))
                {   // 0 signals an installed cartridge
                    // get the percent remaining
                    if (0 == strncasecmp(status+35, ",KP", 3))
                        level[0]= (status[38] - 48)*100 + (status[39] - 48)*10 + (status[40] - 48);
                }
                else if (0 == strncasecmp(status+25, "1", 1))
                    level[0] = -1;  // cartridge not installed
            }
            level[1] = -2;  // set the default error condition
            if (0 == strncasecmp(status+26, ",C", 2))
            {
                if (0 == strncasecmp(status+28, "0", 1))
                {   // 0 signals an installed cartridge
                    // get the percent remaining
                    if (0 == strncasecmp(status+41, ",CP", 3))
                        level[1]= (status[44] - 48)*100 + (status[45] - 48)*10 + (status[46] - 48);
                }
                else if (0 == strncasecmp(status+28, "1", 1))
                    level[1] = -1;  // cartridge not installed
            }
        }
    }
    else if ((status = strstr(deviceID, ";S:")) != NULL || (status = strstr(deviceID, ";s:")) != NULL)
    {
        status += 3;
        // check the version to determine status string length
        // the version is hex-encoded in the first two bytes
        // int version = (status[0] - 48)* 16 + status[1] - 48;
        // look for #c1......c2 where # is a decimal digit indicating the number of cartridges
        if (((field = strstr(status, "c1")) != NULL|| (field = strstr(status, "C1")) != NULL) && (strncasecmp(field+8, "c2",2) == 0))
        {
            cartridgeCount = *(field -1) - 48;
                
            for (i=0;i < cartridgeCount && i < kMaxInkColors ;i++)
            {
                // the following line deserves some explanation (primarily so that I can
                // have a chance to figure out what in the world I was thinking when I wrote it!)
                // we get the device ID from the printer as a raw string without modification.
                // HP printer's (this is an assumption) always use UTF8 encoding for the
                // hexidecimal ink-level percentage, thus we can decode the raw values even if
                // the host's native character encoding were to change. The first part takes
                // care of the high byte (it's big-endian) and we don't have to worry about any
                // hex values > 6 because if the percentage is ever over 100 then we have an error.
                // the second part (Starting with (val=...) decodes the low byte, and here we need
                // to be prepared to handle hexidecimal values so we subtract 48 if it's a decimal
                // digit, or we subtract 55 if it's an upper-case A-F (leaving 10 for `A' ...), or 
                // we subtract 87 if it's a-f (leaving 10 for `a' ...), else we add 1000 in error.
                // We check for values > 100 later and report an error if true.
                // the raw string looks like this:  3c148005fc2500061c3580061
                // so here cartridge 1 has a hex value of 5f = 95%, cartridge 2 has a hex value
                // of 61 = 97%, and cartridge 3 has the same value as cartridge 2.
                val = field[8*i + 7];
                level[i] = (field[8*i + 6] - 48)*16 + val - ((47 < val && 58 > val) ? 48 : ((64 < val && 71 > val) ? 55 : ((96 < val && 103 > val) ? 87 : -1000)));
            }
        }
    }
	
    // print the results on stderr INFO
    if (0 < cartridgeCount)
    {
        fprintf(stderr,"INFO: Ink levels:");
        for (i=0;i < cartridgeCount;i++)
        {
            if (-1 < level[i] && 101 > level[i])
                fprintf(stderr," %s=%d%%",hpColors[i],level[i]);
            else if ( -1 == level[i] )
                fprintf(stderr," %s=%s",hpColors[i],"missing");
            else
                fprintf(stderr," %s=%s",hpColors[i],"error");
        }
        fprintf(stderr,"\n");
    }
    else
        fprintf(stderr,"DEBUG: Could not read ink levels\n");
}
Boolean setReadStreamClientForContext(TBUSBInterfaceContext  *tbContext)
{
    CFOptionFlags streamEvents;
    CFStreamClientContext clientContext;
    
    // init the clientContext
    clientContext.retain=NULL;
    clientContext.release=NULL;
    clientContext.copyDescription=NULL;
    clientContext.version=(CFIndex)0;
    clientContext.info=tbContext;
    
    // set the desired stream event flags
    streamEvents = kCFStreamEventHasBytesAvailable | kCFStreamEventErrorOccurred | kCFStreamEventEndEncountered ;

    return CFReadStreamSetClient(tbContext->readStream,  streamEvents, readStreamCallBack, &clientContext);
}
void handleSignalForContext(TBUSBInterfaceContext  *tbContext)
{
    fprintf (stderr,"\n%s received signal %d:%s\n", APP_NAME_STRING, gSignal,strForSignal(gSignal));

    switch(gSignal)
    {
    case SIGTERM :
        // the standard behavior of a CUPS backend is to ignore a signal to
        // terminate while the device is open and printing from stdin so as
        // to "finish out any page data the driver sends"
        if (6 == gargc && kUSBInterfaceIsOpen == tbContext->interfaceStatus)
            break;

    case SIGHUP  :
    case SIGINT  :
    case SIGQUIT :
    case SIGABRT :
    case SIGTSTP :
        // for these signals in all other situations go ahead and
        // safely stop the printing process
        fprintf (stderr," -- aborting job.\n");
        // clear any status that might stop termination
        if (kBackChannelDevice & tbContext->deviceProperties && kIOReturnTimeout==tbContext->USBReadStatus)
            tbContext->USBReadStatus=kIOReturnAborted;
        stopRunLoopForContext(tbContext);
        return;

    case SIGUSR1:
        //this signal indicates that we should read the backchannel once and write back any data
        if(kBackChannelSignalRead & tbContext->deviceProperties)
        {
            CUPS_DEBUG("recieved request to read backchannel data ... will commence after write completion\n");
            return;
        }
        else
        {
            CUPS_DEBUG("recieved signal to read backchannel data ... but backchannel reading on signal was not requested\n");
        }
        break;
    case SIGUSR2:
            CUPS_DEBUG("recieved signal to read backchannel at next possible opportunity ... which is now\n");
            readAsyncFromUSBInterfaceForContext(tbContext);
        break;
    default:
        // ignore all other caught signals (such as SIGPIPE)
        break;
    }
    CUPS_DEBUG(" -- ignoring signal %s.\n",strForSignal(gSignal));
    // reset the global
    gSignal=0;
}
void stopRunLoopForContext(TBUSBInterfaceContext  *tbContext)
{
//    CUPS_DEBUG("control entering stopRunLoopForContext \n");

    // when it's time to stop the runloop, we need to ensure that
    // none of the callbacks are in process.  If the runloop stops
    // when certain functions are being called (such as fprintf())
    // there may be problems.
    
    // bail out if we are waiting for feedback
    if ((kBackChannelDevice & tbContext->deviceProperties) && kIOReturnTimeout==tbContext->USBReadStatus)
    {
        CUPS_DEBUG("bailing out of stopRunLoopForContext() to wait for backchannel data\n");
        return;
    }

    // add a CFRunLoopObserver to the end of the runloop
    // when all currently processing functions exit then
    // the run loop observer will be called before the runloop sleeps.
    tbContext->runLoopObserver = CFRunLoopObserverCreate(NULL, kCFRunLoopAllActivities, false, 0, observerCallback, NULL);
    if (NULL != tbContext->runLoopObserver)
        CFRunLoopAddObserver(CFRunLoopGetCurrent(), tbContext->runLoopObserver,  kCFRunLoopCommonModes);

    // invalidate any other runloop sources
    removeRunLoopSourcesForContext(tbContext);
	
        
    // wait for any currently processing callbacks to finish
    if (tbContext->callbackInProgress)
        CUPS_DEBUG("stopping runloop with callbacks in progress: %d\n", (int)tbContext->callbackInProgress);
    //while (tbContext->callbackInProgress);
    
    // and finally stop the runloop
    //CFRunLoopStop(CFRunLoopGetCurrent());
    // with all of the sources and timers removed, the run loop should stop when any
    // currently proceeding callbacks finish
//        CUPS_DEBUG("control exiting stopRunLoopForContext \n");
}
void setDeviceStatusTimerForContext(TBUSBInterfaceContext  *tbContext)
{
    CFAbsoluteTime          fireDate;
    CFTimeInterval          interval;
    CFRunLoopTimerContext   timerContext;

    // set the timer repeat interval
    interval = tbContext->deviceStatusReadInterval;

    // validate the repeat interval
    if (0.3 > interval)
        interval = 0.3;
	
    // set the value for the next firedate
    fireDate = CFAbsoluteTimeGetCurrent() + interval;

    // check for an existing valid timer
    if(NULL != tbContext->deviceStatusTimer && CFRunLoopTimerIsValid(tbContext->deviceStatusTimer))
    {
        // if the existing timer is still valid then just reset the next firedate
        CFRunLoopTimerSetNextFireDate(tbContext->deviceStatusTimer, fireDate);
    }
    else
    {
        // we need to create a new timer ...
        
        // first check if we need to release an invalidated timer
        if(NULL != tbContext->deviceStatusTimer)
        {
            // release any previous deviceStatusTimer 
            CFRelease(tbContext->deviceStatusTimer);
            tbContext->deviceStatusTimer=NULL;
        }
        // init the CFRunLoopTimerContext for this timer
        timerContext.info = tbContext;
        timerContext.version = 0;
        timerContext.retain = NULL;
        timerContext.release = NULL;
        timerContext.copyDescription = NULL;

        tbContext->deviceStatusTimer = CFRunLoopTimerCreate(NULL, fireDate, interval, 0, 0, deviceStatusTimerCallback, &timerContext );
        
        // validate the new timer
        if (NULL != tbContext->deviceStatusTimer)
        {
            if (CFRunLoopTimerIsValid(tbContext->deviceStatusTimer))
            {
                // add it to the runloop and ...
                CFRunLoopAddTimer (CFRunLoopGetCurrent(), tbContext->deviceStatusTimer, kCFRunLoopCommonModes);
                // ... set the readStatus so that we can check for this condition later
                tbContext->USBReadStatus=kIOReturnSuccess;
                CUPS_DEBUG("Added a deviceStatusTimer with interval %f secs.\n",interval);
            }
            else
            {
                // somehow we created an invalid timer; release it
                CFRelease(tbContext->deviceStatusTimer);
                tbContext->deviceStatusTimer = NULL;
            }
        }
    }
	
    CUPS_DEBUG("found device with properties %.8x in %s\n",(unsigned)tbContext->deviceProperties,__func__);
    // start to read any status data
    if(kBackChannelSignalRead & tbContext->deviceProperties)
    {
     // do nothing ... wait for a signal
        CUPS_DEBUG("waiting for signal to read backchannel data in %s\n",__func__);
    }
    else if (kBackChannelDevice & tbContext->deviceProperties)
    {
        CUPS_DEBUG("Reading device for backchannel data in %s\n",__func__);
        readAsyncFromUSBInterfaceForContext(tbContext);
    }
    else if(kPrinterDeviceStatusInDeviceID & tbContext->deviceProperties)
    {
        // get the deviceID for printers that report status via the deviceID
        if (NULL == tbContext->deviceIDBuffer)
        {
            getDeviceIDForContext(tbContext);
            CUPS_DEBUG("Got a device ID of length %d.\n",tbContext->deviceIDLength);
        }
        // check for length > 0 then parse according to model
        if (0 < tbContext->deviceIDLength)
        {
            if (kHPPrinterDevice & tbContext->deviceProperties)
                parseHPDeviceIDForStatus((char *)tbContext->deviceIDBuffer +2, tbContext->deviceIDLength);
                    //parseHPDeviceIDForStatusInfoForContext(tbContext);
        }
    }
}
void killWriteCompletionTimer(TBUSBInterfaceContext  *tbContext)
{
    // invalidate any writeCompletionTimer
    if(tbContext && NULL != tbContext->writeCompletionTimer)
    {
        // invalidate and release
        CFRunLoopTimerInvalidate(tbContext->writeCompletionTimer);
        CFRelease(tbContext->writeCompletionTimer);
        tbContext->writeCompletionTimer=NULL;
    }
}
void setWriteCompletionTimerForContext(TBUSBInterfaceContext  *tbContext)
{
    CFAbsoluteTime          fireDate;
    CFTimeInterval          interval;
    CFRunLoopTimerContext   timerContext;
    
    fireDate = CFAbsoluteTimeGetCurrent() + tbContext->writeCompletionTimeOut;

    // check for an existing writeCompletionTimer
    if(NULL != tbContext->writeCompletionTimer)
    {
        // if the existing timer is still valid then just reset the next firedate
        // invalidate any existing valid writeCompletionTimer 
        if (CFRunLoopTimerIsValid(tbContext->writeCompletionTimer))
        {
            CFRunLoopTimerSetNextFireDate(tbContext->writeCompletionTimer, fireDate);
        }
        else
        {
            // release any previous writeCompletionTimer 
            CFRelease(tbContext->writeCompletionTimer);
            tbContext->writeCompletionTimer=NULL;
        }
    }
	
    // create a new timer if need be (we may have just released an invalid timer...)
    if(NULL == tbContext->writeCompletionTimer)
    {
    
        // init the CFRunLoopTimerContext for this timer
        timerContext.info = tbContext;
        timerContext.version = 0;
        timerContext.retain = NULL;
        timerContext.release = NULL;
        timerContext.copyDescription = NULL;

        interval = tbContext->writeCompletionTimeOut;

        // validate the writeCompletionTimeOut
        if (0.1 > interval)
                interval = 5.0;
                
        tbContext->writeCompletionTimer = CFRunLoopTimerCreate(NULL, fireDate, interval, 0, 0, writeCompletionTimerCallback, &timerContext );
        
        // validate the new timer
        if (NULL != tbContext->writeCompletionTimer)
        {
            if (CFRunLoopTimerIsValid(tbContext->writeCompletionTimer))
            {
                // add it to the runloop
                CFRunLoopAddTimer (CFRunLoopGetCurrent(), tbContext->writeCompletionTimer, kCFRunLoopCommonModes);
            }
            else
            {
                // somehow we created an invalid timer; release it
                CFRelease(tbContext->writeCompletionTimer);
                tbContext->writeCompletionTimer = NULL;
            }
        }
    }
}
Boolean setReadStreamTimerForContext(TBUSBInterfaceContext  *tbContext)
{
    CFAbsoluteTime          haltTime;
    CFRunLoopTimerContext   timerContext;
    
    // check for an existing readStreamTimer
    if(NULL != tbContext->readStreamTimer)
    {
        // invalidate any existing valid readStreamTimer 
        if (CFRunLoopTimerIsValid(tbContext->readStreamTimer))
            CFRunLoopTimerInvalidate(tbContext->readStreamTimer);
        // release any previous readStreamTimer 
        CFRelease(tbContext->readStreamTimer);
    }
    
    // init the CFRunLoopTimerContext for this timer
    timerContext.info = tbContext;
    timerContext.version = 0;
    timerContext.retain = NULL;
    timerContext.release = NULL;
    timerContext.copyDescription = NULL;

    haltTime = tbContext->readStreamNoDataTimeOut;
    
    // check for a sufficiently sized timeout interval
    if ( 1 > haltTime || 300 < haltTime)
    {
        CUPS_DEBUG("warning! requested timeout interval (%f sec) exceeds limits.\n", haltTime);
        
        haltTime = (CFAbsoluteTime) kReadStreamNoDataTimeOutDefault;
        CUPS_DEBUG("default timeout value of (%f sec) has been substituted.\n", haltTime);
    }
    
    // we're waiting for data from the readstream, but we don't want to wait forever
    // create a timer and add it to the run loop
    haltTime += CFAbsoluteTimeGetCurrent();
    tbContext->readStreamTimer = CFRunLoopTimerCreate(NULL, haltTime, 0, 0, 0, readStreamTimerCallback, &timerContext );
    
    // validate the new timer
    if (NULL != tbContext->readStreamTimer) 
    {
        if (CFRunLoopTimerIsValid(tbContext->readStreamTimer))
        {
        // add it to the runloop and ...
        CFRunLoopAddTimer (CFRunLoopGetCurrent(), tbContext->readStreamTimer, kCFRunLoopCommonModes);
        // ... set the readStatus so that we can check for this condition later
        tbContext->readStatus=kIOReturnTimeout;

        return true;
        }
        // somehow we created an invalid timer; release it
        CFRelease(tbContext->readStreamTimer);
        tbContext->readStreamTimer = NULL;
    }

    // failed to create a valid timer
    tbContext->readStatus=kIOReturnNoResources;
    CUPS_DEBUG("failed to create a CFRunLoopTimer in setReadStreamTimerForContext().\n");    

    // the calling function should stop the runloop if it's running.

    return false;
}

/*
 * End of "$Id: main.c 109 2008-11-01 21:04:33Z tyler $".
 */
